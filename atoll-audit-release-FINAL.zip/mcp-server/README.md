# Atoll Audit (v0.3)
Read-only security check for apps built with AI coding tools (Lovable, Bolt, Cursor, v0, Replit) on Supabase or Firebase, **for apps you own**. Python 3 standard library only, no dependencies.

    python3 -m atoll_audit.cli https://your-app.example --i-own-this-app --out reports/myapp   # single scan + reports
    python3 -m atoll_audit.fulfill order.json --out orders                                     # free scan request -> triple-checked report + email draft
    python3 -m atoll_audit.cli remediate reports/myapp/result.json --project-ref REF           # fix-it layer (dry run by default)
    python3 -m atoll_audit.mcp_server                                                          # MCP server for Cursor / Claude Code (see MCP.md)
    python3 -m atoll_audit.api --port 8787                                                     # local HTTP JSON API
    python3 -m unittest discover -s tests -v                                                   # 97 tests, all against local mocks (Node used for the web checker tests)

## What it checks
- **Keys:** Supabase service_role / sb_secret_, Stripe, OpenAI, Anthropic, Resend, Twilio, SendGrid, AWS, GitHub, Slack, private keys; Google keys (restrict them).
- **Data:** Supabase tables readable with the anon key (limit=1, values discarded), public buckets/files, open Firebase RTDB/Firestore.
- **Auth gaps:** `/auth/v1/settings`: email confirmation off, open sign-ups, anonymous sign-ins. Admin routes from the bundle: *proven* if served without login, otherwise *review*.
- **Rate limits:** RateLimit / X-RateLimit / Retry-After headers on login endpoints (OPTIONS/HEAD only, never brute force; low/info).
- **Debug/dev leftovers:** /api/debug, Next.js dev builds, Vite dev server, GraphQL introspection (GET query only), Swagger/OpenAPI, phpinfo, /server-status, Spring /actuator, stack traces on a harmless 404.
- **Vulnerable libraries:** lodash, jquery, axios, next, react-dom versions from bundle banners vs. `atoll_audit/data/vulnerable_versions.json` (CVE ranges verified Oct 17 2026). Reported as "version appears vulnerable".
- **Exposed env:** secret-looking VITE_/NEXT_PUBLIC_/REACT_APP_ vars, `process.env` dumps, `window.__ENV__` objects, database connection strings.
- Source maps, `.env`, `.git`, security headers, CORS.

## Triple-check verification (fulfill, MCP, API)
1. First independent scan. 2. Second independent scan: only findings seen in both are **confirmed**; the rest are listed as **unconfirmed** and excluded from the grade. 3. Safety audit: only GET/HEAD/OPTIONS, limit=1 on every table read, no RPC, no function calls, and no full key / JWT / email anywhere in result.json, report.md or report.html. A report is "ready" only if all three pass. A human still reviews it before sending.

## Safety
Only GET/HEAD/OPTIONS (enforced in the HTTP client), 0.2 s between requests, `limit=1` row reads, row values discarded (column names only), keys masked, RPC never called, Edge Functions only preflighted (OPTIONS) unless `--allow-function-invocation` (CLI only; never from MCP/API/fulfill). Consent flag `--i-own-this-app` is required.

## Fix-it layer v1 (Supabase)
`remediate.py` proposes **enable RLS (default-deny)** for flagged tables and **make bucket private** for flagged buckets, with the exact SQL and rollback SQL for each. It runs as a dry run by default. With `--apply` plus `SUPABASE_ACCESS_TOKEN`, every fix needs a typed `APPLY <fix-id>`, a read-only snapshot is taken first, the change goes through the Management API `database/query` endpoint (beta), the app is re-scanned to verify, and a typed `ROLLBACK <fix-id>` is offered if the finding remains. Everything goes to a hash-chained JSONL audit log (`--verify-log` checks it). Per-user policies and key rotation are produced as **drafts only** (`drafts/policies.sql`, `drafts/key-rotation-checklist.md`). Tests use a local mock Management API; nothing contacts real Supabase.
