# Atoll Audit for AI coding assistants (MCP + local HTTP API)
Let Cursor, Claude Code, Windsurf and other MCP clients run Atoll Audit directly. The server is **pure Python standard library** (JSON-RPC 2.0 over stdio, no SDK and nothing to install), so it only needs Python 3.9+ and this folder.

    python3 -m atoll_audit.mcp_server        # run from the atoll-audit folder (or set PYTHONPATH to it)

## Tools
| Tool | Input | Returns |
|---|---|---|
| `scan_app` | `url`, `i_own_this_app` (must be `true`) | Grade, counts, **confirmed** findings (each with explanation and fix prompt), **suspected** findings (seen in only 1 of 2 scans), triple-check verification, safe metadata (tables, buckets, libraries, auth settings). Refuses if `i_own_this_app` isn't `true`. **Never invokes the app's server functions.** |
| `check_code_for_leaks` | `code` | Masked leaked-key findings (same patterns as the free web checker), detected platform. Runs locally; nothing leaves your machine. |
| `get_fix_prompt` | `finding_id`, optional `context` (`table`, `bucket`, `route`, `library`, `variable`, `path`…) | Plain-English explanation plus a copy-paste fix prompt. |

Scans are read-only (GET/HEAD/OPTIONS), rate-limited, read at most one row per table and discard values, and mask keys. Each `scan_app` call runs two independent scans and a safety audit (about 2× the requests of a single scan; expect 20–60 seconds on a real app).

## Cursor: `.cursor/mcp.json` (project) or `~/.cursor/mcp.json` (global)
```json
{
  "mcpServers": {
    "atoll-audit": {
      "command": "python3",
      "args": ["-m", "atoll_audit.mcp_server"],
      "env": { "PYTHONPATH": "/ABSOLUTE/PATH/TO/atoll-audit" }
    }
  }
}
```
Then in Cursor chat: *"Use atoll-audit to check this repo's built bundle for leaked keys"* or *"Scan https://my-app.lovable.app with atoll-audit. I own it."*

## Claude Code
```bash
claude mcp add atoll-audit -e PYTHONPATH=/ABSOLUTE/PATH/TO/atoll-audit -- python3 -m atoll_audit.mcp_server
```
Or commit a project-scoped `.mcp.json` with the same `mcpServers` block as Cursor above.

## Windsurf: `~/.codeium/windsurf/mcp_config.json`
Same `mcpServers` block as Cursor.

On Windows use `"command": "py"` or the full path to `python.exe`.

## Local HTTP JSON API (agents without MCP)
```bash
python3 -m atoll_audit.api --port 8787          # binds 127.0.0.1 only
curl -s localhost:8787/health
curl -s -X POST localhost:8787/check-code -H 'Content-Type: application/json' -d '{"code":"const k=\"...\""}'
curl -s -X POST localhost:8787/scan       -H 'Content-Type: application/json' -d '{"url":"https://my-app.example","i_own_this_app":true}'
curl -s -X POST localhost:8787/fix-prompt -H 'Content-Type: application/json' -d '{"finding_id":"public-storage-bucket","context":{"bucket":"avatars"}}'
```
`/scan` without `"i_own_this_app": true` returns 403.

## Tuning (env vars)
- `ATOLL_DELAY`: seconds between requests (default 0.2).
- `ATOLL_FIRESTORE_BASE`: Firestore REST base (tests only).

## Notes
- The assistant must ask **you** to confirm ownership before it sets `i_own_this_app=true`; the tool description tells it to.
- For public users this would later be offered as a **hosted** MCP server (HTTP transport, sign-in, per-user rate limits and an ownership-verification step such as a `/.well-known/atollaudit.txt` token). Today it runs locally on your own machine, and scans come from your own IP.
- Tested by `tests/test_mcp.py`, which spawns the server and runs initialize → tools/list → tools/call against the local insecure test target.
