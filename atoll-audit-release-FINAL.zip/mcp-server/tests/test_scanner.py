import json, sys, pathlib, unittest, tempfile
ROOT = pathlib.Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from testtarget import server
from atoll_audit.scanner import scan, Client
from atoll_audit.report import to_markdown, to_html
from atoll_audit.cli import main

class T(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.t = server.start(); server.State.requests.clear()
        cls.res = scan(cls.t["site"], Client(delay=0.01), firestore_base=cls.t["firebase"])
        cls.reqs = list(server.State.requests)
        cls.sec = scan(cls.t["secure_site"], Client(delay=0.01), firestore_base=cls.t["firebase"])
        cls.ids = [f["id"] for f in cls.res["findings"]]
        cls.out = json.dumps(cls.res) + to_markdown(cls.res) + to_html(cls.res)
    @classmethod
    def tearDownClass(cls):
        for s in cls.t["servers"]: s.shutdown()
    def by(self, fid, key=None):
        return [f.get(key) if key else f for f in self.res["findings"] if f["id"] == fid]

    # --- discovery
    def test_custom_domain_supabase_url(self): self.assertEqual(self.res["info"]["supabase_url"], self.t["api"])
    def test_follows_lazy_chunk(self): self.assertTrue(any("chunk-settings" in b for b in self.res["info"]["bundles"]))
    # --- keys
    def test_anon_key_info_only(self):
        self.assertEqual([f["severity"] for f in self.by("anon-key-public")], ["info"])
    def test_service_role(self): self.assertEqual(self.by("service-role-key-exposed")[0]["severity"], "critical")
    def test_all_secret_types(self):
        for fid in ("supabase-secret-key-exposed", "stripe-secret-key-exposed", "openai-key-exposed", "anthropic-key-exposed",
                    "resend-key-exposed", "twilio-key-exposed"):
            self.assertIn(fid, self.ids, fid)
        self.assertEqual(self.by("anthropic-key-exposed")[0]["where"].split("/")[-1], "chunk-settings-9f8e.js")
        self.assertEqual(len(self.by("openai-key-exposed")), 1)  # anthropic key not double-counted as OpenAI
    def test_google_key(self): self.assertEqual(self.by("google-api-key-public")[0]["severity"], "medium")
    # --- tables
    def test_sensitive_table_critical(self):
        f = self.by("table-readable-sensitive")
        self.assertEqual([x["table"] for x in f], ["profiles"]); self.assertEqual(f[0]["severity"], "critical")
        self.assertEqual(set(f[0]["sensitive_columns"]), {"email", "phone", "password_hash", "stripe_customer_id"})
    def test_plain_open_table_high(self): self.assertEqual(self.by("table-readable-by-anon", "table"), ["posts"])
    def test_protected_table_negative(self):
        self.assertNotIn("private_notes", json.dumps(self.res["findings"]))
        self.assertFalse([t for t in self.res["info"]["tables"] if t["table"] == "private_notes"][0]["anon_readable"])
    # --- storage
    def test_public_bucket_and_private_negative(self): self.assertEqual(self.by("public-storage-bucket", "bucket"), ["avatars"])
    def test_public_file_and_private_file_negative(self):
        self.assertEqual(self.by("public-storage-file", "bucket"), ["avatars"])
        inv = [s for s in self.res["info"]["storage_files"] if s["bucket"] == "invoices"]
        self.assertEqual(len(inv), 1); self.assertFalse(inv[0]["downloadable_without_auth"])
    # --- edge functions
    def test_functions_default_safe(self):
        self.assertNotIn("edge-function-no-auth", self.ids)
        self.assertEqual([f["severity"] for f in self.by("edge-function-review")], ["info"])
        self.assertEqual(self.by("edge-function-review", "function"), ["send-welcome"])
        fn = {f["function"]: f for f in self.res["info"]["functions"]}
        self.assertTrue(fn["admin-export"]["auth_required"])
        self.assertFalse([1 for m, p in self.reqs if "/functions/v1/" in p and m != "OPTIONS"])
    def test_functions_opt_in_invocation(self):
        server.State.requests.clear()
        r = scan(self.t["site"], Client(delay=0.01), firestore_base=self.t["firebase"], allow_function_invocation=True)
        hi = [f["function"] for f in r["findings"] if f["id"] == "edge-function-no-auth"]
        self.assertEqual(hi, ["send-welcome"])
        self.assertFalse([f for f in r["findings"] if f["id"] == "edge-function-review"])
        gets = [p for m, p in server.State.requests if m == "GET" and "/functions/v1/" in p]
        self.assertEqual(gets, [p for p in gets if "send-welcome" in p])  # admin-export never invoked (preflight 401)
        self.assertFalse([1 for m, p in server.State.requests if m in ("POST", "HEAD") and "/functions/v1/" in p])
    def test_cli_opt_in_flag_warns(self):
        import io, contextlib
        err = io.StringIO()
        with contextlib.redirect_stderr(err), contextlib.redirect_stdout(io.StringIO()):
            main([self.t["site"], "--i-own-this-app", "--allow-function-invocation", "--out", tempfile.mkdtemp(), "--delay", "0.01"], firestore_base=self.t["firebase"])
        self.assertIn("WARNING", err.getvalue())
    # --- firebase
    def test_rtdb_open(self): self.assertEqual(self.by("firebase-rtdb-open")[0]["severity"], "critical")
    def test_firestore_open_and_protected_negative(self):
        f = self.by("firestore-open-read")
        self.assertEqual([x["collection"] for x in f], ["public_posts"]); self.assertEqual(f[0]["severity"], "critical")
        self.assertNotIn("admin_logs", json.dumps(self.res["findings"]))
    # --- exposed files
    def test_source_map(self): self.assertEqual(self.by("source-map-exposed", "path"), ["/assets/index-abc123.js.map"])
    def test_no_sourcemap_false_positive_spa_fallback(self):
        self.assertFalse(any("chunk" in (p or "") for p in self.by("source-map-exposed", "path")))
    def test_env_and_git(self): self.assertIn("env-file-exposed", self.ids); self.assertIn("git-exposed", self.ids)
    # --- headers / CORS
    def test_headers_and_cors(self):
        for fid in ("missing-csp", "missing-xfo", "cors-permissive-credentials"): self.assertIn(fid, self.ids)
        self.assertNotIn("missing-hsts", self.ids)  # site is plain HTTP: HSTS not applicable
    def test_hsts_only_over_https(self):
        from atoll_audit.scanner import Scan
        for url, expect in (("https://app.example/", True), ("http://app.example/", False)):
            sc = Scan(url, Client(), "", 1, 1); sc.page_headers = {}; sc.headers()
            self.assertEqual("missing-hsts" in [f["id"] for f in sc.findings], expect, url)
        sc = Scan("https://app.example/", Client(), "", 1, 1); sc.page_headers = {"strict-transport-security": "max-age=1"}; sc.headers()
        self.assertNotIn("missing-hsts", [f["id"] for f in sc.findings])
    # --- secure site negative control (SPA fallback, good headers, wildcard CORS w/o credentials)
    def test_secure_site_clean(self):
        ids = {f["id"] for f in self.sec["findings"]}
        self.assertEqual(ids, {"no-backend"}, ids); self.assertEqual(self.sec["grade"], "A")
    # --- grading
    def test_grade_f(self): self.assertEqual(self.res["grade"], "F")
    # --- safety
    def test_only_safe_methods(self):
        self.assertTrue({m for m, _ in self.reqs} <= {"GET", "HEAD", "OPTIONS"})
        self.assertTrue(all(r["method"] in ("GET", "HEAD", "OPTIONS") for r in self.res["requests"]))
    def test_limit1_and_no_rpc_and_no_unbounded_rtdb(self):
        for _, p in self.reqs:
            if p.startswith("api:/rest/v1/") and p != "api:/rest/v1/": self.assertIn("limit=1", p)
            if p.startswith("fb:/.json"): self.assertIn("shallow=true", p)
            if "/documents/" in p: self.assertIn("pageSize=1", p)
        self.assertFalse(any("/rpc/" in p for _, p in self.reqs))
    def test_functions_probed_without_auth(self):
        self.assertTrue(any(m == "OPTIONS" and "/functions/v1/" in p for m, p in self.reqs))
    def test_no_values_or_full_keys_leak(self):
        leaks = ["alice@example.test", "+15550100", "$2b$fakehash", "cus_FAKE", "Hello public post", "secret note", "bob@example.test",
                 "carol@example.test", "me.png", "inv-1.pdf", "SUPABASE_SERVICE_ROLE_KEY", server.ANON, server.SERVICE, *server.FAKE_KEYS.values()]
        for leak in leaks: self.assertNotIn(leak, self.out, leak)
    def test_client_refuses_writes(self):
        for m in ("POST", "PUT", "PATCH", "DELETE"):
            with self.assertRaises(ValueError): Client().request(self.t["api"] + "/rest/v1/profiles", method=m)
    # --- CLI + reports
    def test_cli_requires_consent(self): self.assertEqual(main([self.t["site"]]), 2)
    def test_cli_writes_all_reports(self):
        d = pathlib.Path(tempfile.mkdtemp())
        self.assertEqual(main([self.t["site"], "--i-own-this-app", "--out", str(d), "--delay", "0.01"], firestore_base=self.t["firebase"]), 1)
        h = (d / "report.html").read_text()
        for s in ("Atoll Audit", "Executive summary", "NOT a full penetration test", ">F<", "Fix prompt", "Verify:", "Why it matters"):
            self.assertIn(s, h)
        self.assertNotIn("<script", h.lower())
        self.assertIn("Enable Row Level Security on the table &#x27;profiles&#x27;", h)
        json.loads((d / "result.json").read_text()); self.assertIn("## 1. [CRITICAL]", (d / "report.md").read_text())

if __name__ == "__main__": unittest.main()
