"""Fix-it layer v1 (Supabase): dry-run default, per-fix typed approval, mock Management API only, re-scan verify, rollback, hash-chained audit log."""
import copy, io, json, os, sys, pathlib, tempfile, unittest, contextlib
ROOT = pathlib.Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from testtarget import server, mgmt_api
from atoll_audit.scanner import scan, Client
from atoll_audit import remediate as R
from atoll_audit.cli import main as cli_main

REF = "fakeprojectref"

class Remediate(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.t = server.start(); cls.api_url, cls.api = mgmt_api.start(REF)
        cls.orig = (copy.deepcopy(server.TABLES), copy.deepcopy(server.BUCKETS))
    @classmethod
    def tearDownClass(cls):
        cls.api.shutdown()
        for s in cls.t["servers"]: s.shutdown()
    def setUp(self):
        server.TABLES.clear(); server.TABLES.update(copy.deepcopy(self.orig[0])); server.BUCKETS[:] = copy.deepcopy(self.orig[1])
        mgmt_api.MgmtState.calls.clear(); mgmt_api.MgmtState.fail_writes = False
        self.d = pathlib.Path(tempfile.mkdtemp()); self.log = self.d / "audit.jsonl"
        self.res = self.scan()
        os.environ["SUPABASE_ACCESS_TOKEN"] = mgmt_api.FAKE_TOKEN
    def tearDown(self):
        os.environ.pop("SUPABASE_ACCESS_TOKEN", None)
        server.TABLES.clear(); server.TABLES.update(copy.deepcopy(self.orig[0])); server.BUCKETS[:] = copy.deepcopy(self.orig[1])
    def scan(self): return scan(self.t["site"], Client(delay=0.002), firestore_base=self.t["firebase"])
    def run_fix(self, answers, apply=True, rescan=True):
        it = iter(answers); lines = []
        s = R.run(self.res, REF, apply=apply, api_base=self.api_url, log_path=self.log, drafts_dir=self.d / "drafts",
                  input_fn=lambda prompt: next(it, ""), out=lines.append, rescan_fn=self.scan if rescan else None)
        return s, "\n".join(lines)

    def test_plans_with_sql_and_rollback(self):
        p = {x["fix_id"]: x for x in R.plan_fixes(self.res)}
        self.assertEqual(set(p), {"rls:profiles", "rls:posts", "bucket:avatars"})
        self.assertEqual(p["rls:profiles"]["sql"], 'alter table public."profiles" enable row level security;')
        self.assertEqual(p["rls:profiles"]["rollback_sql"], 'alter table public."profiles" disable row level security;')
        self.assertEqual(p["bucket:avatars"]["sql"], "update storage.buckets set public = false where id = 'avatars';")
        self.assertEqual(p["bucket:avatars"]["rollback_sql"], "update storage.buckets set public = true where id = 'avatars';")
    def test_identifier_quoting(self):
        self.assertEqual(R.qident('we"ird'), '"we""ird"'); self.assertEqual(R.qlit("o'x"), "'o''x'")
        p = R.plan_fixes({"findings": [{"id": "table-readable-by-anon", "severity": "high", "title": "t", "table": 'x"; drop table y; --'}]})
        self.assertEqual(p[0]["sql"], 'alter table public."x""; drop table y; --" enable row level security;')
    def test_dry_run_default_changes_nothing(self):
        s, out = self.run_fix([], apply=False)
        self.assertEqual(mgmt_api.MgmtState.calls, []); self.assertIn("DRY RUN", out); self.assertEqual(s["applied"], [])
        self.assertFalse(server.TABLES["profiles"]["rls"]); self.assertIn("Rollback:", out)
    def test_cli_dry_run(self):
        rp = self.d / "result.json"; rp.write_text(json.dumps(self.res))
        with contextlib.redirect_stdout(io.StringIO()) as o:
            code = cli_main(["remediate", str(rp), "--project-ref", REF, "--api-base", self.api_url, "--audit-log", str(self.log), "--drafts", str(self.d / "dr")])
        self.assertEqual(code, 0); self.assertIn("DRY RUN", o.getvalue()); self.assertEqual(mgmt_api.MgmtState.calls, [])
    def test_apply_refuses_without_token(self):
        os.environ.pop("SUPABASE_ACCESS_TOKEN")
        s, out = self.run_fix(["APPLY rls:profiles"]); self.assertEqual(s.get("error"), "no token"); self.assertEqual(mgmt_api.MgmtState.calls, [])
    def test_apply_only_approved_fixes_and_verify(self):
        s, out = self.run_fix(["APPLY rls:profiles", "yes", "APPLY bucket:avatars"])  # 'yes' is NOT an approval
        self.assertEqual(s["applied"], ["rls:profiles", "bucket:avatars"]); self.assertEqual(s["skipped"], ["rls:posts"])
        self.assertTrue(server.TABLES["profiles"]["rls"]); self.assertFalse(server.TABLES["posts"]["rls"])
        self.assertFalse([b for b in server.BUCKETS if b["id"] == "avatars"][0]["public"])
        self.assertEqual(out.count("Verification by re-scan: PASSED"), 2)
        writes = [sql for path, sql in mgmt_api.MgmtState.calls if path == "database/query"]
        self.assertEqual(len(writes), 2)
        reads = [sql for path, sql in mgmt_api.MgmtState.calls if path.endswith("read-only")]
        self.assertEqual(len(reads), 3)  # snapshot taken before every proposed fix
        after = self.scan(); ids = {(f["id"], f.get("table") or f.get("bucket")) for f in after["findings"]}
        self.assertNotIn(("table-readable-sensitive", "profiles"), ids); self.assertIn(("table-readable-by-anon", "posts"), ids)
    def test_failed_verification_offers_rollback(self):
        s, out = self.run_fix(["APPLY rls:profiles", "ROLLBACK rls:profiles"], rescan=False)
        self.assertEqual(s["applied"], ["rls:profiles"])  # no rescan -> not verified, no rollback prompt
        res = self.res
        s2_lines = []; it = iter(["skip", "APPLY rls:posts", "ROLLBACK rls:posts"])
        stale = lambda: res  # simulate a re-scan that still shows the finding
        s2 = R.run(self.res, REF, apply=True, api_base=self.api_url, log_path=self.log, drafts_dir=self.d / "dr2",
                   input_fn=lambda p: next(it, ""), out=s2_lines.append, rescan_fn=stale)
        self.assertEqual(s2["rolled_back"], ["rls:posts"]); self.assertFalse(server.TABLES["posts"]["rls"])
    def test_api_failure_reported(self):
        mgmt_api.MgmtState.fail_writes = True
        s, out = self.run_fix(["APPLY rls:profiles"]); self.assertEqual(s["failed"], ["rls:profiles"]); self.assertIn("FAILED", out)
    def test_audit_log_hash_chain_and_redaction(self):
        self.run_fix(["APPLY rls:profiles"])
        ok, why = R.verify_log(self.log); self.assertTrue(ok, why)
        text = self.log.read_text(); self.assertNotIn(mgmt_api.FAKE_TOKEN, text)
        events = [json.loads(l)["event"] for l in text.splitlines()]
        for e in ("session_start", "plan", "snapshot", "approved", "execute", "verify", "declined", "session_end"): self.assertIn(e, events)
        lines = text.splitlines(); e = json.loads(lines[3]); e["data"]["fix_id"] = "tampered"; lines[3] = json.dumps(e, sort_keys=True)
        self.log.write_text("\n".join(lines) + "\n"); self.assertFalse(R.verify_log(self.log)[0])
        self.log.write_text("\n".join(text.splitlines()[:2] + text.splitlines()[3:]) + "\n"); self.assertFalse(R.verify_log(self.log)[0])  # deletion
    def test_drafts_never_executed(self):
        self.run_fix(["APPLY rls:profiles"])
        pol = (self.d / "drafts" / "policies.sql").read_text(); keys = (self.d / "drafts" / "key-rotation-checklist.md").read_text()
        self.assertIn("DRAFT ONLY", pol); self.assertIn('create policy "Own rows: select" on public."profiles"', pol); self.assertIn("(select auth.uid()) = \"id\"", pol)
        self.assertIn("No obvious owner column", pol)  # posts has no owner column
        self.assertIn("Supabase service_role key", keys); self.assertIn("cannot be undone", keys)
        self.assertFalse(any("create policy" in sql for _, sql in mgmt_api.MgmtState.calls))
    def test_mgmt_client_only_posts_query_endpoints(self):
        m = R.ManagementAPI(self.api_url, REF, "t")
        with self.assertRaises(AssertionError): m._post("api-keys", "x")
        with self.assertRaises(ValueError): R.ManagementAPI(self.api_url, "../evil", "t")

if __name__ == "__main__": unittest.main()
