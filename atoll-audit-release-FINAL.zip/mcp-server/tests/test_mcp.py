"""MCP server: spawn it over stdio and speak JSON-RPC (initialize, tools/list, tools/call) against the local test target."""
import json, os, subprocess, sys, pathlib, unittest
ROOT = pathlib.Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from testtarget import server

class MCP(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.t = server.start()
        env = {**os.environ, "ATOLL_DELAY": "0.002", "ATOLL_FIRESTORE_BASE": cls.t["firebase"], "PYTHONPATH": str(ROOT)}
        cls.p = subprocess.Popen([sys.executable, "-m", "atoll_audit.mcp_server"], cwd=ROOT, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, text=True, bufsize=1)
        cls.n = 0
        cls.init = cls.rpc("initialize", {"protocolVersion": "2025-06-18", "capabilities": {}, "clientInfo": {"name": "test", "version": "1"}})
        cls.notify("notifications/initialized")
    @classmethod
    def tearDownClass(cls):
        cls.p.stdin.close(); cls.p.wait(timeout=10); cls.p.stdout.close(); cls.p.stderr.close()
        for s in cls.t["servers"]: s.shutdown()
    @classmethod
    def rpc(cls, method, params=None):
        cls.n += 1
        cls.p.stdin.write(json.dumps({"jsonrpc": "2.0", "id": cls.n, "method": method, "params": params or {}}) + "\n"); cls.p.stdin.flush()
        r = json.loads(cls.p.stdout.readline()); assert r["id"] == cls.n, r; return r
    @classmethod
    def notify(cls, method): cls.p.stdin.write(json.dumps({"jsonrpc": "2.0", "method": method}) + "\n"); cls.p.stdin.flush()
    def call(self, name, args): return self.rpc("tools/call", {"name": name, "arguments": args})["result"]

    def test_initialize(self):
        r = self.init["result"]
        self.assertEqual(r["protocolVersion"], "2025-06-18"); self.assertEqual(r["serverInfo"]["name"], "atoll-audit"); self.assertIn("tools", r["capabilities"])
    def test_tools_list(self):
        tools = {t["name"]: t for t in self.rpc("tools/list")["result"]["tools"]}
        self.assertEqual(set(tools), {"scan_app", "check_code_for_leaks", "get_fix_prompt"})
        self.assertEqual(tools["scan_app"]["inputSchema"]["required"], ["url", "i_own_this_app"])
        self.assertNotIn("allow_function_invocation", json.dumps(tools))
    def test_scan_refused_without_ownership(self):
        r = self.call("scan_app", {"url": self.t["site"], "i_own_this_app": False})
        self.assertTrue(r["isError"]); self.assertIn("Refusing", r["content"][0]["text"])
    def test_scan_app_triple_checked(self):
        server.State.requests.clear()
        r = self.call("scan_app", {"url": self.t["site"], "i_own_this_app": True})
        self.assertFalse(r["isError"]); d = r["structuredContent"]
        self.assertEqual(d["grade"], "F"); self.assertTrue(d["verification"]["ready"]); self.assertEqual(d["suspected"], [])
        ids = {f["id"] for f in d["confirmed"]}
        self.assertTrue({"service-role-key-exposed", "table-readable-sensitive", "public-storage-bucket"} <= ids)
        self.assertTrue(all(f["fix_prompt"] for f in d["confirmed"]))
        self.assertEqual(json.loads(r["content"][0]["text"])["grade"], "F")
        out = json.dumps(r)
        for leak in (server.SERVICE, server.ANON, "alice@example.test", *server.FAKE_KEYS.values()): self.assertNotIn(leak, out)
        reqs = list(server.State.requests)
        self.assertTrue({m for m, _ in reqs} <= {"GET", "HEAD", "OPTIONS"})
        self.assertFalse([p for m, p in reqs if "/functions/v1/" in p and m != "OPTIONS"])  # never invokes functions
    def test_check_code_for_leaks(self):
        r = self.call("check_code_for_leaks", {"code": 'const k="sk_' + 'live_' + 'FAKE1234567890abcd"'})["structuredContent"]
        self.assertEqual([f["type"] for f in r["findings"]], ["stripe_secret_key"]); self.assertNotIn("FAKE1234567890abcd", json.dumps(r))
    def test_get_fix_prompt(self):
        r = self.call("get_fix_prompt", {"finding_id": "table-readable-sensitive", "context": {"table": "profiles"}})["structuredContent"]
        self.assertIn("Enable Row Level Security on the table 'profiles'", r["fix_prompt"])
        self.assertIn("Rotate", self.call("get_fix_prompt", {"finding_id": "openai_key"})["structuredContent"]["fix_prompt"])
        self.assertTrue(self.call("get_fix_prompt", {"finding_id": "nope"})["isError"])
    def test_errors(self):
        self.assertEqual(self.rpc("does/not/exist")["error"]["code"], -32601)
        self.assertEqual(self.rpc("tools/call", {"name": "rm_rf"})["error"]["code"], -32602)
        self.assertEqual(self.rpc("ping")["result"], {})

if __name__ == "__main__": unittest.main()
