"""Vibe-coding failure modes: planted issues AND negative controls in realistic mock apps."""
import json, sys, pathlib, unittest
ROOT = pathlib.Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from testtarget import apps, server
from atoll_audit.scanner import scan, Client
from atoll_audit.report import to_markdown, to_html
from atoll_audit import vibe

def _scan(t):
    server.State.requests.clear()
    r = scan(t["site"], Client(delay=0.002), firestore_base=t.get("firebase", "http://127.0.0.1:9"))
    return r, list(server.State.requests)

class VibeApps(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.apps = {n: getattr(apps, n)() for n in ("bolt_firebase", "next_supabase", "next_secure", "legacy_host")}
        cls.r, cls.reqs = {}, {}
        for n, t in cls.apps.items(): cls.r[n], cls.reqs[n] = _scan(t)
    @classmethod
    def tearDownClass(cls):
        for t in cls.apps.values():
            for s in t["servers"]: s.shutdown()
    def ids(self, app): return [f["id"] for f in self.r[app]["findings"]]
    def by(self, app, fid): return [f for f in self.r[app]["findings"] if f["id"] == fid]

    # --- auth gaps (Supabase /auth/v1/settings)
    def test_auth_settings_planted(self):
        a = self.r["next_supabase"]["info"]["auth_settings"]
        self.assertEqual(a, {"signup_open": True, "email_autoconfirm": True, "phone_autoconfirm": False, "anonymous_sign_ins": True, "email_provider": True})
        self.assertEqual(self.by("next_supabase", "auth-email-confirmation-off")[0]["severity"], "medium")
        self.assertEqual(self.by("next_supabase", "auth-anonymous-signins")[0]["severity"], "low")
        self.assertEqual(self.by("next_supabase", "auth-open-signup")[0]["severity"], "info")
    def test_auth_settings_negative(self):
        ids = self.ids("next_secure")
        self.assertNotIn("auth-email-confirmation-off", ids); self.assertNotIn("auth-anonymous-signins", ids)
        self.assertFalse(self.r["next_secure"]["info"]["auth_settings"]["email_autoconfirm"])
    def test_admin_route_proven_vs_review_vs_protected(self):
        self.assertEqual([f["route"] for f in self.by("next_supabase", "admin-page-reachable")], ["/admin"])
        routes = {x["route"]: x["status"] for x in self.r["next_supabase"]["info"]["admin_routes"]}
        self.assertEqual(routes["/internal/reports"], "redirects to login")
        self.assertNotIn("/internal/reports", json.dumps([f for f in self.r["next_supabase"]["findings"] if f["severity"] != "info"]))
        rev = self.by("bolt_firebase", "admin-route-review")
        self.assertEqual([(f["route"], f["severity"]) for f in rev], [("/admin", "info")])  # SPA: review only, not proven
        self.assertNotIn("admin-page-reachable", self.ids("bolt_firebase"))
        self.assertEqual(self.r["next_secure"]["info"]["admin_routes"], [])
    # --- rate limits (headers only)
    def test_rate_limit_signals(self):
        self.assertEqual([f["endpoint"] for f in self.by("next_supabase", "rate-limit-not-visible")], ["/api/auth/login"])  # signup has RateLimit headers
        self.assertEqual(self.by("bolt_firebase", "rate-limit-not-visible")[0]["severity"], "low")
        self.assertNotIn("rate-limit-not-visible", self.ids("next_secure"))
        self.assertEqual(self.by("next_supabase", "rate-limit-supabase-review")[0]["severity"], "info")
    def test_rate_limit_probe_never_posts(self):
        for n, reqs in self.reqs.items():
            auth = [(m, p) for m, p in reqs if "/api/auth/" in p or "/api/login" in p or "/auth/v1/token" in p]
            self.assertTrue(all(m in ("OPTIONS", "HEAD") for m, _ in auth), (n, auth))
    # --- debug / dev endpoints
    def test_debug_endpoints_planted(self):
        self.assertEqual(self.by("bolt_firebase", "debug-endpoint-exposed")[0]["severity"], "high")
        self.assertIn("nextjs-dev-mode", self.ids("next_supabase"))
        self.assertEqual([f["path"] for f in self.by("next_supabase", "graphql-introspection")], ["/graphql"])
        self.assertIn("verbose-errors", self.ids("next_supabase"))
        L = self.ids("legacy_host")
        for fid in ("phpinfo-exposed", "server-status-exposed", "actuator-exposed", "api-docs-public", "vite-dev-server-exposed"): self.assertIn(fid, L, fid)
        self.assertEqual(self.by("legacy_host", "actuator-exposed")[0]["severity"], "high")
    def test_debug_negative_controls(self):
        for n in ("next_secure", "bolt_firebase"):
            ids = self.ids(n)
            for fid in ("graphql-introspection", "phpinfo-exposed", "server-status-exposed", "actuator-exposed", "api-docs-public", "verbose-errors", "nextjs-dev-mode"):
                self.assertNotIn(fid, ids, (n, fid))
        self.assertNotIn("debug-endpoint-exposed", self.ids("next_secure"))
        self.assertTrue(self.r["bolt_firebase"]["info"]["not_found_probe"]["spa_fallback"])  # SPA fallback did not cause false positives
    def test_graphql_only_get_introspection(self):
        g = [(m, p) for m, p in self.reqs["next_supabase"] if "graphql" in p]
        self.assertTrue(g and all(m == "GET" and "__schema" in p and "mutation" not in p for m, p in g))
    # --- vulnerable dependencies
    def test_vulnerable_libraries_planted(self):
        libs = {f["library"]: f for f in self.r["next_supabase"]["findings"] if f["id"] == "vulnerable-library"}
        self.assertEqual(set(libs), {"next@14.1.0", "axios@1.5.1"})
        self.assertEqual(libs["next@14.1.0"]["cves"], ["CVE-2025-29927"]); self.assertEqual(libs["next@14.1.0"]["severity"], "high")
        self.assertEqual(libs["axios@1.5.1"]["cves"], ["CVE-2023-45857", "CVE-2025-27152"])
        self.assertIn("appears vulnerable", libs["axios@1.5.1"]["title"])
        self.assertEqual([f["library"] for f in self.by("bolt_firebase", "vulnerable-library")], ["lodash@4.17.15"])
    def test_library_negative_controls(self):
        bolt = {(l["library"], l["version"]): l["appears_vulnerable"] for l in self.r["bolt_firebase"]["info"]["libraries"]}
        self.assertEqual(bolt[("jquery", "3.7.1")], False); self.assertEqual(bolt[("react-dom", "18.2.0")], False)
        sec = self.r["next_secure"]["info"]["libraries"]
        self.assertEqual(len(sec), 4); self.assertFalse(any(l["appears_vulnerable"] for l in sec))
    def test_version_ranges(self):
        self.assertEqual([e["cve"] for e in vibe.vulns_for("next", "14.2.24")], ["CVE-2025-29927"])
        self.assertEqual(vibe.vulns_for("next", "14.2.25"), [])
        self.assertEqual({e["cve"] for e in vibe.vulns_for("next", "15.2.2")}, {"CVE-2025-29927", "CVE-2025-66478"})
        self.assertEqual({e["cve"] for e in vibe.vulns_for("jquery", "3.4.1")}, {"CVE-2020-11022", "CVE-2020-11023"})
        self.assertEqual(vibe.vulns_for("jquery", "3.5.0"), []); self.assertEqual(vibe.vulns_for("lodash", "4.17.21"), [])
        self.assertEqual(vibe.vulns_for("react-dom", "19.2.1"), [])
        for e in vibe.vuln_db(): self.assertRegex(e["cve"], r"^CVE-\d{4}-\d{4,}$"); self.assertTrue(e["ref"].startswith("https://"))
    # --- exposed env vars
    def test_env_exposure_planted(self):
        self.assertEqual([f["variable"] for f in self.by("bolt_firebase", "public-env-secret")], ["VITE_STRIPE_SECRET_KEY"])
        self.assertEqual(self.by("bolt_firebase", "env-object-exposed")[0]["secret_variables"], ["ADMIN_PASSWORD"])
        d = self.by("next_supabase", "process-env-dump")[0]; self.assertEqual(d["severity"], "high"); self.assertEqual(d["secret_variables"], ["DATABASE_URL"])
        self.assertEqual(self.by("next_supabase", "database-url-exposed")[0]["severity"], "critical")
    def test_env_negative_controls(self):
        ids = self.ids("next_secure")
        for fid in ("public-env-secret", "env-object-exposed", "process-env-dump", "database-url-exposed"): self.assertNotIn(fid, ids)
        self.assertEqual(self.by("next_secure", "env-object-public")[0]["severity"], "info")
        bolt_vars = [f.get("variable") for f in self.r["bolt_firebase"]["findings"]]
        self.assertNotIn("VITE_PUBLIC_SITE_NAME", bolt_vars); self.assertNotIn("VITE_FIREBASE_API_KEY", bolt_vars)
    # --- firebase in the Bolt app
    def test_bolt_firestore(self):
        self.assertEqual([f["collection"] for f in self.by("bolt_firebase", "firestore-open-read")], ["orders"])
        self.assertNotIn("firebase-rtdb-open", self.ids("bolt_firebase"))  # RTDB locked: negative control
    # --- whole-app negative control
    def test_secure_app_has_no_actionable_findings(self):
        bad = [f["id"] for f in self.r["next_secure"]["findings"] if f["severity"] not in ("info",)]
        self.assertEqual(bad, []); self.assertEqual(self.r["next_secure"]["grade"], "A")
    # --- safety
    def test_safe_methods_and_no_values_leak(self):
        for n, reqs in self.reqs.items(): self.assertTrue({m for m, _ in reqs} <= {"GET", "HEAD", "OPTIONS"}, n)
        secrets = ["dana@example.test", "erin@example.test", "FAKEadminPass123", "FAKEstripeLikeValue12345", "FAKEdbPass99", "FAKEsecretVALUE",
                   apps.NEXT_ANON, apps.SECURE_ANON, "42.00"]
        for n, r in self.r.items():
            out = json.dumps(r) + to_markdown(r) + to_html(r)
            for s in secrets: self.assertNotIn(s, out, (n, s))
    def test_reports_explain_new_findings(self):
        h = to_html(self.r["next_supabase"])
        for s in ("Upgrade next to the latest version", "CVE-2025-29927", "Confirm email", "Disable GraphQL introspection", "Database → Reset password"):
            self.assertIn(s, h)

if __name__ == "__main__": unittest.main()
