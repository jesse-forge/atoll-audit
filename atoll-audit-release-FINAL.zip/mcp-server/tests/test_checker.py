"""Free key-leak checker page: detection logic (run in Node), parity with the Python twin, analytics privacy, static-site hygiene."""
import json, re, shutil, subprocess, sys, pathlib, tempfile, unittest, base64
ROOT = pathlib.Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from atoll_audit import leaks
SITE = ROOT.parent / "atoll-audit-site"
if not (SITE / "checker").exists():
    SITE = ROOT.parent  # release layout: site files sit one level up

def site_html():
    """Website pages only (skips the bundled mcp-server folder in the release layout)."""
    return [p for p in SITE.rglob("*.html") if "mcp-server" not in p.relative_to(SITE).parts]
CHECKER = SITE / "checker" / "index.html"
NODE = shutil.which("node")

def b64(o): return base64.urlsafe_b64encode(json.dumps(o).encode()).decode().rstrip("=")
def jwt(role): return b64({"alg": "HS256"}) + "." + b64({"role": role, "note": "FAKE"}) + ".FAKEsignatureFAKE"
# Built from pieces; ALL FAKE.
SAMPLES = {
    "supabase_service_role": f'const a="{jwt("service_role")}"',
    "supabase_anon_key": f'createClient("https://x.supabase.co","{jwt("anon")}")',
    "supabase_publishable_key": 'k="sb_publishable_' + "FAKEabc123456" + '"',
    "supabase_secret_key": 'k="sb_secret_' + "FAKEabc123456" + '"',
    "stripe_secret_key": 'k="sk_' + 'live_' + 'FAKE1234567890abcd"',
    "openai_key": 'k="sk-' + 'proj-' + 'FAKEopenai0000000000000000"',
    "anthropic_key": 'k="sk-' + 'ant-api03-' + 'FAKE000000000000000000"',
    "resend_key": 'k="re_' + 'FAKEresend00000000000000"',
    "twilio_key": 'k="SK' + "0123456789abcdef" * 2 + '"',
    "sendgrid_key": 'k="SG.' + "FAKEsendgrid0000" + "." + "FAKEsendgrid0000xx" + '"',
    "aws_access_key": 'k="AKIA' + "FAKE000000000000" + '"',
    "github_token": 'k="ghp_' + "FAKE" * 9 + '"',
    "slack_token": 'k="xoxb-' + "0000-FAKE-token" + '"',
    "private_key": '"-----BEGIN ' + 'PRIVATE KEY-----\\nFAKE"',
    "google_api_key": 'k="AIza' + "F" * 35 + '"',
    "public_env_secret": 'env={VITE_ADMIN_TOKEN:"FAKEvalue1234"}',
}
NEGATIVES = [
    'createClient("https://x.supabase.co", import.meta.env.VITE_SUPABASE_ANON_KEY)',
    'const pk="pk_' + 'live_' + 'FAKEpublishable123"',          # Stripe publishable key is public
    'VITE_SUPABASE_URL="https://x.supabase.co"; NEXT_PUBLIC_SITE_NAME="Shop"',
    'VITE_SECRET_PLACEHOLDER="your-secret-here"; REACT_APP_TOKEN_TTL="undefined"',
    'const skeleton = "sk-short"; const re_render = 1;',
]

def run_node(texts):
    js = re.search(r"/\* ATOLL-DETECTOR-START.*?ATOLL-DETECTOR-END \*/", CHECKER.read_text(), re.S).group(0)
    d = pathlib.Path(tempfile.mkdtemp()); (d / "det.js").write_text(js)
    (d / "inp.json").write_text(json.dumps(texts))
    code = "const D=require('./det.js');const t=require('./inp.json');process.stdout.write(JSON.stringify(t.map(x=>D.detect(x))))"
    return json.loads(subprocess.run([NODE, "-e", code], cwd=d, capture_output=True, text=True, check=True).stdout)

@unittest.skipUnless(NODE, "node not installed")
class CheckerJS(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pos = dict(zip(SAMPLES, run_node(list(SAMPLES.values()))))
        cls.neg = run_node(NEGATIVES)
    def test_each_pattern_detected_with_correct_type(self):
        for t, r in self.pos.items(): self.assertEqual([f["type"] for f in r["findings"]], [t], t)
    def test_severities(self):
        self.assertEqual(self.pos["supabase_anon_key"]["findings"][0]["severity"], "info")
        self.assertEqual(self.pos["supabase_service_role"]["findings"][0]["severity"], "critical")
        self.assertEqual(self.pos["google_api_key"]["findings"][0]["severity"], "medium")
        self.assertEqual(self.pos["supabase_anon_key"]["serious"], 0)
    def test_negative_controls(self):
        for txt, r in zip(NEGATIVES, self.neg): self.assertEqual(r["findings"], [], txt)
    def test_keys_masked_and_explained(self):
        for t, r in self.pos.items():
            f = r["findings"][0]; out = json.dumps(f)
            self.assertIn("\u2026", f["masked"]); self.assertTrue(f["what"] and f["why"] and f["fix"], t)
            m = re.search(r'"([^"]{13,})"', SAMPLES[t])
            if m and t != "private_key": self.assertNotIn(m.group(1), out, t)
    def test_platform_detection(self):
        r = run_node(["/* lovable-tagger */", "https://bolt.new/x", "x.vusercontent.net", "foo.replit.app", "plain"])
        self.assertEqual([x["platform"] for x in r], ["lovable", "bolt", "v0", "replit", "unknown"])
    def test_line_numbers(self):
        r = run_node(["a\nb\n" + SAMPLES["stripe_secret_key"]])[0]; self.assertEqual(r["findings"][0]["line"], 3)
    def test_parity_with_python_detector(self):
        for t, txt in SAMPLES.items():
            py = leaks.check_code(txt)
            self.assertEqual([f["type"] for f in py["findings"]], [f["type"] for f in self.pos[t]["findings"]], t)
            self.assertEqual([f["masked"] for f in py["findings"]], [f["masked"] for f in self.pos[t]["findings"]], t)
        for txt in NEGATIVES: self.assertEqual(leaks.check_code(txt)["findings"], [], txt)

@unittest.skipUnless(NODE, "node not installed")
class Analytics(unittest.TestCase):
    def run_analytics(self, code, dnt=None, gpc=False):
        harness = """
const fs=require('fs');const vm=require('vm');
const appended=[];const ctx={navigator:{doNotTrack:%s,globalPrivacyControl:%s},location:{pathname:'/checker/',search:'?app=secret',hash:'#x'},
 document:{title:'t',head:{appendChild:(s)=>appended.push(s)},createElement:()=>({attrs:{},setAttribute(k,v){this.attrs[k]=v}})}};
ctx.window=ctx;vm.createContext(ctx);
ctx.ATOLL_CONFIG={GOATCOUNTER_CODE:%s};
vm.runInContext(fs.readFileSync(%s,'utf8'),ctx);
const sent=[];const a=ctx.atollAnalytics;
const r1=a.track('check_run'),r2=a.track('finding_supabase_service_role'),r3=a.track('platform_lovable'),r4=a.track('scan_request');
const bad=[a.track('finding_sk_'+'live_ABC123/x'),a.track('https://evil'),a.track('email_x@y.z'),a.track('platform_martian')];
if(appended.length){ctx.goatcounter={count:(o)=>sent.push(o)};appended[0].onload();}
process.stdout.write(JSON.stringify({enabled:a.enabled,appended:appended.map(s=>({src:s.src,attrs:s.attrs})),good:[r1,r2,r3,r4],bad,sent}));
""" % (json.dumps(dnt), json.dumps(gpc), json.dumps(code), json.dumps(str(SITE / "analytics.js")))
        return json.loads(subprocess.run([NODE, "-e", harness], capture_output=True, text=True, check=True).stdout)
    def test_placeholder_means_no_script(self):
        r = self.run_analytics("GOATCOUNTER_CODE"); self.assertFalse(r["enabled"]); self.assertEqual(r["appended"], [])
    def test_dnt_and_gpc_respected(self):
        for kw in ({"dnt": "1"}, {"gpc": True}):
            r = self.run_analytics("atollaudit", **kw); self.assertFalse(r["enabled"]); self.assertEqual(r["appended"], []); self.assertEqual(r["good"], [False] * 4)
    def test_enabled_sends_only_allowlisted_events_and_bare_path(self):
        r = self.run_analytics("atollaudit")
        self.assertTrue(r["enabled"]); self.assertEqual(r["appended"][0]["src"], "https://gc.zgo.at/count.js")
        self.assertEqual(r["appended"][0]["attrs"]["data-goatcounter"], "https://atollaudit.goatcounter.com/count")
        self.assertEqual(r["good"], [True] * 4); self.assertEqual(r["bad"], [False] * 4)
        self.assertEqual(r["sent"][0], {"path": "/checker/", "title": "t"})  # page view: no ?query / #hash
        self.assertEqual([s["path"] for s in r["sent"][1:]], ["check_run", "finding_supabase_service_role", "platform_lovable", "scan_request"])
        self.assertTrue(all(s.get("event") for s in r["sent"][1:]))

class StaticSite(unittest.TestCase):
    def test_files_and_nojekyll(self):
        for f in ("index.html", "checker/index.html", "privacy.html", "terms.html", "config.js", "analytics.js", "site.css", ".nojekyll", "ANALYTICS.md", "LEMON_SQUEEZY_SETUP.md", "DEPLOY.md"):
            self.assertTrue((SITE / f).exists(), f)
    def test_relative_links_only(self):
        for p in site_html():
            for href in re.findall(r'(?:href|src)="([^"#]+)"', p.read_text()):
                if href.startswith(("https://www.goatcounter.com", "mailto:")): continue
                self.assertFalse(href.startswith(("/", "http://", "https://")), (p.name, href))
                self.assertTrue((p.parent / href).resolve().exists(), (p.name, href))
    def test_single_config_placeholders(self):
        c = (SITE / "config.js").read_text()
        for k in ("GOATCOUNTER_CODE", "SCAN_REQUEST_URL", "CONTACT_EMAIL"): self.assertRegex(c, k + r': "[^"]+"')  # placeholder or a real value
        self.assertRegex(c, r'SCAN_REQUEST_URL: "(SCAN_REQUEST_URL|https://formspree\.io/f/\w+|mailto:[^"@]+@[^"]+)"')
        for p in site_html(): self.assertNotIn("goatcounter.com/count", p.read_text(), p.name)  # only analytics.js loads it
    def test_free_launch_no_paywall(self):
        for p in site_html():
            t = p.read_text().lower()
            self.assertNotIn("lemonsqueezy", t, p.name); self.assertNotIn("$29", t, p.name); self.assertNotIn("checkout", t, p.name)
    def test_checker_never_uploads(self):
        h = CHECKER.read_text()
        self.assertIn("connect-src https://*.goatcounter.com", h); self.assertIn("form-action 'none'", h)
        self.assertNotRegex(h, r"\bfetch\(|XMLHttpRequest|sendBeacon|\.submit\(")
        self.assertNotIn("innerHTML", h)  # results rendered with textContent only
        self.assertIn("Request a free full scan", h)
        self.assertNotRegex(h, r"sk_live_[A-Za-z0-9]{10}")  # no real-looking sample keys (avoids GitHub push protection)
    def test_landing_has_flow_consent_faq_privacy(self):
        h = (SITE / "index.html").read_text()
        for s in ('id="request"', 'name="owns_app"', "checker/index.html", 'id="faq"', "Do Not Track", "Global Privacy Control", "not a penetration test",
                  "terms.html", "privacy.html", "scan_request"):
            self.assertIn(s, h, s)
        for p in ("terms.html", "privacy.html"): self.assertIn("DRAFT", (SITE / p).read_text())

if __name__ == "__main__": unittest.main()

class GoatCounterSummary(unittest.TestCase):
    def test_summary_from_export_csv(self):
        sys.path.insert(0, str(ROOT / "scripts")); import goatcounter_summary as G
        csv_text = ("2Path,Title,Event,UserAgent,Browser,System,Session,Bot,Referrer,Referrer scheme,Screen size,Location,FirstVisit,Date\n"
                    "/,Atoll,false,,Chrome,Linux,s1,0,news.ycombinator.com,h,1920,US,true,2026-10-20T10:00:00Z\n"
                    "/checker/,Checker,false,,Chrome,Linux,s1,0,,,1920,US,false,2026-10-20T10:01:00Z\n"
                    "check_run,check_run,true,,Chrome,Linux,s1,0,,,1920,US,false,2026-10-20T10:02:00Z\n"
                    "finding_stripe_secret_key,x,true,,Chrome,Linux,s1,0,,,1920,US,false,2026-10-20T10:02:00Z\n"
                    "platform_lovable,x,true,,Chrome,Linux,s1,0,,,1920,US,false,2026-10-20T10:02:00Z\n"
                    "/,Atoll,false,,Bot,Linux,s9,1,,,0,US,true,2026-10-20T10:03:00Z\n")
        md = G.report(*G.summarize(csv_text))
        self.assertIn("Total page views: **2**", md); self.assertIn("| Checks run (`check_run`) | 1 | 100% of checker views |", md)
        self.assertIn("`finding_stripe_secret_key`: 1", md); self.assertIn("lovable: 1", md); self.assertIn("news.ycombinator.com: 1", md)
