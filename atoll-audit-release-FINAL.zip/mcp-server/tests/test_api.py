"""Local HTTP JSON API (for agents without MCP)."""
import json, os, sys, pathlib, threading, unittest, urllib.request, urllib.error
ROOT = pathlib.Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from testtarget import server
from atoll_audit import api

class API(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.t = server.start()
        os.environ["ATOLL_DELAY"] = "0.002"; os.environ["ATOLL_FIRESTORE_BASE"] = cls.t["firebase"]
        cls.s = api.make_server("127.0.0.1", 0); threading.Thread(target=cls.s.serve_forever, daemon=True).start()
        cls.base = f"http://127.0.0.1:{cls.s.server_address[1]}"
    @classmethod
    def tearDownClass(cls):
        cls.s.shutdown(); cls.s.server_close()
        for s in cls.t["servers"]: s.shutdown()
        os.environ.pop("ATOLL_DELAY"); os.environ.pop("ATOLL_FIRESTORE_BASE")
    def post(self, path, obj):
        req = urllib.request.Request(self.base + path, data=json.dumps(obj).encode(), method="POST", headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req) as r: return r.status, json.loads(r.read())
        except urllib.error.HTTPError as e: return e.code, json.loads(e.read())
    def test_health(self):
        with urllib.request.urlopen(self.base + "/health") as r: self.assertTrue(json.loads(r.read())["ok"])
    def test_scan_requires_ownership(self):
        c, b = self.post("/scan", {"url": self.t["site"]}); self.assertEqual(c, 403); self.assertIn("Refusing", b["error"])
    def test_scan(self):
        c, b = self.post("/scan", {"url": self.t["site"], "i_own_this_app": True})
        self.assertEqual((c, b["grade"]), (200, "F")); self.assertTrue(b["verification"]["ready"]); self.assertNotIn(server.SERVICE, json.dumps(b))
    def test_check_code_and_fix_prompt(self):
        c, b = self.post("/check-code", {"code": "x=\"sb_secret_" + "FAKEabc123456\""}); self.assertEqual(b["findings"][0]["type"], "supabase_secret_key")
        c, b = self.post("/fix-prompt", {"finding_id": "public-storage-bucket", "context": {"bucket": "avatars"}}); self.assertIn("avatars", b["fix_prompt"])
    def test_bad_requests(self):
        req = urllib.request.Request(self.base + "/scan", data=b"x", method="POST", headers={"Content-Type": "text/plain"})
        with self.assertRaises(urllib.error.HTTPError) as e: urllib.request.urlopen(req)
        self.assertEqual(e.exception.code, 415)
        self.assertEqual(self.post("/nope", {})[0], 404)
    def test_binds_localhost_by_default(self): self.assertEqual(self.s.server_address[0], "127.0.0.1")

if __name__ == "__main__": unittest.main()
