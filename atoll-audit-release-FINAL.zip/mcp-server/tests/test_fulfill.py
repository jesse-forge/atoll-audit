"""Free scan-request fulfillment + triple-check verification."""
import json, sys, pathlib, tempfile, unittest, io, contextlib
ROOT = pathlib.Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from testtarget import server, apps
from atoll_audit.scanner import Client
from atoll_audit import fulfill as F, verify as V
from atoll_audit.report import to_html

class Fulfill(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.t = server.start(); cls.sec = apps.next_secure()
    @classmethod
    def tearDownClass(cls):
        for s in cls.t["servers"] + cls.sec["servers"]: s.shutdown()
    def run_order(self, order, **kw):
        out = tempfile.mkdtemp()
        return F.fulfill(order if isinstance(order, str) else json.dumps(order), out, client_factory=lambda: Client(delay=0.002),
                         firestore_base=self.t["firebase"], allow_private=True, **kw)

    def test_parse_form_json_and_mailto_text(self):
        o = F.parse_order(json.dumps({"app_url": "https://a.example", "email": "x@example.test", "owns_app": "yes", "platform": "bolt"}))
        self.assertTrue(o["owns_app"]); self.assertEqual(o["platform"], "bolt"); self.assertEqual(len(o["request_id"]), 12)
        t = "Please run...\n\nApp URL: https://b.example\nEmail: (reply to this email)\nBuilt with: lovable\nOwnership confirmed: yes (I own this app ...)\n"
        o = F.parse_order(t); self.assertEqual((o["app_url"], o["email"], o["owns_app"], o["platform"]), ("https://b.example", "", True, "lovable"))
    def test_rejects_without_ownership_or_bad_url(self):
        code, info = F.fulfill(json.dumps({"app_url": "https://a.example", "owns_app": "no"}), tempfile.mkdtemp())
        self.assertEqual(code, 2); self.assertIn("ownership", info["errors"][0])
        code, info = F.fulfill(json.dumps({"app_url": "ftp://x", "owns_app": "yes"}), tempfile.mkdtemp()); self.assertEqual(code, 2)
        code, info = F.fulfill(json.dumps({"app_url": "http://127.0.0.1:1/", "owns_app": "yes"}), tempfile.mkdtemp())
        self.assertEqual(code, 2); self.assertIn("private", " ".join(info["errors"]))
    def test_full_order_ready_with_all_outputs(self):
        code, info = self.run_order({"app_url": self.t["site"], "email": "owner@example.test", "owns_app": "yes", "platform": "lovable"})
        self.assertEqual(code, 0); self.assertTrue(info["ready"]); self.assertEqual(info["grade"], "F")
        d = pathlib.Path(info["dir"])
        for f in ("result.json", "report.html", "report.md", "verification.json", "email_draft.txt"): self.assertTrue((d / f).exists(), f)
        v = json.loads((d / "verification.json").read_text())
        self.assertEqual([c["passed"] for c in v["checks"]], [True, True, True]); self.assertEqual(v["suspected_count"], 0)
        h = (d / "report.html").read_text(); self.assertIn("Triple-checked", h); self.assertIn("safety audit passed", h)
        self.assertNotIn("owner@example.test", h)  # customer email never put into the report
        e = (d / "email_draft.txt").read_text(); self.assertIn("To: owner@example.test", e); self.assertIn("grade F", e)
    def test_secure_app_order(self):
        code, info = self.run_order({"app_url": self.sec["site"], "owns_app": "yes"})
        self.assertEqual((code, info["grade"]), (0, "A"))
    def test_ownership_proof_required(self):
        code, info = self.run_order({"app_url": self.t["site"], "owns_app": "yes"}, require_proof=True)
        self.assertEqual(code, 4); self.assertIn("atoll-audit-verify=", info["errors"][0])
    def test_cli_main(self):
        p = pathlib.Path(tempfile.mkdtemp()) / "o.json"; p.write_text(json.dumps({"app_url": "https://x.example", "owns_app": "no"}))
        with contextlib.redirect_stderr(io.StringIO()): self.assertEqual(F.main([str(p)]), 2)

class TripleCheck(unittest.TestCase):
    def f(self, fid, sev="high", **kw): return {"id": fid, "severity": sev, "title": fid, **kw}
    def test_merge_confirms_only_repeated_findings(self):
        r1 = {"findings": [self.f("table-readable-by-anon", table="a"), self.f("public-storage-bucket", bucket="x"), self.f("anon-key-public", "info")]}
        r2 = {"findings": [self.f("table-readable-by-anon", table="a"), self.f("missing-csp", "low")]}
        c, s = V.merge_passes(r1, r2)
        self.assertEqual([x["id"] for x in c], ["table-readable-by-anon", "anon-key-public"])
        self.assertEqual(sorted(x["id"] for x in s), ["missing-csp", "public-storage-bucket"])
    def test_audit_catches_unmasked_values_and_unsafe_requests(self):
        bad = {"report.html": "key sk_live_" + "A1b2C3d4E5f6G7h8 and alice@example.test"}
        probs = V.audit_outputs(bad)
        self.assertTrue(any("stripe_secret_key" in p for p in probs)); self.assertTrue(any("email-like" in p for p in probs))
        self.assertFalse(any("A1b2C3d4E5f6G7h8" in p for p in probs))  # the audit itself masks what it reports
        reqs = [{"method": "POST", "url": "http://x/rest/v1/t"}, {"method": "GET", "url": "http://x/rest/v1/t?select=*"},
                {"method": "GET", "url": "http://x/functions/v1/f"}, {"method": "GET", "url": "http://x/rest/v1/rpc/f?limit=1"}]
        self.assertEqual(len(V.audit_requests(reqs)), 5)  # POST also lacks limit=1
        self.assertEqual(V.audit_requests([{"method": "GET", "url": "http://x/rest/v1/t?select=*&limit=1"}]), [])
    def test_flaky_finding_becomes_suspected_and_excluded_from_grade(self):
        t = server.start()
        try:
            calls = {"n": 0}
            orig = server.TABLES["posts"]["rls"]
            class Flaky(Client):
                def request(self, url, *a, **k):
                    if "/rest/v1/posts" in url:
                        calls["n"] += 1; server.TABLES["posts"]["rls"] = calls["n"] > 1  # readable only in the first pass
                    return super().request(url, *a, **k)
            res = V.triple_check(t["site"], client_factory=lambda: Flaky(delay=0.002), firestore_base=t["firebase"])
            server.TABLES["posts"]["rls"] = orig
            self.assertEqual([s["table"] for s in res["suspected"] if s.get("table")], ["posts"])
            self.assertNotIn("posts", [f.get("table") for f in res["findings"] if f["severity"] != "info"])
            self.assertIn("seen in only one scan", to_html(res))
        finally:
            for s in t["servers"]: s.shutdown()

if __name__ == "__main__": unittest.main()
