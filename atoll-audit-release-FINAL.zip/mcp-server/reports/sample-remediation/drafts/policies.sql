-- DRAFT ONLY. Atoll Audit never runs this file. Review with someone who knows the app, then test as two different users.
-- Pattern: each user may only see and change their own rows. Adjust the owner column and add rules for shared/public rows.

-- Table profiles (columns seen: email, id, password_hash, phone, stripe_customer_id)
create policy "Own rows: select" on public."profiles" for select to authenticated using ((select auth.uid()) = "id");
create policy "Own rows: insert" on public."profiles" for insert to authenticated with check ((select auth.uid()) = "id");
create policy "Own rows: update" on public."profiles" for update to authenticated using ((select auth.uid()) = "id") with check ((select auth.uid()) = "id");
create policy "Own rows: delete" on public."profiles" for delete to authenticated using ((select auth.uid()) = "id");

-- Table posts (columns seen: id, title)
-- No obvious owner column. Decide who may read posts; if it is truly public content, a read-only policy is:
-- create policy "Public read" on public."posts" for select to anon, authenticated using (true);
