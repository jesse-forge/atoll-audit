# Key rotation checklist (DRAFT: instructions only, nothing is changed automatically)

Order matters: create the new key → update every place that uses it → deploy → only then disable the old key.

## Supabase service_role key (masked: `eyJhbG…ture`)

- [ ] Supabase Dashboard → Project Settings → API Keys: create a new secret key.
- [ ] Update it in Edge Function secrets, server env vars, cron jobs and CI. Never in VITE_/NEXT_PUBLIC_ vars.
- [ ] Remove the old key from frontend code and redeploy; re-run Atoll Audit to confirm it's gone from the bundle.
- [ ] Disable the legacy service_role key / delete the old secret key. ⚠️ Deleting a new-style secret key cannot be undone.
- [ ] Review Database → logs for unexpected activity while the key was public.

## Supabase secret key (sb_secret_) (masked: `sb_sec…cdef`)

- [ ] Supabase Dashboard → Project Settings → API Keys: create a new secret key.
- [ ] Update it in Edge Function secrets, server env vars, cron jobs and CI. Never in VITE_/NEXT_PUBLIC_ vars.
- [ ] Remove the old key from frontend code and redeploy; re-run Atoll Audit to confirm it's gone from the bundle.
- [ ] Disable the legacy service_role key / delete the old secret key. ⚠️ Deleting a new-style secret key cannot be undone.
- [ ] Review Database → logs for unexpected activity while the key was public.

## Stripe secret key (masked: `sk_liv…test`)

- [ ] In the provider's dashboard, create a new Stripe secret key and update server-side secrets.
- [ ] Remove the key from frontend code, move calls into a server function that checks login, redeploy.
- [ ] Revoke the old key; check the provider's usage/billing logs for abuse.

## Anthropic API key (masked: `sk-ant…test`)

- [ ] In the provider's dashboard, create a new Anthropic API key and update server-side secrets.
- [ ] Remove the key from frontend code, move calls into a server function that checks login, redeploy.
- [ ] Revoke the old key; check the provider's usage/billing logs for abuse.

## OpenAI API key (masked: `sk-pro…test`)

- [ ] In the provider's dashboard, create a new OpenAI API key and update server-side secrets.
- [ ] Remove the key from frontend code, move calls into a server function that checks login, redeploy.
- [ ] Revoke the old key; check the provider's usage/billing logs for abuse.

## Resend API key (masked: `re_FAK…test`)

- [ ] In the provider's dashboard, create a new Resend API key and update server-side secrets.
- [ ] Remove the key from frontend code, move calls into a server function that checks login, redeploy.
- [ ] Revoke the old key; check the provider's usage/billing logs for abuse.

## Twilio API key/secret (masked: `SKffff…ffaa`)

- [ ] In the provider's dashboard, create a new Twilio API key/secret and update server-side secrets.
- [ ] Remove the key from frontend code, move calls into a server function that checks login, redeploy.
- [ ] Revoke the old key; check the provider's usage/billing logs for abuse.
