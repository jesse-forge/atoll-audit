# Atoll Audit report

**Target:** http://127.0.0.1:39295/  
**Overall grade:** F: Failing. Multiple critical issues; fix before sharing the app with more users.  
**Findings:** 11 critical · 5 high · 2 medium · 2 low

> This is an automated, read-only, owner-consented security check. It is NOT a full penetration test and does not guarantee your app is secure. It only tests what is reachable from your public website. Row contents and file contents are never stored or shown; keys are masked.

**Verification:** Triple-checked. 20 finding(s) confirmed in two independent scans; safety audit passed (read-only requests only, no keys or data values in this report).

## 1. [CRITICAL] Supabase service_role key exposed in frontend (bypasses all RLS)

- Key (masked): `eyJhbG…ture` in `http://127.0.0.1:39295/assets/index-abc123.js`

**What this means:** Your app's master Supabase key (service_role) is inside the code every visitor downloads.

**Why it matters:** This key bypasses all security rules. Anyone can read, change, or delete every row in your database.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
First rotate the service_role key in Supabase → Project Settings → API. Then: Remove every use of the Supabase service_role key from frontend code. Only the anon/publishable key may be used in the browser. Move any operation that needs elevated privileges into a Supabase Edge Function that reads the key from environment secrets and checks the user's JWT, and call that function from the frontend instead.
```

**Verify:** Rotate the key, redeploy, and re-run Atoll Audit: this finding should disappear. The old key must return 401.

## 2. [CRITICAL] Supabase secret key (sb_secret_) exposed in frontend code

- Key (masked): `sb_sec…cdef` in `http://127.0.0.1:39295/assets/index-abc123.js`

**What this means:** A Supabase secret key (sb_secret_) is in the code every visitor downloads.

**Why it matters:** Anyone can copy it and use the service on your account and bill (e.g. send emails, make AI calls, charge cards).

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
First revoke/rotate this key in the provider's dashboard. Then: Remove the Supabase secret key (sb_secret_) from all frontend code. Store it as a Supabase Edge Function secret (or server environment variable) and call the provider from a server function that checks the user's login.
```

**Verify:** Rotate the key and re-run Atoll Audit; this finding should disappear and the old key should stop working.

## 3. [CRITICAL] Stripe secret key exposed in frontend code

- Key (masked): `sk_liv…test` in `http://127.0.0.1:39295/assets/index-abc123.js`

**What this means:** A Stripe secret key is in the code every visitor downloads.

**Why it matters:** Anyone can copy it and use the service on your account and bill (e.g. send emails, make AI calls, charge cards).

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
First revoke/rotate this key in the provider's dashboard. Then: Remove the Stripe secret key from all frontend code. Store it as a Supabase Edge Function secret (or server environment variable) and call the provider from a server function that checks the user's login.
```

**Verify:** Rotate the key and re-run Atoll Audit; this finding should disappear and the old key should stop working.

## 4. [CRITICAL] Anthropic API key exposed in frontend code

- Key (masked): `sk-ant…test` in `http://127.0.0.1:39295/assets/chunk-settings-9f8e.js`

**What this means:** A Anthropic API key is in the code every visitor downloads.

**Why it matters:** Anyone can copy it and use the service on your account and bill (e.g. send emails, make AI calls, charge cards).

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
First revoke/rotate this key in the provider's dashboard. Then: Remove the Anthropic API key from all frontend code. Store it as a Supabase Edge Function secret (or server environment variable) and call the provider from a server function that checks the user's login.
```

**Verify:** Rotate the key and re-run Atoll Audit; this finding should disappear and the old key should stop working.

## 5. [CRITICAL] OpenAI API key exposed in frontend code

- Key (masked): `sk-pro…test` in `http://127.0.0.1:39295/assets/chunk-settings-9f8e.js`

**What this means:** A OpenAI API key is in the code every visitor downloads.

**Why it matters:** Anyone can copy it and use the service on your account and bill (e.g. send emails, make AI calls, charge cards).

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
First revoke/rotate this key in the provider's dashboard. Then: Remove the OpenAI API key from all frontend code. Store it as a Supabase Edge Function secret (or server environment variable) and call the provider from a server function that checks the user's login.
```

**Verify:** Rotate the key and re-run Atoll Audit; this finding should disappear and the old key should stop working.

## 6. [CRITICAL] Resend API key exposed in frontend code

- Key (masked): `re_FAK…test` in `http://127.0.0.1:39295/assets/chunk-settings-9f8e.js`

**What this means:** A Resend API key is in the code every visitor downloads.

**Why it matters:** Anyone can copy it and use the service on your account and bill (e.g. send emails, make AI calls, charge cards).

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
First revoke/rotate this key in the provider's dashboard. Then: Remove the Resend API key from all frontend code. Store it as a Supabase Edge Function secret (or server environment variable) and call the provider from a server function that checks the user's login.
```

**Verify:** Rotate the key and re-run Atoll Audit; this finding should disappear and the old key should stop working.

## 7. [CRITICAL] Twilio API key/secret exposed in frontend code

- Key (masked): `SKffff…ffaa` in `http://127.0.0.1:39295/assets/chunk-settings-9f8e.js`

**What this means:** A Twilio API key/secret is in the code every visitor downloads.

**Why it matters:** Anyone can copy it and use the service on your account and bill (e.g. send emails, make AI calls, charge cards).

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
First revoke/rotate this key in the provider's dashboard. Then: Remove the Twilio API key/secret from all frontend code. Store it as a Supabase Edge Function secret (or server environment variable) and call the provider from a server function that checks the user's login.
```

**Verify:** Rotate the key and re-run Atoll Audit; this finding should disappear and the old key should stop working.

## 8. [CRITICAL] Table 'profiles' with sensitive columns (email, password_hash, phone, stripe_customer_id) is readable by anyone

- Exposed columns/fields (names only): email, id, password_hash, phone, stripe_customer_id

**What this means:** Anyone can read the table 'profiles', which contains personal or payment-related columns (email, password_hash, phone, stripe_customer_id).

**Why it matters:** This is a data breach waiting to happen: emails, phone numbers, password hashes or customer IDs can be scraped by anyone, which can trigger legal duties (e.g. breach notification).

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Enable Row Level Security on the table 'profiles'. Add policies so users can only select, insert, update, and delete their own rows (auth.uid() = user_id). Never expose columns like password_hash to the client; move them to a separate table with no client access. Show me the SQL migration before applying it.
```

**Verify:** Re-run Atoll Audit. 'profiles' should show 'Readable by anon: no'. Also log in as two different test users and confirm each sees only their own rows.

## 9. [CRITICAL] Firebase Realtime Database is readable by anyone (2 top-level keys)


**What this means:** Your Firebase Realtime Database can be read by anyone.

**Why it matters:** All data in it, including user records, can be downloaded with a single request.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Update Firebase Realtime Database security rules: deny read and write by default (".read": false, ".write": false) and only allow each user to access their own path using auth.uid. Show me the rules before deploying.
```

**Verify:** Open <databaseURL>/.json in a private window: it should return 'Permission denied'. Re-run Atoll Audit.

## 10. [CRITICAL] Firestore collection 'public_posts' is readable by anyone

- Exposed columns/fields (names only): author_email, title

**What this means:** The Firestore collection 'public_posts' can be read without logging in.

**Why it matters:** Anyone can list documents in it; sensitive-looking fields: author_email.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Update Firestore security rules so the 'public_posts' collection is only readable by signed-in users who own the document (request.auth.uid == resource.data.userId), and deny everything else by default.
```

**Verify:** Re-run Atoll Audit; the collection should return PERMISSION_DENIED.

## 11. [CRITICAL] /.env file is publicly downloadable (may contain secrets)


**What this means:** Your /.env file can be downloaded from your website.

**Why it matters:** These files usually contain secret keys and database passwords.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Remove the .env file from the deployed/public folder, add .env to .gitignore, and make sure only VITE_/NEXT_PUBLIC_ public values are bundled. Then rotate every secret that was in the file.
```

**Verify:** Open https://yourapp/.env: it should return 404 or the normal page. Rotate every key that was in it.

## 12. [HIGH] File in bucket 'avatars' is downloadable by anyone (URL found in your frontend)


**What this means:** A file in bucket 'avatars' that is linked from your frontend can be downloaded without logging in.

**Why it matters:** Confirms the bucket is serving files publicly. If these are user uploads, they are exposed.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Make the 'avatars' bucket private unless it only contains public assets, and switch the app to signed URLs created after checking the logged-in user.
```

**Verify:** Open the old file URL in a private browser window: it should fail.

## 13. [HIGH] Table 'posts' is readable by anyone with the public anon key

- Exposed columns/fields (names only): id, title

**What this means:** Anyone on the internet can read the table 'posts' using the public key built into your site.

**Why it matters:** Even if the data seems harmless today, columns added later will be exposed automatically.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Enable Row Level Security on the table 'posts'. If the rows are meant to be public, add a SELECT policy for the anon role that only exposes intended rows and columns; otherwise restrict access to auth.uid() = user_id. Show me the SQL migration before applying it.
```

**Verify:** Re-run Atoll Audit and confirm 'posts' is either no longer readable or intentionally public.

## 14. [HIGH] Storage bucket 'avatars' is public


**What this means:** The storage bucket 'avatars' is public.

**Why it matters:** Anyone who has or guesses a file URL can download it. Fine for logos and product images, dangerous for user uploads or documents.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
If 'avatars' holds private files: make the Supabase storage bucket 'avatars' private, add storage RLS policies so users can only access files under a folder named with their user id, and display files with short-lived signed URLs.
```

**Verify:** Re-run Atoll Audit; the bucket should be listed as private, and an old public file URL should return an error.

## 15. [HIGH] /.git directory is publicly reachable (source code and history can be downloaded)


**What this means:** Your /.git folder is reachable on your website.

**Why it matters:** Attackers can rebuild your full source code and history, including any secrets ever committed.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Make sure the .git folder is never deployed: deploy from a build output folder (dist/) only, and block dotfiles in the hosting config.
```

**Verify:** Open https://yourapp/.git/HEAD: it should return 404.

## 16. [HIGH] CORS allows any website to make logged-in requests (reflects arbitrary Origin with credentials)


**What this means:** Your site tells browsers that any other website may make logged-in requests to it.

**Why it matters:** A malicious site could act as your logged-in users and read their data.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Fix the CORS configuration: only allow my own domain(s) in Access-Control-Allow-Origin, never reflect arbitrary origins, and only send Access-Control-Allow-Credentials: true for that allow-list.
```

**Verify:** Re-run Atoll Audit; the CORS finding should be gone.

## 17. [MEDIUM] Google/Firebase API key in frontend: must be restricted (HTTP referrer + API restrictions)

- Key (masked): `AIzaFA…0000` in `http://127.0.0.1:39295/assets/index-abc123.js`

**What this means:** A Google/Firebase API key is in your frontend.

**Why it matters:** Firebase keys are meant to be public, but if the key is unrestricted, others can use it for paid Google APIs (like Maps) on your bill.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
In Google Cloud Console → APIs & Services → Credentials, restrict this API key to my website's domain (HTTP referrers) and only to the APIs this app uses. Do not use this key for any server-side-only API.
```

**Verify:** In Google Cloud Console, the key shows 'Application restrictions: HTTP referrers' and an API restriction list.

## 18. [MEDIUM] Source map exposed (your original source code can be downloaded)


**What this means:** Your original source code (source map) can be downloaded at /assets/index-abc123.js.map.

**Why it matters:** Attackers can read your full code, comments, and logic, making other bugs much easier to find.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Disable production source maps in the build config (e.g. in vite.config set build.sourcemap = false) and make sure no .map files are deployed.
```

**Verify:** Open /assets/index-abc123.js.map in the browser: it should return 404 or your normal page.

## 19. [LOW] Missing Content-Security-Policy header


**What this means:** No Content-Security-Policy header.

**Why it matters:** A CSP limits the damage of injected scripts (XSS).

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Add a Content-Security-Policy header in the hosting config (e.g. vercel.json or netlify.toml headers) starting with default-src 'self' and allowing only the domains my app needs (Supabase URL, fonts, analytics). Test that the app still works.
```

**Verify:** Check response headers in browser DevTools → Network → document.

## 20. [LOW] Missing clickjacking protection (X-Frame-Options or CSP frame-ancestors)


**What this means:** No clickjacking protection.

**Why it matters:** Other sites could load your app invisibly in a frame and trick users into clicking.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Add X-Frame-Options: DENY (or CSP frame-ancestors 'none') to the hosting headers config.
```

**Verify:** Check response headers in DevTools.

## Notes

- Supabase anon key in frontend (expected; safe only if RLS protects every table)
- Edge Function 'send-welcome': could not verify safely; review that this function checks auth
- Supabase Auth doesn't expose rate-limit headers; review Auth → Rate Limits in the dashboard (Supabase applies built-in limits)

## Tables checked

| Table | Readable without login |
|---|---|
| profiles | YES |
| posts | YES |
| private_notes | no |
