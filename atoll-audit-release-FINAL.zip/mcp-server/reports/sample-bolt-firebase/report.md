# Atoll Audit report

**Target:** http://127.0.0.1:40099/  
**Overall grade:** D: Poor. A critical issue puts your data or bills at risk.  
**Findings:** 1 critical · 3 high · 2 medium · 3 low

> This is an automated, read-only, owner-consented security check. It is NOT a full penetration test and does not guarantee your app is secure. It only tests what is reachable from your public website. Row contents and file contents are never stored or shown; keys are masked.

**Verification:** Triple-checked. 9 finding(s) confirmed in two independent scans; safety audit passed (read-only requests only, no keys or data values in this report).

## 1. [CRITICAL] Firestore collection 'orders' is readable by anyone

- Exposed columns/fields (names only): customer_email, total

**What this means:** The Firestore collection 'orders' can be read without logging in.

**Why it matters:** Anyone can list documents in it; sensitive-looking fields: customer_email.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Update Firestore security rules so the 'orders' collection is only readable by signed-in users who own the document (request.auth.uid == resource.data.userId), and deny everything else by default.
```

**Verify:** Re-run Atoll Audit; the collection should return PERMISSION_DENIED.

## 2. [HIGH] Debug endpoint /api/debug is publicly reachable and appears to show secrets/config


**What this means:** A debug endpoint (/api/debug) is open to the public.

**Why it matters:** Debug output often contains environment variables, keys, user data or internal details that help attackers.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Delete the /api/debug route from my app (or guard it so it only runs in development: if process.env.NODE_ENV !== 'development' return 404). Rotate any secret it may have shown. Redeploy.
```

**Verify:** Open /api/debug on the live site: it should return 404.

## 3. [HIGH] window.__ENV__ config object in your frontend contains secret-looking values (ADMIN_PASSWORD)

- Secret-looking variable names: ADMIN_PASSWORD

**What this means:** A runtime config object (window.__ENV__) in your page contains secret-looking values.

**Why it matters:** Everything in that object is readable by every visitor.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Rotate the secret values listed in the report. Remove them from window.__ENV__ so only public settings (site URL, anon key) remain; use secrets only on the server.
```

**Verify:** View page source: the secret names should be gone.

## 4. [HIGH] Secret-looking public environment variable VITE_STRIPE_SECRET_KEY is in your frontend bundle

- Key (masked): `FAKEst…2345` in `http://127.0.0.1:40099/assets/index-B0ltA1.js`

**What this means:** A secret-looking environment variable (VITE_STRIPE_SECRET_KEY) is baked into your frontend.

**Why it matters:** Variables starting with VITE_, NEXT_PUBLIC_ or REACT_APP_ are sent to every visitor. A secret there is public.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Rotate the value with whatever service issued it. Then rename VITE_STRIPE_SECRET_KEY so it doesn't start with VITE_/NEXT_PUBLIC_/REACT_APP_, use it only in server code (Edge Function / API route), and redeploy.
```

**Verify:** Re-run Atoll Audit; the variable should no longer appear.

## 5. [MEDIUM] Google/Firebase API key in frontend: must be restricted (HTTP referrer + API restrictions)

- Key (masked): `AIzaFA…0000` in `http://127.0.0.1:40099/assets/index-B0ltA1.js`

**What this means:** A Google/Firebase API key is in your frontend.

**Why it matters:** Firebase keys are meant to be public, but if the key is unrestricted, others can use it for paid Google APIs (like Maps) on your bill.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
In Google Cloud Console → APIs & Services → Credentials, restrict this API key to my website's domain (HTTP referrers) and only to the APIs this app uses. Do not use this key for any server-side-only API.
```

**Verify:** In Google Cloud Console, the key shows 'Application restrictions: HTTP referrers' and an API restriction list.

## 6. [MEDIUM] lodash 4.17.15 version appears vulnerable (CVE-2021-23337)

- CVE-2021-23337: Command injection via the template function (fixed in 4.17.21) https://github.com/advisories/GHSA-35jh-r3h4-6jhm

**What this means:** Your site ships lodash@4.17.15, and that version appears vulnerable to known security issues.

**Why it matters:** Known vulnerabilities have public write-ups that attackers use. Whether your app is actually exploitable depends on how the library is used.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Upgrade lodash to the latest version (at least the fixed version in the report) in package.json, run the install, rebuild and redeploy. Then run 'npm audit' and fix anything else it reports.
```

**Verify:** Re-run Atoll Audit; the version shown should be the new one and the finding should disappear.

## 7. [LOW] Missing Content-Security-Policy header


**What this means:** No Content-Security-Policy header.

**Why it matters:** A CSP limits the damage of injected scripts (XSS).

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Add a Content-Security-Policy header in the hosting config (e.g. vercel.json or netlify.toml headers) starting with default-src 'self' and allowing only the domains my app needs (Supabase URL, fonts, analytics). Test that the app still works.
```

**Verify:** Check response headers in browser DevTools → Network → document.

## 8. [LOW] Missing clickjacking protection (X-Frame-Options or CSP frame-ancestors)


**What this means:** No clickjacking protection.

**Why it matters:** Other sites could load your app invisibly in a frame and trick users into clicking.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Add X-Frame-Options: DENY (or CSP frame-ancestors 'none') to the hosting headers config.
```

**Verify:** Check response headers in DevTools.

## 9. [LOW] No rate-limit signal on login endpoint /api/login (can't confirm brute-force protection; headers may just be hidden)


**What this means:** We couldn't see any rate-limit signal on your login endpoint /api/login.

**Why it matters:** Without rate limiting, attackers can try thousands of passwords or flood sign-ups and emails. (Your endpoint may still be protected without showing headers; we never brute-force to find out.)

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Add rate limiting to /api/login: e.g. at most 5 attempts per minute per IP and per account, returning HTTP 429 with RateLimit-Limit/RateLimit-Remaining headers. Use a middleware or a store like Upstash Redis, or your host's firewall rules.
```

**Verify:** Check the response headers of /api/login in DevTools for RateLimit-* or X-RateLimit-* headers.

## Notes

- Review: admin route '/admin' exists in your app's code; confirm its data is protected server-side (RLS/role checks), not just hidden in the UI
