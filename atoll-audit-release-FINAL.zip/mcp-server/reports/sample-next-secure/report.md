# Atoll Audit report

**Target:** http://127.0.0.1:33279/  
**Overall grade:** A: Strong. No significant issues found by these checks.  
**Findings:** 0 critical · 0 high · 0 medium · 0 low

> This is an automated, read-only, owner-consented security check. It is NOT a full penetration test and does not guarantee your app is secure. It only tests what is reachable from your public website. Row contents and file contents are never stored or shown; keys are masked.

**Verification:** Triple-checked. 0 finding(s) confirmed in two independent scans; safety audit passed (read-only requests only, no keys or data values in this report).

## Notes

- Supabase anon key in frontend (expected; safe only if RLS protects every table)
- Sign-ups are open to anyone (fine for public apps; make sure RLS policies don't treat every logged-in user as trusted)
- Supabase Auth doesn't expose rate-limit headers; review Auth → Rate Limits in the dashboard (Supabase applies built-in limits)
- window.__ENV__ config object found (only public-looking keys: NEXT_PUBLIC_SUPABASE_ANON_KEY, NEXT_PUBLIC_SUPABASE_URL)

## Tables checked

| Table | Readable without login |
|---|---|
| profiles | no |
