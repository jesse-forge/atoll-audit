# Atoll Audit report

**Target:** http://127.0.0.1:40463/  
**Overall grade:** D: Poor. A critical issue puts your data or bills at risk.  
**Findings:** 1 critical · 2 high · 5 medium · 5 low

> This is an automated, read-only, owner-consented security check. It is NOT a full penetration test and does not guarantee your app is secure. It only tests what is reachable from your public website. Row contents and file contents are never stored or shown; keys are masked.

**Verification:** Triple-checked. 13 finding(s) confirmed in two independent scans; safety audit passed (read-only requests only, no keys or data values in this report).

## 1. [CRITICAL] A database connection string with a password is in your frontend code

- Key (masked): `postgr…/app` in `http://127.0.0.1:40463/_next/static/chunks/app/page-7c6d.js`

**What this means:** A database connection string, including its password, is in your frontend code.

**Why it matters:** Anyone can connect directly to your database and read or destroy everything, bypassing your app and RLS.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Immediately reset the database password (Supabase: Project Settings → Database → Reset password). Then remove the connection string from frontend code; only server code may use it, from a server-only environment variable. Redeploy.
```

**Verify:** Re-run Atoll Audit and confirm the old password no longer works.

## 2. [HIGH] next 14.1.0 version appears vulnerable (CVE-2025-29927)

- CVE-2025-29927: Authorization bypass in middleware via x-middleware-subrequest header (self-hosted; Vercel/Netlify/Cloudflare not affected) (fixed in 14.2.25) https://github.com/advisories/GHSA-f82v-jwr5-mffw

**What this means:** Your site ships next@14.1.0, and that version appears vulnerable to known security issues.

**Why it matters:** Known vulnerabilities have public write-ups that attackers use. Whether your app is actually exploitable depends on how the library is used.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Upgrade next to the latest version (at least the fixed version in the report) in package.json, run the install, rebuild and redeploy. Then run 'npm audit' and fix anything else it reports.
```

**Verify:** Re-run Atoll Audit; the version shown should be the new one and the finding should disappear.

## 3. [HIGH] A process.env dump is embedded in your frontend (3 variables)

- Secret-looking variable names: DATABASE_URL

**What this means:** Your frontend contains a copy of the server's environment variables (process.env).

**Why it matters:** Server env vars usually include database passwords and API keys, and now they're public.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Rotate every secret in the listed variables. Then fix the build config so only specific public variables are exposed (Vite: import.meta.env with VITE_ prefix only; Next.js: NEXT_PUBLIC_ only; never define 'process.env' as the whole object). Redeploy.
```

**Verify:** Search the built JS for 'process.env=' or the variable names; nothing secret should remain.

## 4. [MEDIUM] Error pages show stack traces / internal file paths (seen on a harmless 404 request)


**What this means:** Your error pages show stack traces and internal file paths.

**Why it matters:** These details reveal your framework, file layout and sometimes code, helping attackers.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Configure production error handling: generic error pages for users, details only in server logs (set NODE_ENV=production / DEBUG=False; add a custom 404 and 500 page).
```

**Verify:** Open a non-existent URL on your site: you should see a simple 'Page not found' page with no code or paths.

## 5. [MEDIUM] Email confirmation is turned off: anyone can sign up with any email address, including addresses they don't own


**What this means:** Your Supabase project lets people sign up without confirming their email address.

**Why it matters:** Anyone can create accounts with someone else's email (impersonation, spam sign-ups), and any feature that trusts 'verified email' is fooled.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
In Supabase Dashboard → Authentication → Sign In / Providers → Email, turn ON 'Confirm email'. Then update my app so unconfirmed users see a 'check your inbox' screen and can't use protected features until confirmed.
```

**Verify:** Re-run Atoll Audit; the finding should disappear (it reads the public /auth/v1/settings endpoint).

## 6. [MEDIUM] Admin page '/admin' is served by your server without any login


**What this means:** Your server returns the admin page '/admin' to visitors who are not logged in.

**Why it matters:** Anyone who guesses the URL can see whatever that page shows and may be able to use admin actions.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Protect the /admin route on the server: in Next.js check the session in the page/layout server code (not only in middleware) and redirect to /login if there's no admin user; verify the user's role from the database, never from a client-side flag. Also make sure every API route used by the admin page checks the role.
```

**Verify:** Open /admin in a private browser window: you should be redirected to the login page.

## 7. [MEDIUM] This site is running a Next.js development build in production


**What this means:** Your live site is running a Next.js development build.

**Why it matters:** Dev builds are slow, show detailed errors and source code, and aren't meant to be public.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Deploy a production build: run 'next build' and serve with 'next start' (or your host's production preset), and make sure NODE_ENV=production. Never run 'next dev' on the public server.
```

**Verify:** View page source: __NEXT_DATA__ should not contain "buildId":"development".

## 8. [MEDIUM] axios 1.5.1 version appears vulnerable (CVE-2023-45857, CVE-2025-27152)

- CVE-2023-45857: XSRF-TOKEN cookie value sent to any host in X-XSRF-TOKEN header (fixed in 1.6.0) https://github.com/advisories/GHSA-wf5p-g6vw-rhxx
- CVE-2025-27152: Absolute URLs override baseURL: possible SSRF / credential leakage (fixed in 1.8.2) https://github.com/advisories/GHSA-jr5f-v2jv-69x6

**What this means:** Your site ships axios@1.5.1, and that version appears vulnerable to known security issues.

**Why it matters:** Known vulnerabilities have public write-ups that attackers use. Whether your app is actually exploitable depends on how the library is used.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Upgrade axios to the latest version (at least the fixed version in the report) in package.json, run the install, rebuild and redeploy. Then run 'npm audit' and fix anything else it reports.
```

**Verify:** Re-run Atoll Audit; the version shown should be the new one and the finding should disappear.

## 9. [LOW] Missing Content-Security-Policy header


**What this means:** No Content-Security-Policy header.

**Why it matters:** A CSP limits the damage of injected scripts (XSS).

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Add a Content-Security-Policy header in the hosting config (e.g. vercel.json or netlify.toml headers) starting with default-src 'self' and allowing only the domains my app needs (Supabase URL, fonts, analytics). Test that the app still works.
```

**Verify:** Check response headers in browser DevTools → Network → document.

## 10. [LOW] Missing clickjacking protection (X-Frame-Options or CSP frame-ancestors)


**What this means:** No clickjacking protection.

**Why it matters:** Other sites could load your app invisibly in a frame and trick users into clicking.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Add X-Frame-Options: DENY (or CSP frame-ancestors 'none') to the hosting headers config.
```

**Verify:** Check response headers in DevTools.

## 11. [LOW] Anonymous sign-ins are enabled: anonymous visitors get the 'authenticated' role, so policies written 'to authenticated' also let them in


**What this means:** Anonymous sign-ins are enabled in Supabase Auth.

**Why it matters:** Anonymous users get the 'authenticated' role, so any RLS policy written 'to authenticated' without checking auth.uid() or is_anonymous also lets strangers in.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Check every RLS policy in my Supabase project that uses 'to authenticated'. Add a condition so anonymous users are excluded where needed: (auth.jwt()->>'is_anonymous')::boolean is false. If my app doesn't need guest accounts, disable Anonymous sign-ins in Authentication → Sign In / Providers.
```

**Verify:** Re-run Atoll Audit, and test as a guest user that private data is not visible.

## 12. [LOW] No rate-limit signal on login endpoint /api/auth/login (can't confirm brute-force protection; headers may just be hidden)


**What this means:** We couldn't see any rate-limit signal on your login endpoint /api/auth/login.

**Why it matters:** Without rate limiting, attackers can try thousands of passwords or flood sign-ups and emails. (Your endpoint may still be protected without showing headers; we never brute-force to find out.)

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Add rate limiting to /api/auth/login: e.g. at most 5 attempts per minute per IP and per account, returning HTTP 429 with RateLimit-Limit/RateLimit-Remaining headers. Use a middleware or a store like Upstash Redis, or your host's firewall rules.
```

**Verify:** Check the response headers of /api/auth/login in DevTools for RateLimit-* or X-RateLimit-* headers.

## 13. [LOW] GraphQL introspection is enabled at /graphql (anyone can download your full API schema)


**What this means:** Your GraphQL API (/graphql) answers introspection queries from anyone.

**Why it matters:** Attackers can download your whole API schema, including hidden admin fields and mutations, which makes finding weaknesses easy.

**Fix prompt (paste into Lovable, Bolt, or Cursor):**

```
Disable GraphQL introspection in production (e.g. Apollo Server: introspection: process.env.NODE_ENV !== 'production'), and make sure every resolver checks authorization.
```

**Verify:** Re-run Atoll Audit; the finding should disappear.

## Notes

- Supabase anon key in frontend (expected; safe only if RLS protects every table)
- Sign-ups are open to anyone (fine for public apps; make sure RLS policies don't treat every logged-in user as trusted)
- Supabase Auth doesn't expose rate-limit headers; review Auth → Rate Limits in the dashboard (Supabase applies built-in limits)

## Tables checked

| Table | Readable without login |
|---|---|
| orders | no |
