"""Local insecure test target: static 'Lovable' site + mock Supabase + mock Firebase. ALL KEYS ARE FAKE."""
import base64, json, threading
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

def fake_jwt(role):
    b = lambda d: base64.urlsafe_b64encode(json.dumps(d).encode()).decode().rstrip("=")
    return f"{b({'alg':'HS256','typ':'JWT'})}.{b({'iss':'supabase','ref':'fakeproject','role':role,'note':'FAKE-TEST-KEY'})}.FAKEsignatureFAKEsignature"

ANON = fake_jwt("anon")
SERVICE = fake_jwt("service_role")
FAKE_KEYS = {
    "sb_secret": "sb_" + "secret_FAKEtestKEY0123456789abcdef",
    "stripe": "sk_" + "live_FAKE0000000000000000test",
    "openai": "sk-" + "proj-FAKEopenaiKEY0000000000000000test",
    "anthropic": "sk-" + "ant-api03-FAKEanthropicKEY000000000000test",
    "resend": "re" + "_FAKEresendKEY0000000000test",
    "twilio": "SK" + "f" * 30 + "aa",
    "google": "AI" + "zaFAKEgoogleKEY0000000000000000000000",
}
SENSITIVE_ROW = {"id": 1, "email": "alice@example.test", "phone": "+15550100", "password_hash": "$2b$fakehash", "stripe_customer_id": "cus_FAKE"}
TABLES = {"profiles": {"rls": False, "rows": [SENSITIVE_ROW]},
          "posts": {"rls": False, "rows": [{"id": 1, "title": "Hello public post"}]},
          "private_notes": {"rls": True, "rows": [{"id": 1, "user_id": "u1", "body": "secret note"}]}}
BUCKETS = [{"id": "avatars", "name": "avatars", "public": True}, {"id": "invoices", "name": "invoices", "public": False}]
FIRESTORE = {"public_posts": {"open": True, "fields": {"title": "x", "author_email": "bob@example.test"}},
             "admin_logs": {"open": False}}
RTDB = {"users": {"u1": {"email": "carol@example.test"}}, "config": {"x": 1}}

class State: requests = []

def _json(h, code, obj, extra=None):
    body = json.dumps(obj).encode(); h.send_response(code)
    h.send_header("Content-Type", "application/json")
    for k, v in (extra or {}).items(): h.send_header(k, v)
    h.end_headers()
    if h.command != "HEAD": h.wfile.write(body)

class _Base(BaseHTTPRequestHandler):
    tag = "?"
    def log_message(self, *a): pass
    def _rec(self): State.requests.append((self.command, f"{self.tag}:{self.path}"))
    def _deny(self): self._rec(); _json(self, 405, {"message": "write attempted"})
    do_POST = do_PUT = do_PATCH = do_DELETE = _deny

def make_api_handler():
    class H(_Base):
        tag = "api"
        def do_OPTIONS(self):
            self._rec()
            if "/functions/v1/admin-export" in self.path: return _json(self, 401, {"msg": "Missing authorization header"})
            self.send_response(204); self.send_header("Access-Control-Allow-Origin", "*"); self.end_headers()
        def do_HEAD(self): self.do_GET()
        def do_GET(self):
            self._rec(); p = urlparse(self.path); key = self.headers.get("apikey"); auth = self.headers.get("Authorization")
            cors = {"Access-Control-Allow-Origin": "*"}
            if p.path.startswith("/functions/v1/"):
                name = p.path.split("/")[3]
                if name == "send-welcome": return _json(self, 200, {"ok": True}, cors)        # no JWT check
                return _json(self, 401, {"msg": "Missing authorization header"}, cors)          # admin-export: protected
            if p.path.startswith("/storage/v1/object/public/avatars/"): return _json(self, 200, {}, cors)
            if p.path.startswith("/storage/v1/object/"): return _json(self, 400, {"error": "not found"}, cors)
            if key != ANON: return _json(self, 401, {"message": "Invalid API key"}, cors)
            if p.path == "/rest/v1/":
                return _json(self, 200, {"swagger": "2.0", "paths": {"/": {}, **{f"/{t}": {} for t in TABLES}, "/rpc/do_thing": {}}}, cors)
            if p.path.startswith("/rest/v1/"):
                t = TABLES.get(p.path[len("/rest/v1/"):])
                if not t: return _json(self, 404, {"message": "not found"}, cors)
                return _json(self, 200, [] if t["rls"] else t["rows"][:1], cors)
            if p.path == "/storage/v1/bucket": return _json(self, 200, BUCKETS, cors)
            return _json(self, 404, {}, cors)
    return H

def make_firebase_handler():
    class H(_Base):
        tag = "fb"
        def do_GET(self):
            self._rec(); p = urlparse(self.path)
            if p.path == "/.json":
                if parse_qs(p.query).get("shallow") == ["true"]: return _json(self, 200, {k: True for k in RTDB})
                return _json(self, 200, RTDB)
            if "/documents/" in p.path:
                coll = p.path.rsplit("/", 1)[1]; c = FIRESTORE.get(coll)
                if not c or not c["open"]: return _json(self, 403, {"error": {"status": "PERMISSION_DENIED"}})
                return _json(self, 200, {"documents": [{"name": f"x/{coll}/d1", "fields": {k: {"stringValue": v} for k, v in c["fields"].items()}}]})
            return _json(self, 404, {})
    return H

INDEX_HTML = '<!doctype html><html><head><script type="module" src="/assets/index-abc123.js"></script></head><body><div id="root"></div></body></html>'

def make_site_handler(api_url, fb_url, secure=False):
    k = FAKE_KEYS
    main_js = (f'import{{createClient}}from"./vendor.js";const sb=createClient("{api_url}","{ANON}");'
               f'const adminKey="{SERVICE}";const sbAdmin="{k["sb_secret"]}";const stripe="{k["stripe"]}";'
               f'const fbConfig={{apiKey:"{k["google"]}",authDomain:"fakeproj.firebaseapp.com",databaseURL:"{fb_url}",projectId:"fakeproj"}};'
               f'const avatar="{api_url}/storage/v1/object/public/avatars/u1/me.png";'
               f'const inv="{api_url}/storage/v1/object/invoices/inv-1.pdf";'
               'sb.functions.invoke("admin-export");'
               f'fetch(`{api_url}/functions/v1/send-welcome`);'
               'const Settings=()=>import("./chunk-settings-9f8e.js");'
               '//# sourceMappingURL=index-abc123.js.map')
    chunk_js = (f'const ai="{k["openai"]}";const claude="{k["anthropic"]}";const mail="{k["resend"]}";const sms="{k["twilio"]}";'
                'db.collection("public_posts");collection(db,"admin_logs");')
    files = {"/assets/index-abc123.js": (main_js, "application/javascript"),
             "/assets/vendor.js": ("export const createClient=()=>({});", "application/javascript"),
             "/assets/chunk-settings-9f8e.js": (chunk_js, "application/javascript"),
             "/assets/index-abc123.js.map": ('{"version":3,"sources":["src/App.tsx"],"mappings":"AAAA"}', "application/json"),
             "/.env": ("VITE_SUPABASE_URL=fake\nSUPABASE_SERVICE_ROLE_KEY=FAKE\n", "text/plain"),
             "/.git/HEAD": ("ref: refs/heads/main\n", "text/plain")}
    if secure:
        files = {"/assets/index-abc123.js": ("export default 1", "application/javascript")}
    class H(_Base):
        tag = "secure" if secure else "site"
        def do_HEAD(self): self.do_GET()
        def do_OPTIONS(self): self._rec(); self.send_response(204); self.end_headers()
        def do_GET(self):
            self._rec(); path = urlparse(self.path).path
            body, ct = files.get(path, (INDEX_HTML, "text/html"))  # SPA fallback for unknown paths
            self.send_response(200); self.send_header("Content-Type", ct)
            if secure:
                self.send_header("Content-Security-Policy", "default-src 'self'; frame-ancestors 'none'")
                self.send_header("Strict-Transport-Security", "max-age=63072000")
                self.send_header("X-Frame-Options", "DENY")
                self.send_header("X-Content-Type-Options", "nosniff")
                self.send_header("Access-Control-Allow-Origin", "*")  # wildcard WITHOUT credentials: fine
            else:
                origin = self.headers.get("Origin")
                if origin:
                    self.send_header("Access-Control-Allow-Origin", origin); self.send_header("Access-Control-Allow-Credentials", "true")
            self.end_headers()
            if self.command != "HEAD": self.wfile.write(body.encode())
    return H

def _serve(handler, host="127.0.0.1"):
    s = ThreadingHTTPServer((host, 0), handler); threading.Thread(target=s.serve_forever, daemon=True).start(); return s

def start():
    """Returns dict with site, secure_site, api, firebase URLs and servers. Supabase is on 'localhost' to mimic a custom domain."""
    api = _serve(make_api_handler()); fb = _serve(make_firebase_handler())
    api_url = f"http://localhost:{api.server_address[1]}"; fb_url = f"http://127.0.0.1:{fb.server_address[1]}"
    site = _serve(make_site_handler(api_url, fb_url)); sec = _serve(make_site_handler(api_url, fb_url, secure=True))
    return {"site": f"http://127.0.0.1:{site.server_address[1]}/", "secure_site": f"http://127.0.0.1:{sec.server_address[1]}/",
            "api": api_url, "firebase": fb_url, "servers": [api, fb, site, sec]}

if __name__ == "__main__":
    t = start(); print({k: v for k, v in t.items() if k != "servers"}); threading.Event().wait()
