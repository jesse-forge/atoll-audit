"""More realistic mock apps for vibe-coding failure modes. ALL KEYS, PASSWORDS AND DATA ARE FAKE.

- bolt_firebase:  'Bolt + Firebase' Vite SPA with a small Express-style backend on the same origin
- next_supabase:  'Next.js (Cursor) + Supabase on a custom domain', self-hosted, several planted issues
- next_secure:    hardened Next.js + Supabase app used as a NEGATIVE CONTROL (should produce no actionable findings)
"""
import json, threading
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from .server import fake_jwt, State
FAKE_FB_KEY = "AI" + "zaFAKEboltKEY000000000000000000000000"  # split so GitHub secret scanning does not flag this fake test value

class Route:
    def __init__(self, status=200, body="", ctype="text/html", headers=None, options_headers=None):
        self.status, self.body, self.ctype, self.headers, self.options_headers = status, body, ctype, headers or {}, options_headers

def make_site(tag, routes, fallback, base_headers=None):
    """routes: path -> Route (path may include ?query for exact matches). fallback: Route for unknown paths."""
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a): pass
        def _rec(self): State.requests.append((self.command, f"{tag}:{self.path}"))
        def _deny(self):
            self._rec(); self.send_response(405); self.end_headers()
        do_POST = do_PUT = do_PATCH = do_DELETE = _deny
        def _route(self):
            p = urlparse(self.path)
            return routes.get(self.path) or routes.get(p.path) or fallback
        def do_OPTIONS(self):
            self._rec(); r = self._route()
            self.send_response(204)
            for k, v in (r.options_headers or {}).items(): self.send_header(k, v)
            self.end_headers()
        def do_HEAD(self): self.do_GET()
        def do_GET(self):
            self._rec(); r = self._route()
            self.send_response(r.status); self.send_header("Content-Type", r.ctype)
            for k, v in {**(base_headers or {}), **r.headers}.items(): self.send_header(k, v)
            self.end_headers()
            if self.command != "HEAD": self.wfile.write(r.body.encode())
    return H

def make_supabase(tag, anon, tables, buckets, auth_settings):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a): pass
        def _rec(self): State.requests.append((self.command, f"{tag}:{self.path}"))
        def _deny(self): self._rec(); self._json(405, {"message": "write attempted"})
        do_POST = do_PUT = do_PATCH = do_DELETE = _deny
        def _json(self, code, obj):
            b = json.dumps(obj).encode(); self.send_response(code); self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*"); self.end_headers()
            if self.command != "HEAD": self.wfile.write(b)
        def do_OPTIONS(self): self._rec(); self.send_response(204); self.send_header("Access-Control-Allow-Origin", "*"); self.end_headers()
        def do_HEAD(self): self.do_GET()
        def do_GET(self):
            self._rec(); p = urlparse(self.path)
            if self.headers.get("apikey") != anon: return self._json(401, {"message": "Invalid API key"})
            if p.path == "/auth/v1/settings": return self._json(200, auth_settings)
            if p.path == "/rest/v1/": return self._json(200, {"swagger": "2.0", "paths": {"/": {}, **{f"/{t}": {} for t in tables}}})
            if p.path.startswith("/rest/v1/"):
                t = tables.get(p.path[len("/rest/v1/"):])
                if t is None: return self._json(404, {})
                return self._json(200, [] if t["rls"] else t["rows"][:1])
            if p.path == "/storage/v1/bucket": return self._json(200, buckets)
            return self._json(404, {})
    return H

def make_firebase(tag, rtdb_open, collections):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a): pass
        def _rec(self): State.requests.append((self.command, f"{tag}:{self.path}"))
        def _json(self, code, obj):
            b = json.dumps(obj).encode(); self.send_response(code); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(b)
        def do_GET(self):
            self._rec(); p = urlparse(self.path)
            if p.path == "/.json": return self._json(200, {"x": True}) if rtdb_open else self._json(401, {"error": "Permission denied"})
            if "/documents/" in p.path:
                c = collections.get(p.path.rsplit("/", 1)[1])
                if not c: return self._json(403, {"error": {"status": "PERMISSION_DENIED"}})
                return self._json(200, {"documents": [{"name": "d1", "fields": {k: {"stringValue": v} for k, v in c.items()}}]})
            return self._json(404, {})
    return H

def _serve(h):
    s = ThreadingHTTPServer(("127.0.0.1", 0), h); threading.Thread(target=s.serve_forever, daemon=True).start(); return s

JS = "application/javascript"
GOOD_HEADERS = {"Content-Security-Policy": "default-src 'self'; frame-ancestors 'none'", "X-Frame-Options": "DENY", "X-Content-Type-Options": "nosniff"}

# ---------------------------------------------------------------- Bolt + Firebase
BOLT_ROW = {"customer_email": "dana@example.test", "total": "42.00"}
def bolt_firebase():
    fb = _serve(make_firebase("boltfb", rtdb_open=False, collections={"orders": BOLT_ROW}))
    fb_url = f"http://127.0.0.1:{fb.server_address[1]}"
    index = ('<!doctype html><html><head><meta name="generator" content="bolt.new"><title>Bolt Shop</title>'
             '<script>window.__ENV__={"VITE_FIREBASE_PROJECT":"boltfake","ADMIN_PASSWORD":"FAKEadminPass123"};</script>'
             '<script type="module" src="/assets/index-B0ltA1.js"></script></head><body><div id="root"></div></body></html>')
    js = ('/*! jQuery v3.7.1 | (c) OpenJS Foundation and other contributors | jquery.org/license */\n'
          '/** @license Lodash lodash.com/license */ var VERSION="4.17.15",HASH_UNDEFINED="__lodash_hash_undefined__";\n'
          'var rd={bundleType:0,version:"18.2.0",rendererPackageName:"react-dom"};\n'
          'const env={VITE_PUBLIC_SITE_NAME:"Bolt Shop",VITE_FIREBASE_API_KEY:"' + FAKE_FB_KEY + '",VITE_STRIPE_SECRET_KEY:"FAKEstripeLikeValue12345"};\n'
          f'const firebaseConfig={{apiKey:"{FAKE_FB_KEY}",authDomain:"boltfake.firebaseapp.com",databaseURL:"{fb_url}",projectId:"boltfake"}};\n'
          'collection(db,"orders");collection(db,"admin_settings");\n'
          'const routes=[{path:"/",element:Home},{path:"/admin",element:AdminPanel}];\n'
          'fetch("/api/login",{method:"POST"});\n')
    routes = {"/assets/index-B0ltA1.js": Route(body=js, ctype=JS),
              "/api/debug": Route(body=json.dumps({"debug": True, "env": {"NODE_ENV": "production", "STRIPE_SECRET": "FAKEsecretVALUE"}}), ctype="application/json"),
              "/api/login": Route(status=405, body='{"error":"Method not allowed"}', ctype="application/json")}
    site = _serve(make_site("bolt", routes, Route(body=index)))
    return {"site": f"http://127.0.0.1:{site.server_address[1]}/", "firebase": fb_url, "servers": [fb, site]}

# ---------------------------------------------------------------- Next.js (Cursor) + Supabase custom domain
NEXT_ANON = fake_jwt("anon").replace("fakeproject", "nextproj")
NEXT_ROW = {"id": 7, "owner_email": "erin@example.test"}
STACK_404 = ('<!DOCTYPE html><html><head><title>404: This page could not be found</title></head><body><pre>Error: ENOENT: no such file or directory\n'
             '    at Object.openSync (node:fs:601:3)\n    at NextNodeServer.render404 (/app/node_modules/next/dist/server/base-server.js:1203:15)\n</pre></body></html>')
def next_supabase():
    api = _serve(make_supabase("nextapi", NEXT_ANON, {"orders": {"rls": True, "rows": [NEXT_ROW]}}, [],
                               {"external": {"email": True, "phone": False, "anonymous_users": True}, "disable_signup": False, "mailer_autoconfirm": True, "phone_autoconfirm": False}))
    api_url = f"http://localhost:{api.server_address[1]}"  # custom domain stand-in (not *.supabase.co)
    index = ('<!DOCTYPE html><html><head><title>Cursor SaaS</title><script src="/_next/static/chunks/main-app-9a8b.js" async></script>'
             '<script src="/_next/static/chunks/app/page-7c6d.js" async></script></head><body><div id="__next"></div>'
             '<script id="__NEXT_DATA__" type="application/json">{"props":{"pageProps":{}},"page":"/","buildId":"development"}</script></body></html>')
    main = ('window.next={version:"14.1.0",appDir:!0};\n/*! Axios v1.5.1 Copyright (c) 2023 Matt Zabriskie and contributors */\n'
            'var r={bundleType:0,version:"18.2.0",rendererPackageName:"react-dom"};\n')
    page = (f'const supabase=createClient("{api_url}","{NEXT_ANON}");\n'
            f'const cfg={{NEXT_PUBLIC_SUPABASE_URL:"{api_url}",NEXT_PUBLIC_SITE_NAME:"Cursor SaaS"}};\n'
            'process.env={"NODE_ENV":"production","DATABASE_URL":"postgres://app:FAKEdbPass99@db.internal.example:5432/app","NEXT_PUBLIC_SITE_URL":"https://saas.example"};\n'
            'const nav=[{href:"/admin"},{href:"/internal/reports"}];\n'
            'fetch("/api/auth/login",{method:"POST"});fetch("/api/auth/signup",{method:"POST"});\n')
    rl = {"RateLimit-Limit": "5", "RateLimit-Remaining": "5", "RateLimit-Reset": "60"}
    routes = {"/": Route(body=index),
              "/_next/static/chunks/main-app-9a8b.js": Route(body=main, ctype=JS),
              "/_next/static/chunks/app/page-7c6d.js": Route(body=page, ctype=JS),
              "/_next/static/development/_buildManifest.js": Route(body="self.__BUILD_MANIFEST={};self.__BUILD_MANIFEST_CB&&self.__BUILD_MANIFEST_CB()", ctype=JS),
              "/admin": Route(body="<!DOCTYPE html><html><head><title>Admin Dashboard</title></head><body><h1>Users</h1><table><tr><td>…</td></tr></table></body></html>"),
              "/internal/reports": Route(status=307, headers={"Location": "/login?next=%2Finternal%2Freports"}),
              "/graphql": Route(body=json.dumps({"data": {"__schema": {"queryType": {"name": "Query"}}}}), ctype="application/json"),
              "/api/auth/login": Route(status=405, body="{}", ctype="application/json"),
              "/api/auth/signup": Route(status=405, body="{}", ctype="application/json", headers=rl, options_headers=rl)}
    site = _serve(make_site("next", routes, Route(status=404, body=STACK_404), base_headers={"X-Powered-By": "Next.js"}))
    return {"site": f"http://127.0.0.1:{site.server_address[1]}/", "api": api_url, "servers": [api, site]}

# ---------------------------------------------------------------- hardened Next.js + Supabase (negative control)
SECURE_ANON = fake_jwt("anon").replace("fakeproject", "secureproj")
def next_secure():
    api = _serve(make_supabase("secapi", SECURE_ANON, {"profiles": {"rls": True, "rows": [{"email": "x@example.test"}]}},
                               [{"id": "avatars", "name": "avatars", "public": False}],
                               {"external": {"email": True, "anonymous_users": False}, "disable_signup": False, "mailer_autoconfirm": False}))
    api_url = f"http://localhost:{api.server_address[1]}"
    index = ('<!DOCTYPE html><html><head><title>Secure SaaS</title><script src="/_next/static/chunks/main-app-1111.js" async></script>'
             '<script>window.__ENV__={"NEXT_PUBLIC_SUPABASE_URL":"' + api_url + '","NEXT_PUBLIC_SUPABASE_ANON_KEY":"' + SECURE_ANON + '"};</script>'
             '</head><body><div id="__next"></div><script id="__NEXT_DATA__" type="application/json">{"props":{},"page":"/","buildId":"a1B2c3D4"}</script></body></html>')
    main = ('window.next={version:"14.2.30",appDir:!0};\n/*! Axios v1.12.0 Copyright (c) 2025 Matt Zabriskie and contributors */\n'
            '/** @license Lodash lodash.com/license */ var VERSION="4.17.21",H="__lodash_hash_undefined__";\n'
            'var r={bundleType:0,version:"19.2.1",rendererPackageName:"react-dom"};\n'
            f'const supabase=createClient("{api_url}",window.__ENV__.NEXT_PUBLIC_SUPABASE_ANON_KEY);\n'
            'const cfg={NEXT_PUBLIC_TOKEN_REFRESH_MS:"undefined"};\n'
            'fetch("/api/auth/login",{method:"POST"});\n')
    rl = {"RateLimit-Limit": "5", "RateLimit-Remaining": "5", "RateLimit-Reset": "60"}
    routes = {"/": Route(body=index), "/_next/static/chunks/main-app-1111.js": Route(body=main, ctype=JS),
              "/graphql": Route(status=400, body=json.dumps({"errors": [{"message": "GraphQL introspection is not allowed"}]}), ctype="application/json"),
              "/api/auth/login": Route(status=405, body="{}", ctype="application/json", headers=rl, options_headers=rl)}
    site = _serve(make_site("secure-next", routes, Route(status=404, body="<!DOCTYPE html><html><body><h1>404</h1><p>This page could not be found.</p></body></html>"),
                            base_headers=GOOD_HEADERS))
    return {"site": f"http://127.0.0.1:{site.server_address[1]}/", "api": api_url, "servers": [api, site]}

# ---------------------------------------------------------------- legacy host (Replit/VPS style) with classic debug leftovers
def legacy_host():
    index = '<!doctype html><html><head><title>Old App</title><script type="module" src="/assets/app.js"></script></head><body></body></html>'
    routes = {"/assets/app.js": Route(body="console.log('replit.app demo')", ctype=JS),
              "/phpinfo.php": Route(body="<html><head><title>PHP 8.1.2 - phpinfo()</title></head><body>PHP Version 8.1.2 ... FAKE</body></html>"),
              "/server-status": Route(body="<html><head><title>Apache Status</title></head><body><h1>Apache Server Status for localhost</h1></body></html>"),
              "/actuator": Route(body=json.dumps({"_links": {"self": {"href": "/actuator"}, "health": {"href": "/actuator/health"}, "env": {"href": "/actuator/env"}}}), ctype="application/json"),
              "/swagger-ui.html": Route(body="<html><head><title>Swagger UI</title></head><body><div id=swagger-ui></div></body></html>"),
              "/@vite/client": Route(body="import.meta.hot; console.debug('[vite] connecting...')", ctype=JS)}
    site = _serve(make_site("legacy", routes, Route(body=index)))
    return {"site": f"http://127.0.0.1:{site.server_address[1]}/", "servers": [site]}
