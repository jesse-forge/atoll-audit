"""Local MOCK of the Supabase Management API query endpoints. Never contacts real Supabase.
Applies a tiny subset of SQL to the shared in-memory state of testtarget.server (TABLES / BUCKETS) so re-scans can verify fixes."""
import json, re, threading
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from . import server

FAKE_TOKEN = "sbp_FAKEtestTOKEN0000000000000000000000"

class MgmtState:
    calls = []   # (path, sql)
    fail_writes = False

def make_handler(ref):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a): pass
        def _json(self, code, obj):
            b = json.dumps(obj).encode(); self.send_response(code); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(b)
        def do_GET(self): self._json(405, {"message": "GET not supported in mock"})
        def do_POST(self):
            if self.headers.get("Authorization") != f"Bearer {FAKE_TOKEN}": return self._json(401, {"message": "Unauthorized"})
            m = re.fullmatch(rf"/v1/projects/{ref}/(database/query(?:/read-only)?)", self.path)
            if not m: return self._json(404, {"message": "not found"})
            sql = json.loads(self.rfile.read(int(self.headers.get("Content-Length") or 0)) or b"{}").get("query", "")
            MgmtState.calls.append((m.group(1), sql))
            if m.group(1).endswith("read-only"):
                if re.match(r"\s*(select)\b", sql, re.I) is None: return self._json(400, {"message": "read-only endpoint"})
                t = re.search(r"c\.relname = '([^']+)'", sql); b = re.search(r"storage\.buckets where id = '([^']+)'", sql)
                if t and t.group(1) in server.TABLES: return self._json(201, [{"rls_enabled": server.TABLES[t.group(1)]["rls"], "policy_count": 0}])
                if b: return self._json(201, [{"id": x["id"], "public": x["public"]} for x in server.BUCKETS if x["id"] == b.group(1)])
                return self._json(201, [])
            if MgmtState.fail_writes: return self._json(500, {"message": "simulated failure"})
            mm = re.fullmatch(r'alter table public\."([^"]+)" (enable|disable) row level security;', sql.strip())
            if mm and mm.group(1) in server.TABLES:
                server.TABLES[mm.group(1)]["rls"] = mm.group(2) == "enable"; return self._json(201, [])
            mm = re.fullmatch(r"update storage\.buckets set public = (true|false) where id = '([^']+)';", sql.strip())
            if mm:
                for x in server.BUCKETS:
                    if x["id"] == mm.group(2): x["public"] = mm.group(1) == "true"
                return self._json(201, [])
            return self._json(400, {"message": "mock does not understand this SQL"})
    return H

def start(ref="fakeprojectref"):
    s = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(ref)); threading.Thread(target=s.serve_forever, daemon=True).start()
    return f"http://127.0.0.1:{s.server_address[1]}", s
