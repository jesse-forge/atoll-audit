import argparse, json, sys, pathlib
from .scanner import scan, Client
from .report import to_markdown, to_html

SUBCOMMANDS = {"remediate": "remediate", "fulfill": "fulfill"}

def main(argv=None, firestore_base="https://firestore.googleapis.com"):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] in SUBCOMMANDS:
        import importlib
        return importlib.import_module(f".{SUBCOMMANDS[argv[0]]}", __package__).main(argv[1:])
    ap = argparse.ArgumentParser(prog="atoll-audit", description="Read-only security check for apps YOU own.")
    ap.add_argument("url")
    ap.add_argument("--i-own-this-app", action="store_true", help="Required: confirm you own or are authorized to test this app.")
    ap.add_argument("--out", default="reports", help="Output directory")
    ap.add_argument("--delay", type=float, default=0.2, help="Seconds between requests (rate limit)")
    ap.add_argument("--allow-function-invocation", action="store_true",
                    help="DANGEROUS opt-in: send GET requests to Edge Functions without auth. This may EXECUTE them (send emails, call paid APIs).")
    a = ap.parse_args(argv)
    if not a.i_own_this_app:
        print("Refusing to scan: pass --i-own-this-app to confirm you own or are authorized to test this app.", file=sys.stderr)
        return 2
    if a.allow_function_invocation:
        print("WARNING: --allow-function-invocation sends GET requests to your Edge Functions. This may execute them "
              "(e.g. send emails, charge APIs). Only use on your own app, ideally a staging copy.", file=sys.stderr)
    res = scan(a.url, Client(delay=a.delay), firestore_base=firestore_base, allow_function_invocation=a.allow_function_invocation)
    out = pathlib.Path(a.out); out.mkdir(parents=True, exist_ok=True)
    (out / "result.json").write_text(json.dumps(res, indent=2))
    (out / "report.md").write_text(to_markdown(res))
    (out / "report.html").write_text(to_html(res))
    serious = res["counts"]["critical"] + res["counts"]["high"]
    print(f"Grade {res['grade']}: {res['counts']}. Wrote result.json, report.md, report.html to {out}")
    return 1 if serious else 0

if __name__ == "__main__":
    sys.exit(main())
