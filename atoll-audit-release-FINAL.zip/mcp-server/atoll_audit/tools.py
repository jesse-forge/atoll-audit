"""Shared tool implementations used by the MCP server and the local HTTP API."""
import os
from .scanner import Client
from .verify import triple_check
from .report import explain, CATALOG
from . import leaks

SAFE_INFO = ("supabase_url", "tables", "buckets", "functions", "firebase", "libraries", "auth_settings", "admin_routes", "rate_limit_checks", "headers")

class ToolError(Exception): pass

def _with_prompt(f):
    what, why, prompt, verify = explain(f)
    return {**f, "what_it_means": what, "why_it_matters": why, "fix_prompt": prompt, "verify": verify}

def scan_app(url, i_own_this_app=False, **_ignored):
    """Triple-checked read-only scan. Function invocation is never allowed from tools."""
    if i_own_this_app is not True:
        raise ToolError("Refusing to scan: set i_own_this_app=true only if you own this app or have the owner's permission to test it.")
    if not isinstance(url, str) or not url.lower().startswith(("http://", "https://")):
        raise ToolError("url must be a full http(s) URL")
    delay = float(os.environ.get("ATOLL_DELAY", "0.2"))
    fs = os.environ.get("ATOLL_FIRESTORE_BASE", "https://firestore.googleapis.com")
    res = triple_check(url, client_factory=lambda: Client(delay=delay), allow_function_invocation=False, firestore_base=fs)
    confirmed = [_with_prompt(f) for f in res["findings"] if not f.get("suspected") and f["severity"] not in ("info", "error")]
    notes = [{"id": f["id"], "title": f["title"]} for f in res["findings"] if f["severity"] in ("info", "error") and not f.get("suspected")]
    return {"target": url, "grade": res["grade"], "counts": res["counts"], "confirmed": confirmed, "suspected": res["suspected"], "notes": notes,
            "verification": res["verification"], "info": {k: res["info"].get(k) for k in SAFE_INFO}, "requests_made": len(res["requests"]),
            "disclaimer": "Automated read-only check; not a penetration test. Keys are masked and row values are never returned."}

def check_code_for_leaks(code):
    if not isinstance(code, str): raise ToolError("code must be a string")
    return leaks.check_code(code)

def get_fix_prompt(finding_id, context=None):
    context = context or {}
    leak_ids = {r[0] for r in leaks.RULES} | {"supabase_service_role", "supabase_anon_key", "supabase_publishable_key", "public_env_secret"}
    if finding_id in leak_ids:
        label = next((r[1] for r in leaks.RULES if r[0] == finding_id), finding_id.replace("_", " "))
        return {"finding_id": finding_id, "fix_prompt": leaks.fix_for(finding_id, label)}
    if finding_id not in CATALOG and not finding_id.endswith("-exposed"):
        raise ToolError(f"Unknown finding id '{finding_id}'. Known: {', '.join(sorted(CATALOG))}")
    f = {"id": finding_id, "title": finding_id, "key_type": context.get("key_type") or (finding_id[:-8].replace("-", " ") + " key" if finding_id.endswith("-exposed") else ""), **context}
    what, why, prompt, verify = explain(f)
    return {"finding_id": finding_id, "what_it_means": what, "why_it_matters": why, "fix_prompt": prompt, "verify": verify}
