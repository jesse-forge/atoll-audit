"""Atoll Audit MCP server (stdio transport, stdlib-only JSON-RPC 2.0; no SDK needed).

    python3 -m atoll_audit.mcp_server

Tools: scan_app, check_code_for_leaks, get_fix_prompt. Messages are newline-delimited JSON on stdin/stdout;
logs go to stderr. Scans are read-only, triple-checked, and never invoke the app's server functions."""
import json, sys, traceback
from . import tools

PROTOCOL_VERSIONS = ("2025-06-18", "2025-03-26", "2024-11-05")
SERVER_INFO = {"name": "atoll-audit", "title": "Atoll Audit security scanner", "version": "0.3"}
INSTRUCTIONS = ("Read-only security checks for apps built with AI coding tools. Only call scan_app for apps the user owns or is authorized "
                "to test, and ask the user to confirm ownership before setting i_own_this_app=true. Findings contain masked keys only.")

TOOLS = [
    {"name": "scan_app", "title": "Scan a live app (read-only, triple-checked)",
     "description": "Run Atoll Audit's read-only scan on a live web app the user OWNS: leaked keys, Supabase RLS/storage, Firebase rules, auth settings, "
                    "admin/debug endpoints, vulnerable libraries, exposed env vars, headers. Runs two independent scans plus a safety audit; returns confirmed "
                    "and suspected findings with fix prompts, plus a grade. Refuses unless i_own_this_app is true. Never invokes server functions.",
     "inputSchema": {"type": "object", "properties": {
         "url": {"type": "string", "description": "Full URL of the deployed app, e.g. https://my-app.lovable.app"},
         "i_own_this_app": {"type": "boolean", "description": "Must be true: the user confirmed they own the app or have permission to test it."}},
         "required": ["url", "i_own_this_app"], "additionalProperties": False},
     "annotations": {"readOnlyHint": True, "destructiveHint": False, "openWorldHint": True}},
    {"name": "check_code_for_leaks", "title": "Check code for leaked secret keys (local)",
     "description": "Scan pasted source code, a JS bundle, or a .env file for leaked secret keys (Supabase service_role/secret, Stripe, OpenAI, Anthropic, "
                    "Resend, Twilio, SendGrid, AWS, GitHub, Slack, private keys, secret-looking VITE_/NEXT_PUBLIC_/REACT_APP_ vars). Runs locally; returns masked findings.",
     "inputSchema": {"type": "object", "properties": {"code": {"type": "string", "description": "The code or bundle text to check"}}, "required": ["code"], "additionalProperties": False},
     "annotations": {"readOnlyHint": True, "destructiveHint": False, "openWorldHint": False}},
    {"name": "get_fix_prompt", "title": "Get the fix prompt for a finding",
     "description": "Return the plain-English explanation and copy-paste fix prompt for a finding id (e.g. table-readable-sensitive, public-storage-bucket, "
                    "stripe_secret_key, vulnerable-library). Optional context fills in names (table, bucket, route, library, variable, path).",
     "inputSchema": {"type": "object", "properties": {"finding_id": {"type": "string"},
         "context": {"type": "object", "description": "Optional fields such as table, bucket, route, library, variable, path", "additionalProperties": {"type": "string"}}},
         "required": ["finding_id"], "additionalProperties": False},
     "annotations": {"readOnlyHint": True, "destructiveHint": False, "openWorldHint": False}},
]

def _call(name, args):
    if name == "scan_app": return tools.scan_app(args.get("url"), args.get("i_own_this_app") is True)
    if name == "check_code_for_leaks": return tools.check_code_for_leaks(args.get("code"))
    if name == "get_fix_prompt": return tools.get_fix_prompt(args.get("finding_id", ""), args.get("context"))
    raise KeyError(name)

def handle(msg):
    """Return a response dict, or None for notifications."""
    mid, method, params = msg.get("id"), msg.get("method"), msg.get("params") or {}
    is_note = "id" not in msg
    def ok(result): return None if is_note else {"jsonrpc": "2.0", "id": mid, "result": result}
    def err(code, text): return None if is_note else {"jsonrpc": "2.0", "id": mid, "error": {"code": code, "message": text}}
    if method == "initialize":
        req = params.get("protocolVersion")
        return ok({"protocolVersion": req if req in PROTOCOL_VERSIONS else PROTOCOL_VERSIONS[0], "capabilities": {"tools": {"listChanged": False}},
                   "serverInfo": SERVER_INFO, "instructions": INSTRUCTIONS})
    if method in ("notifications/initialized", "notifications/cancelled"): return None
    if method == "ping": return ok({})
    if method == "tools/list": return ok({"tools": TOOLS})
    if method == "tools/call":
        name, args = params.get("name"), params.get("arguments") or {}
        if name not in {t["name"] for t in TOOLS}: return err(-32602, f"Unknown tool: {name}")
        try:
            data = _call(name, args)
            return ok({"content": [{"type": "text", "text": json.dumps(data, indent=1)}], "structuredContent": data, "isError": False})
        except tools.ToolError as e:
            return ok({"content": [{"type": "text", "text": str(e)}], "isError": True})
        except Exception as e:
            traceback.print_exc(file=sys.stderr)
            return ok({"content": [{"type": "text", "text": f"Internal error: {type(e).__name__}"}], "isError": True})
    return err(-32601, f"Method not found: {method}")

def serve(stdin=sys.stdin, stdout=sys.stdout):
    for line in stdin:
        line = line.strip()
        if not line: continue
        try: msg = json.loads(line)
        except ValueError:
            stdout.write(json.dumps({"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Parse error"}}) + "\n"); stdout.flush(); continue
        msgs = msg if isinstance(msg, list) else [msg]
        out = [r for r in (handle(m) for m in msgs if isinstance(m, dict)) if r is not None]
        if out:
            stdout.write(json.dumps(out if isinstance(msg, list) else out[0]) + "\n"); stdout.flush()

if __name__ == "__main__":
    serve()
