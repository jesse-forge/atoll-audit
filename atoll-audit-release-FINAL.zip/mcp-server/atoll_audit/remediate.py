"""Atoll Audit fix-it layer v1 (Supabase only).

    python3 -m atoll_audit.remediate reports/myapp/result.json --project-ref abcd1234            # DRY RUN (default): changes nothing
    SUPABASE_ACCESS_TOKEN=... python3 -m atoll_audit.remediate result.json --project-ref abcd1234 --apply

Automatable "close the door" fixes, each needing its own interactive approval:
  * enable Row Level Security (default-deny: no new policies) on tables flagged as readable by anyone
  * make flagged storage buckets private
Draft-only outputs (NEVER executed): per-user RLS policy SQL and a key-rotation checklist.

Execution goes only through the Supabase Management API:
  snapshot  POST /v1/projects/{ref}/database/query/read-only   (current RLS flag / policies / bucket flag)
  change    POST /v1/projects/{ref}/database/query             (one statement per approved fix)
Then the app is re-scanned to verify the finding is gone; if not, a rollback is offered (also needs approval).
Every step is written to an append-only, hash-chained JSONL audit log. The token is never logged."""
import argparse, datetime, hashlib, json, os, pathlib, re, sys, urllib.request, urllib.error, urllib.parse

DEFAULT_API = "https://api.supabase.com"
TABLE_FINDINGS = ("table-readable-sensitive", "table-readable-by-anon")
KEY_FINDINGS = {"service-role-key-exposed": "Supabase service_role key", "supabase-secret-key-exposed": "Supabase secret key (sb_secret_)",
                "database-url-exposed": "Database password (connection string)"}

# ---------------------------------------------------------------- SQL helpers
def qident(name):
    if not isinstance(name, str) or not name or "\x00" in name: raise ValueError("bad identifier")
    return '"' + name.replace('"', '""') + '"'
def qlit(s): return "'" + str(s).replace("'", "''") + "'"

# ---------------------------------------------------------------- audit log (append-only, hash-chained)
class AuditLog:
    def __init__(self, path):
        self.path = pathlib.Path(path); self.path.parent.mkdir(parents=True, exist_ok=True)
        self.prev = "0" * 64
        if self.path.exists():
            lines = [l for l in self.path.read_text().splitlines() if l.strip()]
            if lines: self.prev = json.loads(lines[-1])["hash"]
    def write(self, event, **data):
        entry = {"ts": datetime.datetime.now(datetime.timezone.utc).isoformat(), "event": event, "data": _redact(data), "prev_hash": self.prev}
        entry["hash"] = hashlib.sha256((self.prev + json.dumps({k: entry[k] for k in ("ts", "event", "data", "prev_hash")}, sort_keys=True)).encode()).hexdigest()
        with open(self.path, "a") as f: f.write(json.dumps(entry, sort_keys=True) + "\n")
        self.prev = entry["hash"]; return entry

def verify_log(path):
    """Return (ok, problem). Detects edited, reordered or deleted entries."""
    prev = "0" * 64
    for i, line in enumerate(l for l in pathlib.Path(path).read_text().splitlines() if l.strip()):
        e = json.loads(line)
        if e.get("prev_hash") != prev: return False, f"entry {i}: chain broken"
        h = hashlib.sha256((prev + json.dumps({k: e[k] for k in ("ts", "event", "data", "prev_hash")}, sort_keys=True)).encode()).hexdigest()
        if h != e.get("hash"): return False, f"entry {i}: hash mismatch (edited)"
        prev = h
    return True, ""

def _redact(o):
    if isinstance(o, dict): return {k: ("[redacted]" if re.search(r"token|authorization|secret|password", k, re.I) else _redact(v)) for k, v in o.items()}
    if isinstance(o, list): return [_redact(v) for v in o]
    if isinstance(o, str): return re.sub(r"sbp_[A-Za-z0-9]+|Bearer\s+\S+", "[redacted]", o)
    return o

# ---------------------------------------------------------------- planning
def plan_fixes(result):
    plans = []
    for f in result.get("findings", []):
        if f.get("suspected"): continue
        if f["id"] in TABLE_FINDINGS and f.get("table"):
            t = f["table"]; ref = f"public.{qident(t)}"
            plans.append({"fix_id": f"rls:{t}", "kind": "enable_rls", "target": t, "finding_id": f["id"], "severity": f["severity"],
                "summary": f"Enable Row Level Security on table '{t}' (default-deny: no new policies)",
                "sql": f"alter table {ref} enable row level security;",
                "rollback_sql": f"alter table {ref} disable row level security;",
                "snapshot_sql": (f"select c.relrowsecurity as rls_enabled, (select count(*) from pg_policies p where p.schemaname = 'public' and p.tablename = {qlit(t)}) as policy_count "
                                 f"from pg_class c join pg_namespace n on n.oid = c.relnamespace where n.nspname = 'public' and c.relname = {qlit(t)};"),
                "risk": "Pages that read this table without a matching policy will show no data until per-user policies are added (see drafts/policies.sql). Existing policies on the table, if any, start applying immediately.",
                "verify": f"Re-scan: table '{t}' must no longer be readable with the anon key."})
        elif f["id"] == "public-storage-bucket" and f.get("bucket"):
            b = f["bucket"]
            plans.append({"fix_id": f"bucket:{b}", "kind": "make_bucket_private", "target": b, "finding_id": f["id"], "severity": f["severity"],
                "summary": f"Make storage bucket '{b}' private",
                "sql": f"update storage.buckets set public = false where id = {qlit(b)};",
                "rollback_sql": f"update storage.buckets set public = true where id = {qlit(b)};",
                "snapshot_sql": f"select id, public from storage.buckets where id = {qlit(b)};",
                "risk": "Public links to files in this bucket (e.g. avatars, logos in <img> tags) stop working; the app must use signed URLs instead.",
                "verify": f"Re-scan: bucket '{b}' must no longer be listed as public."})
    return plans

def draft_policies(result):
    out = ["-- DRAFT ONLY. Atoll Audit never runs this file. Review with someone who knows the app, then test as two different users.",
           "-- Pattern: each user may only see and change their own rows. Adjust the owner column and add rules for shared/public rows.", ""]
    tables = {t["table"]: t for t in result.get("info", {}).get("tables", [])}
    for f in result.get("findings", []):
        if f["id"] not in TABLE_FINDINGS or not f.get("table"): continue
        t = f["table"]; cols = tables.get(t, {}).get("columns") or f.get("columns") or []
        owner = next((c for c in ("user_id", "owner_id", "profile_id", "author_id", "created_by") if c in cols), "id" if t in ("profiles", "users") else None)
        ref = f"public.{qident(t)}"
        out.append(f"-- Table {t} (columns seen: {', '.join(cols) or 'unknown'})")
        if owner is None:
            out += [f"-- No obvious owner column. Decide who may read {t}; if it is truly public content, a read-only policy is:",
                    f"-- create policy \"Public read\" on {ref} for select to anon, authenticated using (true);", ""]
            continue
        cond = f"(select auth.uid()) = {qident(owner)}"
        out += [f"create policy \"Own rows: select\" on {ref} for select to authenticated using ({cond});",
                f"create policy \"Own rows: insert\" on {ref} for insert to authenticated with check ({cond});",
                f"create policy \"Own rows: update\" on {ref} for update to authenticated using ({cond}) with check ({cond});",
                f"create policy \"Own rows: delete\" on {ref} for delete to authenticated using ({cond});", ""]
    return "\n".join(out)

def draft_key_checklist(result):
    hits = [f for f in result.get("findings", []) if f["id"] in KEY_FINDINGS or (f["id"].endswith("-exposed") and f.get("key_type"))]
    if not hits: return "# Key rotation checklist (DRAFT)\n\nNo exposed secret keys in this scan.\n"
    L = ["# Key rotation checklist (DRAFT: instructions only, nothing is changed automatically)", "",
         "Order matters: create the new key → update every place that uses it → deploy → only then disable the old key.", ""]
    for f in hits:
        label = KEY_FINDINGS.get(f["id"]) or f.get("key_type")
        L += [f"## {label} (masked: `{f.get('key', '…')}`)", ""]
        if f["id"] in ("service-role-key-exposed", "supabase-secret-key-exposed"):
            L += ["- [ ] Supabase Dashboard → Project Settings → API Keys: create a new secret key.",
                  "- [ ] Update it in Edge Function secrets, server env vars, cron jobs and CI. Never in VITE_/NEXT_PUBLIC_ vars.",
                  "- [ ] Remove the old key from frontend code and redeploy; re-run Atoll Audit to confirm it's gone from the bundle.",
                  "- [ ] Disable the legacy service_role key / delete the old secret key. ⚠️ Deleting a new-style secret key cannot be undone.",
                  "- [ ] Review Database → logs for unexpected activity while the key was public."]
        elif f["id"] == "database-url-exposed":
            L += ["- [ ] Project Settings → Database → Reset database password.", "- [ ] Update server-side connection strings; remove it from frontend code; redeploy."]
        else:
            L += [f"- [ ] In the provider's dashboard, create a new {label} and update server-side secrets.",
                  "- [ ] Remove the key from frontend code, move calls into a server function that checks login, redeploy.",
                  "- [ ] Revoke the old key; check the provider's usage/billing logs for abuse."]
        L.append("")
    return "\n".join(L)

# ---------------------------------------------------------------- Management API client (POST only to the two query endpoints)
class ManagementAPI:
    def __init__(self, base, ref, token, timeout=20):
        if not re.fullmatch(r"[a-z0-9]{6,40}", ref or ""): raise ValueError("invalid project ref")
        self.base, self.ref, self._token, self.timeout = base.rstrip("/"), ref, token, timeout
    def _post(self, path, sql):
        assert path in ("database/query", "database/query/read-only")
        req = urllib.request.Request(f"{self.base}/v1/projects/{self.ref}/{path}", method="POST", data=json.dumps({"query": sql}).encode(),
                                     headers={"Authorization": f"Bearer {self._token}", "Content-Type": "application/json", "User-Agent": "AtollAudit-remediate/0.1"})
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r: return r.status, json.loads(r.read() or b"null")
        except urllib.error.HTTPError as e:
            try: body = json.loads(e.read() or b"null")
            except ValueError: body = None
            return e.code, body
    def read(self, sql): return self._post("database/query/read-only", sql)
    def write(self, sql): return self._post("database/query", sql)

# ---------------------------------------------------------------- run
def _show(plan, out):
    out(f"\n[{plan['fix_id']}] {plan['summary']}  (finding: {plan['finding_id']}, {plan['severity']})")
    out(f"  Change  : {plan['sql']}"); out(f"  Rollback: {plan['rollback_sql']}"); out(f"  Risk    : {plan['risk']}"); out(f"  Verify  : {plan['verify']}")

def _still_present(plan, rescan_result):
    for f in rescan_result.get("findings", []):
        if f["id"] == plan["finding_id"] and (f.get("table") == plan["target"] or f.get("bucket") == plan["target"]): return True
    return False

def run(result, project_ref, apply=False, api_base=DEFAULT_API, token_env="SUPABASE_ACCESS_TOKEN", log_path="remediation-audit.jsonl",
        drafts_dir="drafts", input_fn=input, out=print, rescan_fn=None):
    log = AuditLog(log_path)
    plans = plan_fixes(result)
    d = pathlib.Path(drafts_dir); d.mkdir(parents=True, exist_ok=True)
    (d / "policies.sql").write_text(draft_policies(result)); (d / "key-rotation-checklist.md").write_text(draft_key_checklist(result))
    log.write("session_start", mode="apply" if apply else "dry-run", target=result.get("info", {}).get("target"), project_ref=project_ref, plan_count=len(plans))
    out(f"Atoll Audit fix-it ({'APPLY' if apply else 'DRY RUN: nothing will be changed'}) · project {project_ref} · {len(plans)} proposed fix(es)")
    out(f"Draft-only files (never executed): {d / 'policies.sql'}, {d / 'key-rotation-checklist.md'}")
    for p in plans: log.write("plan", **{k: p[k] for k in ("fix_id", "kind", "target", "finding_id", "sql", "rollback_sql")})
    summary = {"plans": plans, "applied": [], "skipped": [], "rolled_back": [], "failed": [], "mode": "apply" if apply else "dry-run"}
    if not apply:
        for p in plans: _show(p, out)
        out("\nDry run complete. Re-run with --apply (and SUPABASE_ACCESS_TOKEN set) to apply fixes one at a time with approval.")
        log.write("session_end", **{k: len(v) for k, v in summary.items() if isinstance(v, list)}); return summary
    token = os.environ.get(token_env)
    if not token:
        out(f"Refusing to apply: set the {token_env} environment variable (a scoped Supabase access token)."); log.write("session_end", error="no token"); summary["error"] = "no token"; return summary
    api = ManagementAPI(api_base, project_ref, token)
    for p in plans:
        _show(p, out)
        st, snap = api.read(p["snapshot_sql"])
        log.write("snapshot", fix_id=p["fix_id"], status=st, before=snap)
        if st not in (200, 201):
            out(f"  Could not read current state (HTTP {st}); skipping."); summary["failed"].append(p["fix_id"]); continue
        out(f"  Current : {json.dumps(snap)}")
        ans = input_fn(f"  Type APPLY {p['fix_id']} to apply this fix, anything else to skip: ").strip()
        if ans != f"APPLY {p['fix_id']}":
            log.write("declined", fix_id=p["fix_id"]); summary["skipped"].append(p["fix_id"]); out("  Skipped."); continue
        log.write("approved", fix_id=p["fix_id"], approval_text=ans)
        st, body = api.write(p["sql"])
        log.write("execute", fix_id=p["fix_id"], sql=p["sql"], status=st)
        if st not in (200, 201):
            out(f"  FAILED (HTTP {st}). Nothing else changed."); summary["failed"].append(p["fix_id"]); continue
        verified = None
        if rescan_fn:
            verified = not _still_present(p, rescan_fn())
            log.write("verify", fix_id=p["fix_id"], finding_gone=verified)
        out(f"  Applied. Verification by re-scan: {'PASSED' if verified else 'FAILED' if verified is False else 'not run'}")
        summary["applied"].append(p["fix_id"])
        if verified is False:
            ans = input_fn(f"  Finding still present. Type ROLLBACK {p['fix_id']} to undo: ").strip()
            if ans == f"ROLLBACK {p['fix_id']}":
                st, _ = api.write(p["rollback_sql"]); log.write("rollback", fix_id=p["fix_id"], sql=p["rollback_sql"], status=st)
                summary["rolled_back"].append(p["fix_id"]); out(f"  Rolled back (HTTP {st}).")
    log.write("session_end", **{k: len(v) for k, v in summary.items() if isinstance(v, list)})
    return summary

def main(argv=None, input_fn=None, out=None, scan_kw=None):
    ap = argparse.ArgumentParser(prog="atoll-audit remediate", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("result", nargs="?", help="result.json from a scan"); ap.add_argument("--project-ref", help="Supabase project ref")
    ap.add_argument("--apply", action="store_true", help="actually apply approved fixes (default: dry run)")
    ap.add_argument("--api-base", default=DEFAULT_API); ap.add_argument("--token-env", default="SUPABASE_ACCESS_TOKEN")
    ap.add_argument("--audit-log", default="remediation-audit.jsonl"); ap.add_argument("--drafts", default="drafts")
    ap.add_argument("--rescan-url", help="app URL to re-scan for verification (defaults to the result's target)")
    ap.add_argument("--no-rescan", action="store_true"); ap.add_argument("--verify-log", action="store_true", help="only verify the audit log hash chain")
    a = ap.parse_args(argv)
    if a.verify_log:
        ok, why = verify_log(a.audit_log); print("audit log OK" if ok else f"audit log TAMPERED: {why}"); return 0 if ok else 1
    if not a.result or not a.project_ref: ap.error("result and --project-ref are required")
    res = json.loads(pathlib.Path(a.result).read_text())
    rescan_fn = None
    if a.apply and not a.no_rescan:
        from .scanner import scan, Client
        url = a.rescan_url or res.get("info", {}).get("target")
        rescan_fn = (lambda: scan(url, Client(), **(scan_kw or {}))) if url else None
    if a.apply and input_fn is None and not sys.stdin.isatty():
        print("Refusing to apply without an interactive terminal: every fix needs typed approval.", file=sys.stderr); return 2
    s = run(res, a.project_ref, apply=a.apply, api_base=a.api_base, token_env=a.token_env, log_path=a.audit_log, drafts_dir=a.drafts,
            rescan_fn=rescan_fn, input_fn=input_fn or input, out=out or print)
    return 0 if not s.get("failed") and not s.get("error") else 1

if __name__ == "__main__":
    sys.exit(main())
