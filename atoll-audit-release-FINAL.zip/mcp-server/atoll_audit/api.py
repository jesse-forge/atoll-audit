"""Local HTTP JSON API for agents without MCP. Binds to 127.0.0.1 only by default.

    python3 -m atoll_audit.api --port 8787
    POST /scan        {"url": "https://...", "i_own_this_app": true}
    POST /check-code  {"code": "..."}
    POST /fix-prompt  {"finding_id": "...", "context": {...}}
    GET  /health"""
import argparse, json, sys
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from . import tools

MAX_BODY = 25_000_000

class Handler(BaseHTTPRequestHandler):
    server_version = "AtollAuditAPI/0.3"
    def log_message(self, fmt, *a): sys.stderr.write("api: " + fmt % a + "\n")
    def _send(self, code, obj):
        b = json.dumps(obj).encode(); self.send_response(code)
        self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        if self.path == "/health": return self._send(200, {"ok": True, "tools": ["scan", "check-code", "fix-prompt"]})
        self._send(404, {"error": "not found"})
    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > MAX_BODY: return self._send(413, {"error": "body too large"})
        if "application/json" not in (self.headers.get("Content-Type") or ""): return self._send(415, {"error": "Content-Type must be application/json"})
        try: data = json.loads(self.rfile.read(n) or b"{}")
        except ValueError: return self._send(400, {"error": "invalid JSON"})
        try:
            if self.path == "/scan": return self._send(200, tools.scan_app(data.get("url"), data.get("i_own_this_app") is True))
            if self.path == "/check-code": return self._send(200, tools.check_code_for_leaks(data.get("code")))
            if self.path == "/fix-prompt": return self._send(200, tools.get_fix_prompt(data.get("finding_id", ""), data.get("context")))
            return self._send(404, {"error": "not found"})
        except tools.ToolError as e:
            return self._send(400 if "Refusing" not in str(e) else 403, {"error": str(e)})

def make_server(host="127.0.0.1", port=8787): return ThreadingHTTPServer((host, port), Handler)

def main(argv=None):
    ap = argparse.ArgumentParser(prog="atoll-audit-api"); ap.add_argument("--port", type=int, default=8787); ap.add_argument("--host", default="127.0.0.1")
    a = ap.parse_args(argv)
    if a.host not in ("127.0.0.1", "localhost", "::1"): print("WARNING: binding to a non-local interface exposes the scanner to your network.", file=sys.stderr)
    s = make_server(a.host, a.port); print(f"Atoll Audit API on http://{a.host}:{a.port}", file=sys.stderr)
    try: s.serve_forever()
    except KeyboardInterrupt: pass

if __name__ == "__main__":
    main()
