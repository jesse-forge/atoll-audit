"""Checks for real-world 'vibe-coding' failure modes. All requests are GET/HEAD/OPTIONS through the Scan's
read-only Client; response bodies are inspected in memory and never stored (only names, versions, masked values).

- auth gaps: Supabase /auth/v1/settings (public endpoint), admin routes listed in the bundle
- rate limits: RateLimit / X-RateLimit / Retry-After header presence on auth endpoints (OPTIONS/HEAD only, never brute force)
- debug/dev endpoints, GraphQL introspection (GET query only), API docs, phpinfo, server-status, actuator, stack traces
- library versions fingerprinted from bundles vs. a bundled known-vulnerable list (data/vulnerable_versions.json)
- exposed environment variables: secret-looking VITE_/NEXT_PUBLIC_/REACT_APP_ vars, process.env dumps, window.__ENV__ objects"""
import json, pathlib, re, secrets as _secrets, urllib.parse
from . import leaks

def _origin(u): p = urllib.parse.urlparse(u); return f"{p.scheme}://{p.netloc}"

def run_all(s):
    s.info.setdefault("auth_settings", None); s.info.setdefault("admin_routes", []); s.info.setdefault("rate_limit_checks", [])
    s.info.setdefault("debug_checks", []); s.info.setdefault("libraries", [])
    _baseline(s)
    auth_settings(s); admin_routes(s); rate_limits(s); debug_endpoints(s); dependencies(s); env_exposure(s)

# ---------- helpers
def _baseline(s):
    site = _origin(s.url)
    st, body, _ = s.c.request(f"{site}/atoll-audit-404-check-{_secrets.token_hex(4)}", follow_redirects=False)
    s._nf = (st, body or "")
    s.info["not_found_probe"] = {"status": st, "spa_fallback": st == 200 and body.lstrip()[:15].lower().startswith(("<!doctype", "<html"))}
    if _stack_trace(body or ""):
        s.add("verbose-errors", "medium", "Error pages show stack traces / internal file paths (seen on a harmless 404 request)", path="/(404 page)")
    del body

def _fallback(s, st, body):
    """True if a probe just returned the SPA's index page / generic 404 page (not a real endpoint)."""
    if st != 200: return True
    b = (body or "").strip()
    return b == (s._nf[1] or "").strip() or b == (getattr(s, "page_html", "") or "").strip()

STACK_RES = [re.compile(p) for p in (r"Traceback \(most recent call last\)", r"\n\s+at [\w.$<>\[\] ]+ \([^)\n]*:\d+:\d+\)",
             r"Werkzeug Debugger", r"Whoops! There was an error", r"django\.core\.\w+", r"Exception in thread \"",
             r"/node_modules/[^\s\"'<>]+:\d+:\d+", r"(?i)<title>[^<]*(?:Error|Exception)[^<]*</title>[\s\S]{0,4000}?\bat\s+\S+:\d+")]
def _stack_trace(body): return any(r.search(body[:200000]) for r in STACK_RES)

# ---------- auth gaps
def auth_settings(s):
    sb, key = s.info.get("supabase_url"), getattr(s, "anon_key", None)
    if not sb or not key: return
    st, body, _ = s.c.request(f"{sb}/auth/v1/settings", headers={"apikey": key, "Accept": "application/json"})
    try: d = json.loads(body) if st == 200 else None
    except ValueError: d = None
    if not isinstance(d, dict): return
    ext = d.get("external") or {}
    a = s.info["auth_settings"] = {"signup_open": not d.get("disable_signup", False), "email_autoconfirm": bool(d.get("mailer_autoconfirm")),
                                    "phone_autoconfirm": bool(d.get("phone_autoconfirm")), "anonymous_sign_ins": bool(ext.get("anonymous_users")),
                                    "email_provider": bool(ext.get("email", True))}
    if a["signup_open"] and a["email_autoconfirm"] and a["email_provider"]:
        s.add("auth-email-confirmation-off", "medium", "Email confirmation is turned off: anyone can sign up with any email address, including addresses they don't own", setting="mailer_autoconfirm")
    if a["signup_open"]:
        s.add("auth-open-signup", "info", "Sign-ups are open to anyone (fine for public apps; make sure RLS policies don't treat every logged-in user as trusted)", setting="disable_signup")
    if a["anonymous_sign_ins"]:
        s.add("auth-anonymous-signins", "low", "Anonymous sign-ins are enabled: anonymous visitors get the 'authenticated' role, so policies written 'to authenticated' also let them in", setting="anonymous_users")

ADMIN_RE = re.compile(r"[\"'`](/(?:admin|administrator|superadmin|super-admin|backoffice|back-office|staff|internal|moderator|dashboard/admin)(?:/[A-Za-z0-9_\-/]*)?)[\"'`]")
LOGIN_HINT = re.compile(r"type=[\"']?password|sign[ -]?in|log[ -]?in", re.I)
def admin_routes(s):
    routes = set()
    for where, t in s.texts: routes |= set(ADMIN_RE.findall(t))
    site = _origin(s.url)
    for r in sorted(routes)[:6]:
        st, body, h = s.c.request(site + r, follow_redirects=False)
        loc = (h.get("location") or "").lower()
        if st in (301, 302, 303, 307, 308) and re.search(r"login|signin|sign-in|auth", loc): status = "redirects to login"
        elif st in (401, 403): status = "requires login"
        elif st == 200 and _fallback(s, st, body): status = "spa route (client-side only)"
        elif st == 200 and not LOGIN_HINT.search(body or ""): status = "served without login"
        elif st == 200: status = "shows login form"
        else: status = f"status {st}"
        del body
        s.info["admin_routes"].append({"route": r, "status": status})
        if status == "served without login":
            s.add("admin-page-reachable", "medium", f"Admin page '{r}' is served by your server without any login", route=r)
        elif status == "spa route (client-side only)":
            s.add("admin-route-review", "info", f"Review: admin route '{r}' exists in your app's code; confirm its data is protected server-side (RLS/role checks), not just hidden in the UI", route=r)

# ---------- rate-limit signals (headers only)
RL_HDR = re.compile(r"^(?:x-)?rate-?limit|^retry-after$", re.I)
AUTH_EP_RE = re.compile(r"[\"'`](/api/(?:auth/)?(?:login|signin|sign-in|signup|sign-up|register|otp|token|reset-password|forgot-password|callback/credentials)[A-Za-z0-9/_-]*)[\"'`]")
def rate_limits(s):
    site = _origin(s.url); eps = set()
    for _, t in s.texts: eps |= set(AUTH_EP_RE.findall(t))
    checks = [(site + e, "app") for e in sorted(eps)[:4]]
    if s.info.get("supabase_url") and getattr(s, "anon_key", None): checks.append((s.info["supabase_url"] + "/auth/v1/token", "supabase"))
    for url, kind in checks:
        seen = False
        for method in ("OPTIONS", "HEAD"):
            st, _, h = s.c.request(url, method=method, headers={"Origin": _origin(s.url), "Access-Control-Request-Method": "POST"}, follow_redirects=False)
            if any(RL_HDR.search(k) for k in h): seen = True; break
            if kind == "supabase": break  # one preflight is enough for hosted Supabase
        path = urllib.parse.urlparse(url).path
        s.info["rate_limit_checks"].append({"endpoint": path, "kind": kind, "rate_limit_headers_seen": seen})
        if not seen and kind == "app":
            s.add("rate-limit-not-visible", "low", f"No rate-limit signal on login endpoint {path} (can't confirm brute-force protection; headers may just be hidden)", endpoint=path)
        elif not seen:
            s.add("rate-limit-supabase-review", "info", "Supabase Auth doesn't expose rate-limit headers; review Auth → Rate Limits in the dashboard (Supabase applies built-in limits)", endpoint=path)

# ---------- debug / dev endpoints
GQL_Q = "?query=" + urllib.parse.quote("{__schema{queryType{name}}}")
def debug_endpoints(s):
    site = _origin(s.url)
    html = getattr(s, "page_html", "") or ""
    if re.search(r"\"buildId\"\s*:\s*\"development\"", html) or "/_next/static/development/" in html:
        s.add("nextjs-dev-mode", "medium", "This site is running a Next.js development build in production", path="/")
    def probe(path, accept="*/*"):
        st, body, h = s.c.request(site + path, headers={"Accept": accept}, follow_redirects=False)
        real = not _fallback(s, st, body)
        s.info["debug_checks"].append({"path": path.split("?")[0], "status": st, "real_response": real})
        return (body or "") if real else None
    for p in ("/api/debug", "/debug", "/api/_debug", "/__debug"):
        b = probe(p)
        if b is not None and re.search(r"(?i)env|debug|process|config|stack|version", b[:20000]):
            secretish = leaks.check_code(b)["serious"] + len(re.findall(r"(?i)\b[A-Z0-9_]*(?:SECRET|PASSWORD|TOKEN|SERVICE_ROLE|DATABASE_URL)[A-Z0-9_]*\b", b[:50000]))
            s.add("debug-endpoint-exposed", "high" if secretish else "medium",
                  f"Debug endpoint {p} is publicly reachable" + (" and appears to show secrets/config" if secretish else ""), path=p)
        del b
    b = probe("/_next/static/development/_buildManifest.js")
    if b is not None and "__BUILD_MANIFEST" in b:
        s.add("nextjs-dev-mode", "medium", "This site is running a Next.js development build in production", path="/")
    b = probe("/@vite/client")
    if b is not None and re.search(r"vite|import\.meta\.hot", b[:20000]):
        s.add("vite-dev-server-exposed", "medium", "A Vite development server is publicly reachable (dev mode in production)", path="/@vite/client")
    for p in ("/graphql", "/api/graphql"):
        b = probe(p + GQL_Q, "application/json")
        if b is not None and "__schema" in b and "queryType" in b:
            s.add("graphql-introspection", "low", f"GraphQL introspection is enabled at {p} (anyone can download your full API schema)", path=p)
    for p in ("/swagger", "/swagger-ui.html", "/swagger-ui/", "/api-docs", "/swagger.json", "/openapi.json", "/api/swagger.json", "/v2/api-docs"):
        b = probe(p)
        if b is not None and re.search(r"(?i)swagger|\"openapi\"\s*:", b[:20000]):
            s.add("api-docs-public", "low", f"API documentation is public at {p}", path=p, dedupe="api-docs")
    for p in ("/phpinfo.php", "/info.php", "/phpinfo"):
        b = probe(p)
        if b is not None and re.search(r"phpinfo\(\)|<title>PHP \d|PHP Version \d", b[:50000]):
            s.add("phpinfo-exposed", "high", f"phpinfo() page is public at {p} (reveals server config and environment)", path=p)
    b = probe("/server-status")
    if b is not None and "Apache Server Status" in b:
        s.add("server-status-exposed", "medium", "Apache /server-status page is public (reveals visitors' URLs and server internals)", path="/server-status")
    b = probe("/actuator", "application/json")
    if b is not None:
        try: links = (json.loads(b).get("_links") or {})
        except (ValueError, AttributeError): links = {}
        if links:
            bad = sorted(set(links) & {"env", "heapdump", "configprops", "threaddump", "logfile", "mappings", "beans"})
            s.add("actuator-exposed", "high" if bad else "low", "Spring Boot Actuator is public" + (f" including sensitive endpoints: {', '.join(bad)}" if bad else ""), path="/actuator")
    st, body, _ = s.c.request(f"{site}/api/atoll-audit-404-check-{_secrets.token_hex(4)}", follow_redirects=False)
    if body and not _fallback(s, 200, body) and _stack_trace(body):
        s.add("verbose-errors", "medium", "Error pages show stack traces / internal file paths (seen on a harmless 404 request)", path="/(404 page)")
    del body

# ---------- vulnerable libraries
V = r"(\d+\.\d+\.\d+)"
LIB_PATTERNS = {
    "lodash": [r"@license\s+Lodash\s+(?:lodash\.com/license\s*\|\s*)?v?" + V, r"\bLodash\s+v?" + V, r"lodash[\s\S]{0,300}?\bVERSION\s*=\s*[\"']" + V],
    "jquery": [r"jQuery(?: JavaScript Library)? v" + V, r"\bjquery:\s*[\"']" + V],
    "axios": [r"\b[Aa]xios v" + V, r"\baxios@" + V],
    "next": [r"window\.next\s*=\s*\{\s*version:\s*[\"']" + V, r"\bnext@" + V, r"__NEXT_VERSION__?[\"']?\s*[:=]\s*[\"']" + V],
    "react-dom": [r"version:\s*[\"']" + V + r"[\"'],\s*rendererPackageName:\s*[\"']react-dom", r"\breact-dom@" + V],
}
LIB_RES = {k: [re.compile(p) for p in v] for k, v in LIB_PATTERNS.items()}
_DB = None
def vuln_db():
    global _DB
    if _DB is None: _DB = json.loads((pathlib.Path(__file__).parent / "data" / "vulnerable_versions.json").read_text())["entries"]
    return _DB
def _v(s): return tuple(int(x) for x in s.split("."))
def vulns_for(lib, ver):
    return [e for e in vuln_db() if e["library"] == lib and _v(e["introduced"]) <= _v(ver) < _v(e["fixed"])]
def dependencies(s):
    found = {}
    texts = list(s.texts) + [("page", getattr(s, "page_html", "") or "")]
    for where, t in texts:
        if "__lodash_hash_undefined__" in t:  # minified lodash keeps this marker next to its VERSION constant
            for ver in re.findall(r"\bVERSION\s*=\s*[\"'](4\.\d+\.\d+)[\"']", t): found.setdefault(("lodash", ver), where)
        for lib, res in LIB_RES.items():
            for rx in res:
                for ver in rx.findall(t): found.setdefault((lib, ver), where)
    sev_rank = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    for (lib, ver), where in sorted(found.items()):
        hits = vulns_for(lib, ver)
        s.info["libraries"].append({"library": lib, "version": ver, "appears_vulnerable": bool(hits), "cves": sorted({h["cve"] for h in hits})})
        if hits:
            sev = min((h["severity"] for h in hits), key=lambda x: sev_rank[x])
            cves = sorted({h["cve"] for h in hits})
            s.add("vulnerable-library", sev, f"{lib} {ver} version appears vulnerable ({', '.join(cves)})", library=f"{lib}@{ver}", cves=cves,
                  advisories=[{"cve": h["cve"], "fixed": h["fixed"], "summary": h["summary"], "ref": h["ref"]} for h in hits], where=where)

# ---------- exposed environment variables
SECRET_NAME = re.compile(r"SECRET|PRIVATE|PASSWORD|PASSWD|SERVICE_ROLE|DATABASE_URL|DB_URL|POSTGRES_URL|MONGODB_URI|TOKEN|ADMIN_KEY|API_KEY", re.I)
PUBLIC_NAME = re.compile(r"PUBLISHABLE|ANON|FIREBASE_API_KEY|GOOGLE_MAPS|MAPBOX|PUBLIC_KEY|SITE_KEY|RECAPTCHA|_URL$|POSTHOG|SENTRY_DSN", re.I)
ENV_OBJ_RES = [re.compile(r"window\.(__ENV__|_env_|__env|ENV|__RUNTIME_CONFIG__|__APP_CONFIG__)\s*=\s*(\{[^{}]{0,8000}\})"),
               re.compile(r"(process\.env)\s*=\s*(\{[^{}]{0,8000}\})"), re.compile(r"[\"'](process\.env)[\"']\s*:\s*(\{[^{}]{0,8000}\})")]
KV_RE = re.compile(r"[\"']?([A-Za-z_][A-Za-z0-9_]*)[\"']?\s*:\s*[\"'`]([^\"'`]*)[\"'`]")
DBURL_RE = re.compile(r"\b(?:postgres(?:ql)?|mysql|mongodb(?:\+srv)?|redis)://[^\s:@/\"'`]+:[^\s@/\"'`]+@[^\s\"'`]+")
def _is_secret_name(k, v):
    return SECRET_NAME.search(k) and not (PUBLIC_NAME.search(k) and not re.search(r"DATABASE_URL|DB_URL|POSTGRES_URL", k, re.I)) and len(v) >= 8
def env_exposure(s):
    known = {f.get("key") for f in s.findings if f.get("key")}
    for where, t in s.texts:
        for m in leaks.ENV_RE.finditer(t):
            name, val = m.group(1), m.group(2)
            if leaks.ENV_IGNORE.match(val) or leaks.mask(val) in known: continue
            s.add("public-env-secret", "high", f"Secret-looking public environment variable {name} is in your frontend bundle", dedupe=name, variable=name, key=leaks.mask(val), where=where)
        for rx in ENV_OBJ_RES:
            for m in rx.finditer(t):
                obj, body = m.group(1), m.group(2)
                pairs = KV_RE.findall(body)
                secret_keys = sorted({k for k, v in pairs if _is_secret_name(k, v)})
                names = sorted({k for k, _ in pairs})
                if obj == "process.env":
                    s.add("process-env-dump", "high" if secret_keys else "medium", f"A process.env dump is embedded in your frontend ({len(names)} variables)",
                          dedupe=where, variable="process.env", variables=names, secret_variables=secret_keys, where=where)
                elif secret_keys:
                    s.add("env-object-exposed", "high", f"window.{obj} config object in your frontend contains secret-looking values ({', '.join(secret_keys)})",
                          dedupe=obj, variable=f"window.{obj}", variables=names, secret_variables=secret_keys, where=where)
                else:
                    s.add("env-object-public", "info", f"window.{obj} config object found (only public-looking keys: {', '.join(names) or 'none'})", dedupe=obj, variable=f"window.{obj}", where=where)
        for m in DBURL_RE.finditer(t):
            s.add("database-url-exposed", "critical", "A database connection string with a password is in your frontend code", dedupe=m.group(0), key=leaks.mask(m.group(0)), where=where)
