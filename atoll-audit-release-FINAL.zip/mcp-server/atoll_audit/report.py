"""Turn scan results into client-ready Markdown and self-contained HTML reports."""
import html, datetime

DISCLAIMER = ("This is an automated, read-only, owner-consented security check. It is NOT a full penetration test and does not "
              "guarantee your app is secure. It only tests what is reachable from your public website. Row contents and file "
              "contents are never stored or shown; keys are masked.")

# id -> (what it means, why it matters, fix prompt for Lovable/Bolt/Cursor, how to verify)
CATALOG = {
 "service-role-key-exposed": ("Your app's master Supabase key (service_role) is inside the code every visitor downloads.",
   "This key bypasses all security rules. Anyone can read, change, or delete every row in your database.",
   "First rotate the service_role key in Supabase → Project Settings → API. Then: Remove every use of the Supabase service_role key from frontend code. Only the anon/publishable key may be used in the browser. Move any operation that needs elevated privileges into a Supabase Edge Function that reads the key from environment secrets and checks the user's JWT, and call that function from the frontend instead.",
   "Rotate the key, redeploy, and re-run Atoll Audit: this finding should disappear. The old key must return 401."),
 "table-readable-sensitive": ("Anyone can read the table '{table}', which contains personal or payment-related columns ({sens}).",
   "This is a data breach waiting to happen: emails, phone numbers, password hashes or customer IDs can be scraped by anyone, which can trigger legal duties (e.g. breach notification).",
   "Enable Row Level Security on the table '{table}'. Add policies so users can only select, insert, update, and delete their own rows (auth.uid() = user_id). Never expose columns like password_hash to the client; move them to a separate table with no client access. Show me the SQL migration before applying it.",
   "Re-run Atoll Audit. '{table}' should show 'Readable by anon: no'. Also log in as two different test users and confirm each sees only their own rows."),
 "table-readable-by-anon": ("Anyone on the internet can read the table '{table}' using the public key built into your site.",
   "Even if the data seems harmless today, columns added later will be exposed automatically.",
   "Enable Row Level Security on the table '{table}'. If the rows are meant to be public, add a SELECT policy for the anon role that only exposes intended rows and columns; otherwise restrict access to auth.uid() = user_id. Show me the SQL migration before applying it.",
   "Re-run Atoll Audit and confirm '{table}' is either no longer readable or intentionally public."),
 "public-storage-bucket": ("The storage bucket '{bucket}' is public.",
   "Anyone who has or guesses a file URL can download it. Fine for logos and product images, dangerous for user uploads or documents.",
   "If '{bucket}' holds private files: make the Supabase storage bucket '{bucket}' private, add storage RLS policies so users can only access files under a folder named with their user id, and display files with short-lived signed URLs.",
   "Re-run Atoll Audit; the bucket should be listed as private, and an old public file URL should return an error."),
 "public-storage-file": ("A file in bucket '{bucket}' that is linked from your frontend can be downloaded without logging in.",
   "Confirms the bucket is serving files publicly. If these are user uploads, they are exposed.",
   "Make the '{bucket}' bucket private unless it only contains public assets, and switch the app to signed URLs created after checking the logged-in user.",
   "Open the old file URL in a private browser window: it should fail."),
 "edge-function-no-auth": ("The Edge Function '{function}' answers requests without any login token.",
   "Anyone can call it directly, e.g. to send emails, run AI calls on your bill, or trigger actions meant for logged-in users.",
   "In the Supabase Edge Function '{function}', require a valid user JWT: enable verify_jwt for this function, read the Authorization header, call supabase.auth.getUser() and return 401 if there is no valid user. Add rate limiting if it sends emails or calls paid APIs.",
   "Call the function URL in a browser without logging in: it should return 401. Re-run Atoll Audit."),
 "firebase-rtdb-open": ("Your Firebase Realtime Database can be read by anyone.",
   "All data in it, including user records, can be downloaded with a single request.",
   "Update Firebase Realtime Database security rules: deny read and write by default (\".read\": false, \".write\": false) and only allow each user to access their own path using auth.uid. Show me the rules before deploying.",
   "Open <databaseURL>/.json in a private window: it should return 'Permission denied'. Re-run Atoll Audit."),
 "firestore-open-read": ("The Firestore collection '{collection}' can be read without logging in.",
   "Anyone can list documents in it; sensitive-looking fields: {sens}.",
   "Update Firestore security rules so the '{collection}' collection is only readable by signed-in users who own the document (request.auth.uid == resource.data.userId), and deny everything else by default.",
   "Re-run Atoll Audit; the collection should return PERMISSION_DENIED."),
 "google-api-key-public": ("A Google/Firebase API key is in your frontend.",
   "Firebase keys are meant to be public, but if the key is unrestricted, others can use it for paid Google APIs (like Maps) on your bill.",
   "In Google Cloud Console → APIs & Services → Credentials, restrict this API key to my website's domain (HTTP referrers) and only to the APIs this app uses. Do not use this key for any server-side-only API.",
   "In Google Cloud Console, the key shows 'Application restrictions: HTTP referrers' and an API restriction list."),
 "source-map-exposed": ("Your original source code (source map) can be downloaded at {path}.",
   "Attackers can read your full code, comments, and logic, making other bugs much easier to find.",
   "Disable production source maps in the build config (e.g. in vite.config set build.sourcemap = false) and make sure no .map files are deployed.",
   "Open {path} in the browser: it should return 404 or your normal page."),
 "env-file-exposed": ("Your /.env file can be downloaded from your website.",
   "These files usually contain secret keys and database passwords.",
   "Remove the .env file from the deployed/public folder, add .env to .gitignore, and make sure only VITE_/NEXT_PUBLIC_ public values are bundled. Then rotate every secret that was in the file.",
   "Open https://yourapp/.env: it should return 404 or the normal page. Rotate every key that was in it."),
 "git-exposed": ("Your /.git folder is reachable on your website.",
   "Attackers can rebuild your full source code and history, including any secrets ever committed.",
   "Make sure the .git folder is never deployed: deploy from a build output folder (dist/) only, and block dotfiles in the hosting config.",
   "Open https://yourapp/.git/HEAD: it should return 404."),
 "cors-permissive-credentials": ("Your site tells browsers that any other website may make logged-in requests to it.",
   "A malicious site could act as your logged-in users and read their data.",
   "Fix the CORS configuration: only allow my own domain(s) in Access-Control-Allow-Origin, never reflect arbitrary origins, and only send Access-Control-Allow-Credentials: true for that allow-list.",
   "Re-run Atoll Audit; the CORS finding should be gone."),
 "missing-csp": ("No Content-Security-Policy header.", "A CSP limits the damage of injected scripts (XSS).",
   "Add a Content-Security-Policy header in the hosting config (e.g. vercel.json or netlify.toml headers) starting with default-src 'self' and allowing only the domains my app needs (Supabase URL, fonts, analytics). Test that the app still works.",
   "Check response headers in browser DevTools → Network → document."),
 "missing-hsts": ("No Strict-Transport-Security header.", "Without HSTS, users can be downgraded to insecure HTTP on hostile networks.",
   "Add the header Strict-Transport-Security: max-age=63072000; includeSubDomains in the hosting config.",
   "Check response headers in DevTools."),
 "missing-xfo": ("No clickjacking protection.", "Other sites could load your app invisibly in a frame and trick users into clicking.",
   "Add X-Frame-Options: DENY (or CSP frame-ancestors 'none') to the hosting headers config.",
   "Check response headers in DevTools."),
 "auth-email-confirmation-off": ("Your Supabase project lets people sign up without confirming their email address.",
   "Anyone can create accounts with someone else's email (impersonation, spam sign-ups), and any feature that trusts 'verified email' is fooled.",
   "In Supabase Dashboard → Authentication → Sign In / Providers → Email, turn ON 'Confirm email'. Then update my app so unconfirmed users see a 'check your inbox' screen and can't use protected features until confirmed.",
   "Re-run Atoll Audit; the finding should disappear (it reads the public /auth/v1/settings endpoint)."),
 "auth-anonymous-signins": ("Anonymous sign-ins are enabled in Supabase Auth.",
   "Anonymous users get the 'authenticated' role, so any RLS policy written 'to authenticated' without checking auth.uid() or is_anonymous also lets strangers in.",
   "Check every RLS policy in my Supabase project that uses 'to authenticated'. Add a condition so anonymous users are excluded where needed: (auth.jwt()->>'is_anonymous')::boolean is false. If my app doesn't need guest accounts, disable Anonymous sign-ins in Authentication → Sign In / Providers.",
   "Re-run Atoll Audit, and test as a guest user that private data is not visible."),
 "admin-page-reachable": ("Your server returns the admin page '{route}' to visitors who are not logged in.",
   "Anyone who guesses the URL can see whatever that page shows and may be able to use admin actions.",
   "Protect the {route} route on the server: in Next.js check the session in the page/layout server code (not only in middleware) and redirect to /login if there's no admin user; verify the user's role from the database, never from a client-side flag. Also make sure every API route used by the admin page checks the role.",
   "Open {route} in a private browser window: you should be redirected to the login page."),
 "rate-limit-not-visible": ("We couldn't see any rate-limit signal on your login endpoint {endpoint}.",
   "Without rate limiting, attackers can try thousands of passwords or flood sign-ups and emails. (Your endpoint may still be protected without showing headers; we never brute-force to find out.)",
   "Add rate limiting to {endpoint}: e.g. at most 5 attempts per minute per IP and per account, returning HTTP 429 with RateLimit-Limit/RateLimit-Remaining headers. Use a middleware or a store like Upstash Redis, or your host's firewall rules.",
   "Check the response headers of {endpoint} in DevTools for RateLimit-* or X-RateLimit-* headers."),
 "debug-endpoint-exposed": ("A debug endpoint ({path}) is open to the public.",
   "Debug output often contains environment variables, keys, user data or internal details that help attackers.",
   "Delete the {path} route from my app (or guard it so it only runs in development: if process.env.NODE_ENV !== 'development' return 404). Rotate any secret it may have shown. Redeploy.",
   "Open {path} on the live site: it should return 404."),
 "nextjs-dev-mode": ("Your live site is running a Next.js development build.",
   "Dev builds are slow, show detailed errors and source code, and aren't meant to be public.",
   "Deploy a production build: run 'next build' and serve with 'next start' (or your host's production preset), and make sure NODE_ENV=production. Never run 'next dev' on the public server.",
   "View page source: __NEXT_DATA__ should not contain \"buildId\":\"development\"."),
 "vite-dev-server-exposed": ("A Vite development server is reachable on your live site.",
   "The dev server serves your original source files and isn't hardened for the internet.",
   "Build the app with 'vite build' and deploy only the dist/ folder (or 'vite preview' behind a real host). Don't expose 'vite dev' publicly.",
   "Open /@vite/client on the live site: it should return 404."),
 "graphql-introspection": ("Your GraphQL API ({path}) answers introspection queries from anyone.",
   "Attackers can download your whole API schema, including hidden admin fields and mutations, which makes finding weaknesses easy.",
   "Disable GraphQL introspection in production (e.g. Apollo Server: introspection: process.env.NODE_ENV !== 'production'), and make sure every resolver checks authorization.",
   "Re-run Atoll Audit; the finding should disappear."),
 "api-docs-public": ("Your API documentation ({path}) is public.", "It gives attackers a map of every endpoint. That's fine for a public API, risky for internal ones.",
   "If this API isn't meant to be public, disable the Swagger/OpenAPI UI in production or put it behind login.", "Open {path} in a private window."),
 "phpinfo-exposed": ("A phpinfo() page ({path}) is public.", "It reveals server configuration, paths and often environment variables and secrets.",
   "Delete {path} from the server and rotate any secrets shown in its environment section.", "Open {path}: it should return 404."),
 "server-status-exposed": ("Apache's /server-status page is public.", "It shows URLs your visitors are requesting (sometimes with tokens) and server internals.",
   "Restrict mod_status to localhost (Require local) or disable it.", "Open /server-status: it should return 403/404."),
 "actuator-exposed": ("Spring Boot Actuator endpoints are public.", "Endpoints like /actuator/env and /actuator/heapdump can leak passwords and keys.",
   "Expose only health in production: management.endpoints.web.exposure.include=health, and protect the rest with Spring Security.", "Open /actuator: it should list only health, or require login."),
 "verbose-errors": ("Your error pages show stack traces and internal file paths.", "These details reveal your framework, file layout and sometimes code, helping attackers.",
   "Configure production error handling: generic error pages for users, details only in server logs (set NODE_ENV=production / DEBUG=False; add a custom 404 and 500 page).",
   "Open a non-existent URL on your site: you should see a simple 'Page not found' page with no code or paths."),
 "vulnerable-library": ("Your site ships {library}, and that version appears vulnerable to known security issues.",
   "Known vulnerabilities have public write-ups that attackers use. Whether your app is actually exploitable depends on how the library is used.",
   "Upgrade {library_name} to the latest version (at least the fixed version in the report) in package.json, run the install, rebuild and redeploy. Then run 'npm audit' and fix anything else it reports.",
   "Re-run Atoll Audit; the version shown should be the new one and the finding should disappear."),
 "public-env-secret": ("A secret-looking environment variable ({variable}) is baked into your frontend.",
   "Variables starting with VITE_, NEXT_PUBLIC_ or REACT_APP_ are sent to every visitor. A secret there is public.",
   "Rotate the value with whatever service issued it. Then rename {variable} so it doesn't start with VITE_/NEXT_PUBLIC_/REACT_APP_, use it only in server code (Edge Function / API route), and redeploy.",
   "Re-run Atoll Audit; the variable should no longer appear."),
 "env-object-exposed": ("A runtime config object ({variable}) in your page contains secret-looking values.",
   "Everything in that object is readable by every visitor.",
   "Rotate the secret values listed in the report. Remove them from {variable} so only public settings (site URL, anon key) remain; use secrets only on the server.",
   "View page source: the secret names should be gone."),
 "process-env-dump": ("Your frontend contains a copy of the server's environment variables (process.env).",
   "Server env vars usually include database passwords and API keys, and now they're public.",
   "Rotate every secret in the listed variables. Then fix the build config so only specific public variables are exposed (Vite: import.meta.env with VITE_ prefix only; Next.js: NEXT_PUBLIC_ only; never define 'process.env' as the whole object). Redeploy.",
   "Search the built JS for 'process.env=' or the variable names; nothing secret should remain."),
 "database-url-exposed": ("A database connection string, including its password, is in your frontend code.",
   "Anyone can connect directly to your database and read or destroy everything, bypassing your app and RLS.",
   "Immediately reset the database password (Supabase: Project Settings → Database → Reset password). Then remove the connection string from frontend code; only server code may use it, from a server-only environment variable. Redeploy.",
   "Re-run Atoll Audit and confirm the old password no longer works."),
}
SECRET_GENERIC = ("A {key_type} is in the code every visitor downloads.",
   "Anyone can copy it and use the service on your account and bill (e.g. send emails, make AI calls, charge cards).",
   "First revoke/rotate this key in the provider's dashboard. Then: Remove the {key_type} from all frontend code. Store it as a Supabase Edge Function secret (or server environment variable) and call the provider from a server function that checks the user's login.",
   "Rotate the key and re-run Atoll Audit; this finding should disappear and the old key should stop working.")

GRADE_TEXT = {"A": "Strong. No significant issues found by these checks.", "B": "Good, with minor hardening recommended.",
              "C": "Fair. At least one high-severity issue needs fixing soon.", "D": "Poor. A critical issue puts your data or bills at risk.",
              "F": "Failing. Multiple critical issues; fix before sharing the app with more users."}

def explain(f):
    cid = f["id"]
    if cid not in CATALOG and f["id"].endswith("-exposed") and f.get("key_type"): t = SECRET_GENERIC
    else: t = CATALOG.get(cid, (f["title"], "", "", ""))
    lib = f.get("library", "")
    v = dict(route=f.get("route", ""), endpoint=f.get("endpoint", ""), library=lib, library_name=lib.split("@")[0], variable=f.get("variable", ""), table=f.get("table", ""), bucket=f.get("bucket", ""), function=f.get("function", ""), collection=f.get("collection", ""),
             path=f.get("path", ""), key_type=f.get("key_type", "secret key"), sens=", ".join(f.get("sensitive_columns", []) or ["none"]))
    return [s.format(**v) for s in t]

def _actionable(res): return [f for f in res["findings"] if f["severity"] in ("critical", "high", "medium", "low")]

def verification_text(v):
    c = {x["check"]: x for x in v["checks"]}
    return (f"Triple-checked. {v['confirmed_count']} finding(s) confirmed in two independent scans"
            + (f"; {v['suspected_count']} seen in only one scan (listed under Notes as unconfirmed)" if v["suspected_count"] else "")
            + ("; safety audit passed (read-only requests only, no keys or data values in this report)." if c[3]["passed"] else "; SAFETY AUDIT FAILED, do not send."))

def to_markdown(res):
    i, c = res["info"], res["counts"]
    L = ["# Atoll Audit report", "", f"**Target:** {i['target']}  ", f"**Overall grade:** {res['grade']}: {GRADE_TEXT[res['grade']]}  ",
         f"**Findings:** {c['critical']} critical · {c['high']} high · {c['medium']} medium · {c['low']} low", "", f"> {DISCLAIMER}", ""]
    v = res.get("verification")
    if v: L += [f"**Verification:** {verification_text(v)}", ""]
    for n, f in enumerate(_actionable(res), 1):
        what, why, prompt, verify = explain(f)
        L += [f"## {n}. [{f['severity'].upper()}] {f['title']}", ""]
        if f.get("key"): L.append(f"- Key (masked): `{f['key']}` in `{f.get('where')}`")
        if f.get("columns"): L.append(f"- Exposed columns/fields (names only): {', '.join(f['columns'])}")
        for a in f.get("advisories", []): L.append(f"- {a['cve']}: {a['summary']} (fixed in {a['fixed']}) {a['ref']}")
        if f.get("secret_variables"): L.append(f"- Secret-looking variable names: {', '.join(f['secret_variables'])}")
        L += ["", f"**What this means:** {what}", "", f"**Why it matters:** {why}", "", "**Fix prompt (paste into Lovable, Bolt, or Cursor):**", "", "```", prompt, "```", "", f"**Verify:** {verify}", ""]
    notes = [f for f in res["findings"] if f["severity"] in ("info", "error")]
    if notes: L += ["## Notes", ""] + [f"- {f['title']}" for f in notes] + [""]
    if i["tables"]:
        L += ["## Tables checked", "", "| Table | Readable without login |", "|---|---|"] + [f"| {t['table']} | {'YES' if t['anon_readable'] else 'no'} |" for t in i["tables"]] + [""]
    return "\n".join(L)

SEV_COLORS = {"critical": "#b42318", "high": "#d9480f", "medium": "#b08800", "low": "#3b6fb6", "info": "#667085"}
GRADE_COLORS = {"A": "#12b76a", "B": "#66c61c", "C": "#f79009", "D": "#f04438", "F": "#912018"}

def to_html(res):
    e = html.escape; i, c, g = res["info"], res["counts"], res["grade"]
    cards = []
    for n, f in enumerate(_actionable(res), 1):
        what, why, prompt, verify = explain(f)
        meta = ""
        if f.get("key"): meta += f"<p class=meta>Key (masked): <code>{e(f['key'])}</code> in <code>{e(str(f.get('where')))}</code></p>"
        if f.get("columns"): meta += f"<p class=meta>Exposed columns/fields (names only): {e(', '.join(f['columns']))}</p>"
        for a in f.get("advisories", []): meta += f"<p class=meta>{e(a['cve'])}: {e(a['summary'])} (fixed in {e(a['fixed'])}) <a href=\"{e(a['ref'])}\">advisory</a></p>"
        if f.get("secret_variables"): meta += f"<p class=meta>Secret-looking variable names: {e(', '.join(f['secret_variables']))}</p>"
        cards.append(f"""<section class=card><h3><span class=sev style="background:{SEV_COLORS[f['severity']]}">{f['severity'].upper()}</span> {n}. {e(f['title'])}</h3>{meta}
<p><b>What this means:</b> {e(what)}</p><p><b>Why it matters:</b> {e(why)}</p>
<p><b>Fix prompt</b> (paste into Lovable, Bolt, or Cursor):</p><pre>{e(prompt)}</pre><p><b>Verify:</b> {e(verify)}</p></section>""")
    rows = "".join(f"<tr><td>{e(t['table'])}</td><td>{'<b class=bad>YES</b>' if t['anon_readable'] else 'no'}</td></tr>" for t in i["tables"])
    counts = "".join(f'<div class=count style="border-color:{SEV_COLORS[s]}"><b>{c[s]}</b><span>{s}</span></div>' for s in ("critical", "high", "medium", "low"))
    date = datetime.date.today().isoformat()
    return f"""<!doctype html><html lang=en><head><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1">
<title>Atoll Audit report: {e(i['target'])}</title><style>
body{{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;margin:0;background:#f4f7f8;color:#1d2939}}
header{{background:linear-gradient(135deg,#0b4f6c,#20a39e);color:#fff;padding:28px 6vw}}header h1{{margin:0;font-size:28px}}header p{{margin:4px 0 0;opacity:.9}}
main{{max-width:900px;margin:0 auto;padding:24px 5vw}}.summary{{display:flex;gap:24px;align-items:center;flex-wrap:wrap;background:#fff;padding:20px;border-radius:12px;box-shadow:0 1px 3px #0002}}
.grade{{font-size:64px;font-weight:800;color:#fff;width:110px;height:110px;border-radius:16px;display:flex;align-items:center;justify-content:center}}
.counts{{display:flex;gap:10px}}.count{{border-left:5px solid;padding:6px 12px;background:#f9fafb;border-radius:6px;text-align:center}}.count b{{display:block;font-size:22px}}.count span{{font-size:12px;text-transform:uppercase}}
.card{{background:#fff;border-radius:12px;padding:18px 22px;margin:16px 0;box-shadow:0 1px 3px #0002}}.card h3{{margin-top:0}}
.sev{{color:#fff;font-size:12px;padding:3px 8px;border-radius:6px;vertical-align:middle}}pre{{background:#0f172a;color:#e2e8f0;padding:12px;border-radius:8px;white-space:pre-wrap}}
.meta{{color:#475467;font-size:14px}}.verif{{background:#ecfdf3;border:1px solid #abefc6;padding:12px 16px;border-radius:8px;font-size:14px}}.disc{{background:#fffaeb;border:1px solid #fedf89;padding:12px 16px;border-radius:8px;font-size:14px}}
table{{border-collapse:collapse;background:#fff}}td,th{{border:1px solid #d0d5dd;padding:6px 12px}}.bad{{color:#b42318}}footer{{text-align:center;color:#667085;font-size:13px;padding:24px}}
</style></head><body><header><h1>🏝️ Atoll Audit</h1><p>Security checkup for apps built with AI coding tools · {e(date)}</p></header><main>
<section class=summary><div class=grade style="background:{GRADE_COLORS[g]}">{g}</div><div><h2 style="margin:0">Executive summary</h2>
<p><b>Target:</b> {e(i['target'])}<br><b>Backend:</b> {e(i['supabase_url'] or 'Supabase not detected')}{' · Firebase detected' if i['firebase'].get('project_ids') else ''}</p>
<p>{e(GRADE_TEXT[g])}</p><div class=counts>{counts}</div></div></section>
{('<p class=verif><b>✔ Verification:</b> ' + e(verification_text(res['verification'])) + '</p>') if res.get('verification') else ''}
<p class=disc><b>Disclaimer:</b> {e(DISCLAIMER)}</p>
<h2>Findings and fixes</h2>{''.join(cards) or '<p>No issues found by these checks.</p>'}
{('<h2>Notes</h2><ul>' + ''.join('<li>' + e(f['title']) + '</li>' for f in res['findings'] if f['severity'] in ('info', 'error')) + '</ul>') if any(f['severity'] in ('info', 'error') for f in res['findings']) else ''}
{'<h2>Tables checked</h2><table><tr><th>Table</th><th>Readable without login</th></tr>' + rows + '</table>' if rows else ''}
</main><footer>Atoll Audit · read-only, owner-consented scan · {len(res['requests'])} requests made</footer></body></html>"""
