"""Atoll Audit scanner: read-only checks for Lovable/Bolt/Cursor + Supabase/Firebase apps the user owns.
Strictly GET/HEAD/OPTIONS, rate limited, limit=1 row reads, row values discarded, keys masked."""
import base64, json, re, time, urllib.request, urllib.error, urllib.parse
from html.parser import HTMLParser
from . import leaks
EXTRA_LEAK_IDS = {"sendgrid_key", "aws_access_key", "github_token", "slack_token", "private_key"}

UA = "AtollAudit/0.3 (+owner-consented read-only scan)"
ALLOWED = ("GET", "HEAD", "OPTIONS")
PROBE_ORIGIN = "https://atoll-audit-cors-probe.invalid"
SEV_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4, "error": 5}

JWT_RE = re.compile(r"eyJ[A-Za-z0-9_-]{8,}\.eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}")
SB_PUBLISHABLE_RE = re.compile(r"sb_publishable_[A-Za-z0-9_-]{10,}")
# (id, label, regex, severity)
SECRET_PATTERNS = [
    ("supabase-secret-key", "Supabase secret key (sb_secret_)", re.compile(r"sb_secret_[A-Za-z0-9_-]{10,}"), "critical"),
    ("stripe-secret-key", "Stripe secret key", re.compile(r"\b[sr]k_(?:live|test)_[A-Za-z0-9]{10,}"), "critical"),
    ("anthropic-key", "Anthropic API key", re.compile(r"sk-ant-[A-Za-z0-9_-]{20,}"), "critical"),
    ("openai-key", "OpenAI API key", re.compile(r"sk-(?!ant-)(?:proj-)?[A-Za-z0-9_-]{20,}"), "critical"),
    ("resend-key", "Resend API key", re.compile(r"\bre_[A-Za-z0-9_]{20,}"), "critical"),
    ("twilio-key", "Twilio API key/secret", re.compile(r"\bSK[0-9a-fA-F]{32}\b"), "critical"),
]
GOOGLE_KEY_RE = re.compile(r"AIza[0-9A-Za-z_-]{35}")
SENSITIVE_COLS = re.compile(r"email|phone|password|passwd|pass_hash|hash|ssn|social|dob|birth|address|stripe|customer_id|card|iban|token|secret|api_key|salary|tax", re.I)

SB_CLOUD_RE = re.compile(r"https://[a-z0-9-]+\.supabase\.co")
SB_CREATE_RE = re.compile(r"createClient\(\s*[\"'`](https?://[^\"'`\s]+?)/?[\"'`]")
SB_PATH_RE = re.compile(r"(https?://[A-Za-z0-9.:-]+)/(?:rest|storage|functions|auth)/v1/")
FUNC_URL_RE = re.compile(r"/functions/v1/([A-Za-z0-9_-]+)")
FUNC_INVOKE_RE = re.compile(r"functions\.invoke\(\s*[\"'`]([A-Za-z0-9_-]+)[\"'`]")
STORAGE_URL_RE = re.compile(r"(https?://[A-Za-z0-9.:-]+)/storage/v1/object/(public/)?([A-Za-z0-9_.-]+)/([^\"'`\s?#)]+)")
CHUNK_RE = re.compile(r"[\"'`]((?:\.{1,2}/|/)?(?:[A-Za-z0-9_-]+/)*[A-Za-z0-9_.-]+\.m?js)[\"'`]")
SOURCEMAP_RE = re.compile(r"//[#@]\s*sourceMappingURL=([^\s'\"]+)")
FB_DBURL_RE = re.compile(r"databaseURL\s*:\s*[\"'`](https?://[^\"'`]+)[\"'`]")
FB_PROJECT_RE = re.compile(r"projectId\s*:\s*[\"'`]([A-Za-z0-9_-]+)[\"'`]")
FB_COLL_RE = re.compile(r"(?:\.collection\(|collection\(\s*[A-Za-z_$][\w$]*\s*,)\s*[\"'`]([A-Za-z0-9_-]+)[\"'`]")

def mask(s): return s[:6] + "…" + s[-4:] if len(s) > 12 else "…"

def jwt_role(token):
    try:
        p = token.split(".")[1]; p += "=" * (-len(p) % 4)
        return json.loads(base64.urlsafe_b64decode(p)).get("role")
    except Exception:
        return None

class _NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k): return None  # surface 3xx as HTTPError so callers see the redirect
_NO_REDIRECT = urllib.request.build_opener(_NoRedirectHandler)

class Client:
    """HTTP client restricted to GET/HEAD/OPTIONS, with rate limiting, size caps and a request log."""
    def __init__(self, delay=0.2, timeout=10, max_requests=300):
        self.delay, self.timeout, self.max_requests, self.log, self._last = delay, timeout, max_requests, [], 0.0
    def request(self, url, method="GET", headers=None, follow_redirects=True):
        if method not in ALLOWED:
            raise ValueError("Atoll Audit is read-only: only GET/HEAD/OPTIONS allowed")
        if len(self.log) >= self.max_requests:
            return None, "", {}
        wait = self.delay - (time.time() - self._last)
        if wait > 0: time.sleep(wait)
        self._last = time.time()
        req = urllib.request.Request(url, method=method, headers={"User-Agent": UA, **(headers or {})})
        self.log.append({"method": method, "url": re.sub(r"(/storage/v1/object/(?:public/)?[^/]+/).*", r"\1[redacted]", url)})
        try:
            opener = urllib.request.urlopen if follow_redirects else _NO_REDIRECT.open
            with opener(req, timeout=self.timeout) as r:
                body = r.read(3_000_000).decode("utf-8", "replace") if method == "GET" else ""
                return r.status, body, {k.lower(): v for k, v in r.headers.items()}
        except urllib.error.HTTPError as e:
            try: body = e.read(200_000).decode("utf-8", "replace") if method == "GET" else ""  # error pages (stack-trace check)
            except Exception: body = ""
            return e.code, body, {k.lower(): v for k, v in (e.headers or {}).items()}
        except Exception as e:
            return None, str(e), {}

class _Scripts(HTMLParser):
    def __init__(self): super().__init__(); self.srcs, self.inline = [], []
    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "script" and a.get("src"): self.srcs.append(a["src"])
        if tag == "link" and a.get("rel") in ("modulepreload", "preload") and (a.get("href") or "").endswith("js"): self.srcs.append(a["href"])
    def handle_data(self, d):
        if d.strip(): self.inline.append(d)

def _origin(u): p = urllib.parse.urlparse(u); return f"{p.scheme}://{p.netloc}"

def _looks_like_html(body): return body.lstrip()[:15].lower().startswith(("<!doctype", "<html"))

class Scan:
    def __init__(self, url, client, firestore_base, max_files, max_tables, allow_invoke=False):
        self.allow_invoke = allow_invoke
        self.url, self.c, self.fs_base, self.max_files, self.max_tables = url, client, firestore_base, max_files, max_tables
        self.findings, self._seen = [], set()
        self.info = {"target": url, "bundles": [], "supabase_url": None, "tables": [], "buckets": [], "functions": [],
                     "storage_files": [], "firebase": {}, "headers": {}}
        self.texts = []

    def add(self, fid, severity, title, dedupe=None, **kw):
        key = (fid, dedupe or title)
        if key in self._seen: return
        self._seen.add(key); self.findings.append({"id": fid, "severity": severity, "title": title, **kw})

    # 1. Crawl page + bundles (+ lazy chunks)
    def crawl(self):
        s, html, hdrs = self.c.request(self.url, headers={"Origin": PROBE_ORIGIN})
        if s != 200:
            self.add("fetch-failed", "error", f"Could not fetch {self.url} (status {s})"); return False
        self.page_headers = hdrs; self.page_html = html
        p = _Scripts(); p.feed(html)
        self.texts += [("inline", t) for t in p.inline]
        site = _origin(self.url)
        queue = [urllib.parse.urljoin(self.url, s) for s in p.srcs]; seen = set()
        while queue and len(seen) < self.max_files:
            u = queue.pop(0)
            if u in seen or _origin(u) != site: continue
            seen.add(u)
            st, body, h = self.c.request(u)
            if st != 200 or _looks_like_html(body): continue
            self.texts.append((u, body)); self.info["bundles"].append(u)
            for m in CHUNK_RE.findall(body):
                if m.startswith(("http:", "https:")): continue
                nu = urllib.parse.urljoin(u, m)
                if nu not in seen: queue.append(nu)
        return True

    # 2. Secrets
    def secrets(self):
        self.anon_key = None
        for where, t in self.texts:
            for tok in set(JWT_RE.findall(t)):
                role = jwt_role(tok)
                if role == "anon":
                    self.anon_key = self.anon_key or tok
                    self.add("anon-key-public", "info", "Supabase anon key in frontend (expected; safe only if RLS protects every table)", dedupe=tok, where=where, key=mask(tok))
                elif role == "service_role":
                    self.add("service-role-key-exposed", "critical", "Supabase service_role key exposed in frontend (bypasses all RLS)", dedupe=tok, where=where, key=mask(tok))
            for tok in set(SB_PUBLISHABLE_RE.findall(t)):
                self.anon_key = self.anon_key or tok
            for sid, label, rx, sev in SECRET_PATTERNS:
                for tok in set(rx.findall(t)):
                    self.add(f"{sid}-exposed", sev, f"{label} exposed in frontend code", dedupe=tok, where=where, key=mask(tok), key_type=label)
            for tid, label, sev, rx in leaks.RULES:
                if tid not in EXTRA_LEAK_IDS: continue
                for tok in set(rx.findall(t)):
                    self.add(f"{tid.replace('_', '-')}-exposed", sev, f"{label} exposed in frontend code", dedupe=tok, where=where, key=mask(tok), key_type=label)
            for tok in set(GOOGLE_KEY_RE.findall(t)):
                self.add("google-api-key-public", "medium", "Google/Firebase API key in frontend: must be restricted (HTTP referrer + API restrictions)", dedupe=tok, where=where, key=mask(tok))

    # 3. Supabase discovery + DB/storage/functions
    def supabase(self):
        cands = []
        for _, t in self.texts:
            cands += SB_CLOUD_RE.findall(t) + SB_CREATE_RE.findall(t) + SB_PATH_RE.findall(t)
        site = _origin(self.url)
        cands = [c.rstrip("/") for c in cands if _origin(c) != site]
        if not cands: return
        sb = max(set(cands), key=cands.count); self.info["supabase_url"] = sb
        # Functions (no auth headers at all; never POST)
        names = set()
        for _, t in self.texts: names |= set(FUNC_URL_RE.findall(t)) | set(FUNC_INVOKE_RE.findall(t))
        for n in sorted(names)[:20]:
            fu = f"{sb}/functions/v1/{n}"
            # Safe default: OPTIONS (CORS preflight) only. HEAD is NOT used because it can execute function code.
            so, _, ho = self.c.request(fu, method="OPTIONS", headers={"Origin": PROBE_ORIGIN, "Access-Control-Request-Method": "POST"})
            rec = {"function": n, "options_status": so, "get_status": None, "auth_required": None}
            if so in (401, 403):
                rec["auth_required"] = True  # gateway rejected even the preflight -> JWT verification is on
            elif self.allow_invoke:
                sg, _, _ = self.c.request(fu)  # opt-in only: may EXECUTE the function
                rec["get_status"] = sg
                rec["auth_required"] = not (sg is not None and 200 <= sg < 300)
                if not rec["auth_required"]:
                    self.add("edge-function-no-auth", "high", f"Edge Function '{n}' responds without any login/JWT", dedupe=n, function=n)
            if rec["auth_required"] is None:
                self.add("edge-function-review", "info", f"Edge Function '{n}': could not verify safely; review that this function checks auth", dedupe=n, function=n)
            self.info["functions"].append(rec)
        # Storage files referenced in bundle
        files = set()
        for _, t in self.texts: files |= set(STORAGE_URL_RE.findall(t))
        for base, pub, bucket, path in sorted(files)[:20]:
            fu = f"{base}/storage/v1/object/{pub}{bucket}/{path}"
            s, _, _ = self.c.request(fu, method="HEAD")
            ok = s == 200
            self.info["storage_files"].append({"bucket": bucket, "path_masked": path[:3] + "…", "public_url_form": bool(pub), "downloadable_without_auth": ok})
            if ok:
                self.add("public-storage-file", "high", f"File in bucket '{bucket}' is downloadable by anyone (URL found in your frontend)", dedupe=bucket + path, bucket=bucket)
        if not self.anon_key:
            self.add("no-anon-key", "info", "Supabase URL found but no anon key; database checks skipped"); return
        h = {"apikey": self.anon_key, "Authorization": f"Bearer {self.anon_key}", "Accept": "application/json"}
        s, body, _ = self.c.request(f"{sb}/rest/v1/", headers=h)
        tables = []
        if s == 200:
            try: tables = [k.strip("/") for k in json.loads(body).get("paths", {}) if k.strip("/") and not k.startswith("/rpc/")]
            except (ValueError, AttributeError): pass
        else:
            self.add("table-list-unavailable", "info", "Could not list tables via the public API (OpenAPI hidden); table checks limited")
        for t in tables[:self.max_tables]:
            s, body, _ = self.c.request(f"{sb}/rest/v1/{urllib.parse.quote(t)}?select=*&limit=1", headers=h)
            try: rows = json.loads(body) if s == 200 else []
            except ValueError: rows = []
            readable = isinstance(rows, list) and len(rows) > 0
            cols = sorted(rows[0].keys()) if readable and isinstance(rows[0], dict) else []
            del rows, body  # never retain row data
            sens = [c for c in cols if SENSITIVE_COLS.search(c)]
            self.info["tables"].append({"table": t, "status": s, "anon_readable": readable, "columns": cols, "sensitive_columns": sens})
            if readable and sens:
                self.add("table-readable-sensitive", "critical", f"Table '{t}' with sensitive columns ({', '.join(sens)}) is readable by anyone", dedupe=t, table=t, columns=cols, sensitive_columns=sens)
            elif readable:
                self.add("table-readable-by-anon", "high", f"Table '{t}' is readable by anyone with the public anon key", dedupe=t, table=t, columns=cols)
        s, body, _ = self.c.request(f"{sb}/storage/v1/bucket", headers=h)
        if s == 200:
            try: buckets = json.loads(body)
            except ValueError: buckets = []
            for b in buckets if isinstance(buckets, list) else []:
                name = b.get("name") or b.get("id"); pub = bool(b.get("public"))
                self.info["buckets"].append({"bucket": name, "public": pub})
                if pub: self.add("public-storage-bucket", "high", f"Storage bucket '{name}' is public", dedupe=name, bucket=name)

    # 4. Firebase
    def firebase(self):
        db_urls, pids, colls = set(), set(), set()
        for _, t in self.texts:
            db_urls |= set(FB_DBURL_RE.findall(t)); pids |= set(FB_PROJECT_RE.findall(t)); colls |= set(FB_COLL_RE.findall(t))
        fb = self.info["firebase"] = {"database_urls": sorted(db_urls), "project_ids": sorted(pids), "collections_checked": []}
        for u in sorted(db_urls)[:3]:
            s, body, _ = self.c.request(u.rstrip("/") + "/.json?shallow=true")
            ok = False; n = 0
            if s == 200:
                try: d = json.loads(body); ok = d is not None; n = len(d) if isinstance(d, dict) else 0
                except ValueError: pass
            del body
            fb["rtdb_open"] = ok
            if ok: self.add("firebase-rtdb-open", "critical", f"Firebase Realtime Database is readable by anyone ({n} top-level keys)", dedupe=u)
        for pid in sorted(pids)[:2]:
            for col in sorted(colls)[:15]:
                u = f"{self.fs_base}/v1/projects/{pid}/databases/(default)/documents/{col}?pageSize=1"
                s, body, _ = self.c.request(u)
                fields = []
                if s == 200:
                    try:
                        docs = json.loads(body).get("documents", [])
                        fields = sorted(docs[0].get("fields", {}).keys()) if docs else []
                    except (ValueError, AttributeError): pass
                del body
                fb["collections_checked"].append({"collection": col, "status": s, "readable": bool(fields)})
                if fields:
                    sens = [f for f in fields if SENSITIVE_COLS.search(f)]
                    self.add("firestore-open-read", "critical" if sens else "high", f"Firestore collection '{col}' is readable by anyone", dedupe=col, collection=col, columns=fields, sensitive_columns=sens)

    # 5. Exposed files
    def exposed_paths(self):
        maps = set()
        for u, t in self.texts:
            if u == "inline": continue
            maps.add(u + ".map")
            maps |= {urllib.parse.urljoin(u, m) for m in SOURCEMAP_RE.findall(t)}
        for m in sorted(maps)[:20]:
            s, body, _ = self.c.request(m)
            if s == 200 and '"mappings"' in body[:5000] and not _looks_like_html(body):
                self.add("source-map-exposed", "medium", "Source map exposed (your original source code can be downloaded)", dedupe=m, path=urllib.parse.urlparse(m).path)
        base = _origin(self.url)
        s, body, _ = self.c.request(base + "/.env")
        if s == 200 and not _looks_like_html(body) and re.search(r"^[A-Z][A-Z0-9_]*=", body, re.M):
            self.add("env-file-exposed", "critical", "/.env file is publicly downloadable (may contain secrets)", path="/.env")
        s, body, _ = self.c.request(base + "/.git/HEAD")
        if s == 200 and body.startswith("ref:"):
            self.add("git-exposed", "high", "/.git directory is publicly reachable (source code and history can be downloaded)", path="/.git/HEAD")

    # 6. Headers + CORS
    def headers(self):
        h = getattr(self, "page_headers", {})
        csp = h.get("content-security-policy", "")
        self.info["headers"] = {k: h.get(k) for k in ("content-security-policy", "strict-transport-security", "x-frame-options",
                                                     "x-content-type-options", "access-control-allow-origin", "access-control-allow-credentials")}
        if not csp: self.add("missing-csp", "low", "Missing Content-Security-Policy header")
        if self.url.lower().startswith("https://") and not h.get("strict-transport-security"): self.add("missing-hsts", "low", "Missing Strict-Transport-Security (HSTS) header")
        if not h.get("x-frame-options") and "frame-ancestors" not in csp: self.add("missing-xfo", "low", "Missing clickjacking protection (X-Frame-Options or CSP frame-ancestors)")
        acao, acac = h.get("access-control-allow-origin"), (h.get("access-control-allow-credentials") or "").lower() == "true"
        if acac and acao in ("*", PROBE_ORIGIN):
            self.add("cors-permissive-credentials", "high", "CORS allows any website to make logged-in requests (reflects arbitrary Origin with credentials)")

    def grade(self): return grade_findings(self.findings)

def grade_findings(findings):
    c = {s: sum(f["severity"] == s for f in findings) for s in ("critical", "high", "medium", "low", "info")}
    g = "F" if c["critical"] >= 2 else "D" if c["critical"] == 1 else "C" if c["high"] else "B" if c["medium"] else "A" if c["low"] <= 3 else "B"
    return g, c

def scan(url, client=None, firestore_base="https://firestore.googleapis.com", max_files=50, max_tables=50, allow_function_invocation=False):
    s = Scan(url, client or Client(), firestore_base, max_files, max_tables, allow_function_invocation)
    if s.crawl():
        s.secrets(); s.supabase(); s.firebase(); s.exposed_paths(); s.headers()
        from . import vibe
        vibe.run_all(s)
        if not s.info["supabase_url"] and not s.info["firebase"].get("database_urls") and not s.info["firebase"].get("project_ids"):
            s.add("no-backend", "info", "No Supabase or Firebase backend detected in the frontend")
    s.findings.sort(key=lambda f: SEV_ORDER.get(f["severity"], 9))
    g, counts = s.grade()
    return {"tool": "Atoll Audit", "version": "0.3", "grade": g, "counts": counts, "info": s.info, "findings": s.findings, "requests": s.c.log}
