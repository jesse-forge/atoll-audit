"""Triple-check verification for Atoll Audit scans.

Check 1: an independent first full scan.
Check 2: an independent second full scan with a fresh client. A finding is CONFIRMED only if it appears in both;
         findings seen in only one pass become SUSPECTED (shown as 'needs review', excluded from the grade).
Check 3: a safety audit of the scans and of the rendered report: only GET/HEAD/OPTIONS were used, every table
         read had limit=1, no RPC calls, no Edge Function invocation unless explicitly allowed, and no full secret,
         JWT or email address appears anywhere in result.json / report.md / report.html.
A report is READY only if all three pass; a human still reviews before sending."""
import json, re, urllib.parse
from .scanner import scan, Client, grade_findings, ALLOWED
from .report import to_markdown, to_html
from . import leaks

KEY_FIELDS = ("table", "bucket", "function", "collection", "path", "library", "variable", "setting", "route", "endpoint", "key")
EMAIL_RE = re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b")

def finding_key(f):
    for k in KEY_FIELDS:
        if f.get(k): return (f["id"], k, str(f[k]))
    return (f["id"], "title", f["title"])

def merge_passes(r1, r2):
    k2 = {finding_key(f) for f in r2["findings"]}
    confirmed, suspected = [], []
    for f in r1["findings"]:
        (confirmed if finding_key(f) in k2 or f["severity"] in ("info", "error") else suspected).append(f)
    k1 = {finding_key(f) for f in r1["findings"]}
    suspected += [f for f in r2["findings"] if finding_key(f) not in k1 and f["severity"] not in ("info", "error")]
    return confirmed, suspected

def audit_requests(requests, allow_invoke=False):
    problems = []
    for r in requests:
        if r["method"] not in ALLOWED: problems.append(f"unsafe method {r['method']}")
        p = urllib.parse.urlparse(r["url"])
        if p.path.startswith("/rest/v1/") and p.path not in ("/rest/v1/", "/rest/v1") and "limit=1" not in p.query:
            problems.append(f"table read without limit=1: {p.path}")
        if "/rest/v1/rpc/" in p.path: problems.append(f"RPC call: {p.path}")
        if "/functions/v1/" in p.path and r["method"] != "OPTIONS" and not allow_invoke:
            problems.append(f"function invoked without opt-in: {p.path}")
    return problems

def audit_outputs(texts, allowed_emails=()):
    """Look for anything that resembles an unmasked secret or a row value (email) in rendered outputs."""
    problems = []
    for name, t in texts.items():
        res = leaks.check_code(t)
        for f in res["findings"]:
            problems.append(f"{name}: unmasked {f['type']} ({f['masked']})")
        for e in set(EMAIL_RE.findall(t)) - set(allowed_emails):
            problems.append(f"{name}: email-like value present ({leaks.mask(e)})")
    return problems

def triple_check(url, client_factory=None, allow_function_invocation=False, **scan_kw):
    client_factory = client_factory or (lambda: Client())
    r1 = scan(url, client_factory(), allow_function_invocation=allow_function_invocation, **scan_kw)
    r2 = scan(url, client_factory(), allow_function_invocation=allow_function_invocation, **scan_kw)
    confirmed, suspected = merge_passes(r1, r2)
    res = dict(r1)
    for f in suspected:
        f.setdefault("original_severity", f["severity"]); f["suspected"] = True
    shown_suspected = [dict(f, severity="info", title="[Unconfirmed, seen in 1 of 2 scans] " + f["title"]) for f in suspected]
    res["findings"] = confirmed + shown_suspected
    res["grade"], res["counts"] = grade_findings(res["findings"])
    res["requests"] = r1["requests"] + r2["requests"]
    errors = [f for f in r1["findings"] + r2["findings"] if f["severity"] == "error"]
    req_problems = audit_requests(res["requests"], allow_function_invocation)
    texts = {"result.json": json.dumps(res), "report.md": to_markdown(res), "report.html": to_html(res)}
    out_problems = audit_outputs(texts)
    checks = [
        {"check": 1, "name": "first independent scan", "passed": not any(f["severity"] == "error" for f in r1["findings"]), "findings": len(r1["findings"])},
        {"check": 2, "name": "second independent scan (consistency)", "passed": not any(f["severity"] == "error" for f in r2["findings"]),
         "confirmed": len(confirmed), "suspected": len(suspected)},
        {"check": 3, "name": "safety audit (read-only requests, no leaked values in report)", "passed": not req_problems and not out_problems,
         "problems": req_problems + out_problems},
    ]
    res["verification"] = {"method": "triple-check", "checks": checks, "ready": all(c["passed"] for c in checks),
                           "confirmed_count": sum(f["severity"] not in ("info", "error") for f in confirmed), "notes_count": sum(f["severity"] in ("info", "error") for f in confirmed), "suspected_count": len(suspected), "errors": [e["title"] for e in errors]}
    res["suspected"] = [{k: f.get(k) for k in ("id", "original_severity", "title") + KEY_FIELDS if f.get(k) is not None} for f in suspected]
    return res
