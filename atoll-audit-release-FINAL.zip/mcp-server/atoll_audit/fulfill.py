"""Fulfill a free 'Request a full scan' order: validate -> ownership-proof check -> triple-checked scan -> report + email draft.

Usage:
    python3 -m atoll_audit.fulfill order.json            # JSON from the form service (app_url, email, owns_app, platform, consent_at)
    python3 -m atoll_audit.fulfill order.txt             # pasted mailto body ("App URL: ...", "Email: ...", "Ownership confirmed: yes")
    pbpaste | python3 -m atoll_audit.fulfill -           # from stdin
Options: --out orders  --delay 0.2  --require-proof

Never sends email: it writes email_draft.txt for you to review and send yourself."""
import argparse, datetime, hashlib, json, pathlib, re, sys, urllib.parse
from .scanner import Client
from .verify import triple_check
from .report import to_markdown, to_html

FIELD_ALIASES = {"app_url": ("app_url", "app url", "url", "app", "website"), "email": ("email", "e-mail", "reply_to"),
                 "owns_app": ("owns_app", "ownership confirmed", "ownership", "i own this app"), "platform": ("platform", "built with"),
                 "consent_at": ("consent_at", "consent time", "submitted_at", "_date")}

def parse_order(text):
    text = text.strip()
    raw = {}
    if text.startswith("{"):
        d = json.loads(text)
        d = d.get("data", d) if isinstance(d, dict) else {}
        raw = {str(k).lower(): v for k, v in d.items()}
    else:
        for line in text.splitlines():
            if ":" in line:
                k, v = line.split(":", 1); raw[k.strip().lower()] = v.strip()
    order = {}
    for field, names in FIELD_ALIASES.items():
        for n in names:
            if raw.get(n) not in (None, ""): order[field] = raw[n]; break
    o = str(order.get("owns_app", "")).strip().lower()
    order["owns_app"] = o in ("yes", "true", "on", "1") or o.startswith("yes")
    order["email"] = str(order.get("email", "")).strip()
    if order["email"].startswith("("): order["email"] = ""
    order["app_url"] = str(order.get("app_url", "")).strip()
    order.setdefault("platform", "unknown")
    order["request_id"] = hashlib.sha256(f"{order['app_url']}|{order['email']}|{order.get('consent_at', '')}".encode()).hexdigest()[:12]
    return order

def validate(order):
    errs = []
    p = urllib.parse.urlparse(order["app_url"])
    if p.scheme not in ("http", "https") or not p.netloc: errs.append("app_url must be a full http(s) URL")
    if p.hostname in ("localhost",) or (p.hostname or "").startswith(("127.", "10.", "192.168.", "169.254.")):
        errs.append("app_url points to a private/local address")
    if not order["owns_app"]: errs.append("ownership was not confirmed (owns_app must be yes); do not scan")
    if order["email"] and not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", order["email"]): errs.append("email looks invalid")
    return errs

def proof_token(order): return f"atoll-audit-verify={order['request_id']}"

def check_ownership_proof(order, client):
    """Optional stronger proof: owner adds /.well-known/atollaudit.txt or a <meta name="atoll-audit-verify"> tag containing the token."""
    base = "{0.scheme}://{0.netloc}".format(urllib.parse.urlparse(order["app_url"]))
    tok = order["request_id"]
    s, body, _ = client.request(base + "/.well-known/atollaudit.txt")
    if s == 200 and tok in body[:2000] and not body.lstrip().lower().startswith(("<!doctype", "<html")): return "verified (well-known file)"
    s, body, _ = client.request(order["app_url"])
    if s == 200 and re.search(r'<meta[^>]+atoll-audit-verify[^>]+' + re.escape(tok), body or ""): return "verified (meta tag)"
    return "not provided"

def email_draft(order, res, ready):
    to = order["email"] or "(no email given: reply to the request)"
    v = res["verification"]
    if not ready:
        return f"To: {to}\nSubject: [DO NOT SEND] Atoll Audit scan for {order['app_url']} needs manual review\n\nVerification failed: {json.dumps(v['checks'], indent=2)}\n"
    c = res["counts"]
    return (f"To: {to}\nSubject: Your free Atoll Audit report for {order['app_url']} (grade {res['grade']})\nAttach: report.html\n\n"
            f"Hi,\n\nThanks for requesting a free Atoll Audit launch check. Your report is attached (open report.html in any browser).\n\n"
            f"Overall grade: {res['grade']}. Findings: {c['critical']} critical, {c['high']} high, {c['medium']} medium, {c['low']} low.\n"
            f"Every finding was confirmed in two independent read-only scans. Each one comes with a fix prompt you can paste into your AI tool.\n\n"
            "Start with anything marked CRITICAL, and rotate any leaked keys first. After fixing, reply and we'll happily re-scan.\n\n"
            "This was an automated, read-only check, not a penetration test. A good grade doesn't guarantee your app is secure.\n\n"
            "Atoll Audit\n")

def fulfill(order_text, out="orders", client_factory=None, require_proof=False, firestore_base="https://firestore.googleapis.com", allow_private=False):
    order = parse_order(order_text)
    errs = validate(order)
    if allow_private: errs = [e for e in errs if "private/local" not in e]
    if errs: return 2, {"order": order, "errors": errs}
    client_factory = client_factory or (lambda: Client())
    proof = check_ownership_proof(order, client_factory())
    if require_proof and not proof.startswith("verified"):
        return 4, {"order": order, "errors": [f"ownership proof required but {proof}; ask the owner to add {proof_token(order)} at /.well-known/atollaudit.txt"]}
    res = triple_check(order["app_url"], client_factory=client_factory, firestore_base=firestore_base)  # never invokes functions
    ready = res["verification"]["ready"]
    d = pathlib.Path(out) / order["request_id"]; d.mkdir(parents=True, exist_ok=True)
    res["order"] = {"request_id": order["request_id"], "platform": order["platform"], "ownership_confirmed": True, "ownership_proof": proof,
                    "consent_at": order.get("consent_at"), "fulfilled_at": datetime.datetime.now(datetime.timezone.utc).isoformat()}
    (d / "result.json").write_text(json.dumps(res, indent=2))
    (d / "report.md").write_text(to_markdown(res))
    (d / "report.html").write_text(to_html(res))
    (d / "verification.json").write_text(json.dumps(res["verification"], indent=2))
    (d / "email_draft.txt").write_text(email_draft(order, res, ready))
    return (0 if ready else 3), {"order": order, "dir": str(d), "ready": ready, "grade": res["grade"], "counts": res["counts"], "proof": proof}

def main(argv=None, **kw):
    ap = argparse.ArgumentParser(prog="atoll-audit-fulfill", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("order", help="order JSON/text file, or - for stdin")
    ap.add_argument("--out", default="orders"); ap.add_argument("--delay", type=float, default=0.2)
    ap.add_argument("--require-proof", action="store_true", help="refuse unless the owner added the verification token to their site")
    a = ap.parse_args(argv)
    text = sys.stdin.read() if a.order == "-" else pathlib.Path(a.order).read_text()
    code, info = fulfill(text, a.out, client_factory=lambda: Client(delay=a.delay), require_proof=a.require_proof, **kw)
    if code == 2: print("Order rejected: " + "; ".join(info["errors"]), file=sys.stderr)
    elif code == 4: print(info["errors"][0], file=sys.stderr)
    else:
        print(f"{'READY TO SEND (after your review)' if info['ready'] else 'NOT READY: verification failed, see verification.json'}: "
              f"grade {info['grade']} {info['counts']} · ownership proof: {info['proof']} · files in {info['dir']}")
        print(f"Ownership token for stronger proof (optional): {proof_token(info['order'])}")
    return code

if __name__ == "__main__":
    sys.exit(main())
