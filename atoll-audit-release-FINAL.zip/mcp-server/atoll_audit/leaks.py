"""Key-leak detection on pasted code/bundle text. Python twin of the browser checker
(atoll-audit-site/checker/index.html); finding type ids are identical and a test keeps them in sync.
Never returns full keys: only masked values (first 6 + last 4 chars)."""
import base64, json, re

def mask(s): return s[:6] + "\u2026" + s[-4:] if len(s) > 12 else "\u2026"

def jwt_role(tok):
    try:
        p = tok.split(".")[1]; p += "=" * (-len(p) % 4)
        return json.loads(base64.urlsafe_b64decode(p)).get("role")
    except Exception:
        return None

# (type id, label, severity, regex)
RULES = [
    ("supabase_secret_key", "Supabase secret key (sb_secret_)", "critical", re.compile(r"sb_secret_[A-Za-z0-9_-]{10,}")),
    ("stripe_secret_key", "Stripe secret or restricted key", "critical", re.compile(r"\b[sr]k_(?:live|test)_[A-Za-z0-9]{10,}")),
    ("anthropic_key", "Anthropic API key", "critical", re.compile(r"sk-ant-[A-Za-z0-9_-]{20,}")),
    ("openai_key", "OpenAI API key", "critical", re.compile(r"sk-(?!ant-)(?:proj-|svcacct-|admin-)?[A-Za-z0-9_-]{20,}")),
    ("resend_key", "Resend API key", "critical", re.compile(r"\bre_[A-Za-z0-9_]{20,}")),
    ("twilio_key", "Twilio API key", "critical", re.compile(r"\bSK[0-9a-fA-F]{32}\b")),
    ("sendgrid_key", "SendGrid API key", "critical", re.compile(r"\bSG\.[A-Za-z0-9_-]{16,}\.[A-Za-z0-9_-]{16,}")),
    ("aws_access_key", "AWS access key ID", "critical", re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b")),
    ("github_token", "GitHub token", "critical", re.compile(r"\b(?:ghp|gho|ghs|ghu)_[A-Za-z0-9]{30,}|\bgithub_pat_[A-Za-z0-9_]{30,}")),
    ("slack_token", "Slack token", "high", re.compile(r"\bxox[abprs]-[A-Za-z0-9-]{10,}")),
    ("private_key", "Private key block", "critical", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----")),
    ("google_api_key", "Google / Firebase API key", "medium", re.compile(r"AIza[0-9A-Za-z_-]{35}")),
]
JWT_RE = re.compile(r"eyJ[A-Za-z0-9_-]{8,}\.eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}")
PUBLISHABLE_RE = re.compile(r"sb_publishable_[A-Za-z0-9_-]{10,}")
ENV_RE = re.compile(r"\b((?:NEXT_PUBLIC|VITE|REACT_APP|EXPO_PUBLIC)_[A-Z0-9_]*(?:SECRET|PRIVATE|SERVICE_ROLE|PASSWORD|PASSWD|ADMIN_KEY|TOKEN)[A-Z0-9_]*)[\"']?\s*[:=]\s*[\"'`]([^\"'`\s]{8,})[\"'`]?")
ENV_IGNORE = re.compile(r"^(?:undefined|null|true|false|process\.env.*|import\.meta.*|your[_-].*|xxx+|changeme|placeholder)$", re.I)
PLATFORMS = [("lovable", re.compile(r"lovable\.(?:app|dev)|lovable-tagger|gptengineer|gpt-engineer", re.I)),
             ("bolt", re.compile(r"bolt\.new|stackblitz|webcontainer", re.I)),
             ("v0", re.compile(r"v0\.dev|vusercontent\.net|v0\.app", re.I)),
             ("replit", re.compile(r"replit\.(?:app|dev|com)|\.repl\.co|__replco", re.I))]
SEV = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}

FIX = {
    "supabase_service_role": "Rotate the service_role key in Supabase (Project Settings → API Keys). Then remove it from all frontend code; use it only in Edge Functions/server code that checks the user's login. The browser must only use the anon/publishable key.",
    "supabase_anon_key": "No need to hide the anon key. Make sure Row Level Security is enabled on every table, with policies so users can only read and write their own rows.",
    "supabase_publishable_key": "No need to hide the publishable key. Make sure Row Level Security is enabled on every table.",
    "google_api_key": "Restrict this key in Google Cloud Console → Credentials: HTTP referrer restriction to your domain plus API restrictions; add a budget alert.",
    "public_env_secret": "Rotate the value, then rename the variable so it does NOT start with VITE_/NEXT_PUBLIC_/REACT_APP_, use it only in server code, and redeploy.",
}
def fix_for(tid, label):
    return FIX.get(tid) or (f"Rotate (revoke and replace) this {label} in the provider's dashboard first. Then remove it from all frontend code, "
                            "store it as a server-side secret (Supabase Edge Function secret or server env var), and call the provider only from a server function that checks the user's login. Redeploy.")

def _line(text, idx): return text.count("\n", 0, idx) + 1

def detect_platform(text):
    for name, rx in PLATFORMS:
        if rx.search(text): return name
    return "unknown"

def check_code(text):
    """Return {"findings": [...], "platform": str, "serious": int}. Findings carry masked keys only."""
    text = str(text or "")[:20_000_000]
    out, seen = [], set()
    def add(tid, label, sev, tok, idx, **extra):
        if (tid, tok) in seen: return
        seen.add((tid, tok))
        out.append({"type": tid, "label": label, "severity": sev, "masked": mask(tok), "line": _line(text, idx), "fix_prompt": fix_for(tid, label), **extra})
    for m in JWT_RE.finditer(text):
        r = jwt_role(m.group(0))
        if r == "service_role": add("supabase_service_role", "Supabase service_role key", "critical", m.group(0), m.start())
        elif r == "anon": add("supabase_anon_key", "Supabase anon key (normally public)", "info", m.group(0), m.start())
    for m in PUBLISHABLE_RE.finditer(text): add("supabase_publishable_key", "Supabase publishable key (normally public)", "info", m.group(0), m.start())
    for tid, label, sev, rx in RULES:
        for m in rx.finditer(text): add(tid, label, sev, m.group(0), m.start())
    for m in ENV_RE.finditer(text):
        val = m.group(2)
        if ENV_IGNORE.match(val) or any(f["masked"] == mask(val) for f in out): continue
        add("public_env_secret", f"Secret-looking public environment variable ({m.group(1)})", "high", val, m.start(), variable=m.group(1))
    out.sort(key=lambda f: SEV[f["severity"]])
    return {"findings": out, "platform": detect_platform(text), "serious": sum(f["severity"] != "info" for f in out)}
