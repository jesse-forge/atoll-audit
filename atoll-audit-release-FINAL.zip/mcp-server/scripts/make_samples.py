"""Regenerate sample reports from the local FAKE test apps (no network beyond 127.0.0.1)."""
import json, pathlib, shutil, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from testtarget import server, apps
from atoll_audit.scanner import Client
from atoll_audit.verify import triple_check
from atoll_audit.report import to_markdown, to_html
from atoll_audit import remediate

def write(d, res):
    d = ROOT / "reports" / d; d.mkdir(parents=True, exist_ok=True)
    (d / "result.json").write_text(json.dumps(res, indent=2)); (d / "report.md").write_text(to_markdown(res)); (d / "report.html").write_text(to_html(res))
    return d

t = server.start(); b = apps.bolt_firebase(); n = apps.next_supabase(); s = apps.next_secure()
cf = lambda: Client(delay=0.002)
d = write("sample", triple_check(t["site"], client_factory=cf, firestore_base=t["firebase"]))
write("sample-bolt-firebase", triple_check(b["site"], client_factory=cf, firestore_base=b["firebase"]))
write("sample-next-supabase", triple_check(n["site"], client_factory=cf))
write("sample-next-secure", triple_check(s["site"], client_factory=cf))
rd = ROOT / "reports" / "sample-remediation"; shutil.rmtree(rd, ignore_errors=True); rd.mkdir(parents=True)
lines = []
remediate.run(json.loads((d / "result.json").read_text()), "fakeprojectref", apply=False, log_path=rd / "remediation-audit.jsonl",
              drafts_dir=rd / "drafts", out=lines.append)
(rd / "dry-run.txt").write_text("\n".join(lines) + "\n")
print("ok")
