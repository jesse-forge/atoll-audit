"""One-page summary of Atoll Audit's GoatCounter analytics.

    python3 scripts/goatcounter_summary.py --csv goatcounter-export.csv[.gz] [--out goatcounter-summary.md]
    GOATCOUNTER_TOKEN=... python3 scripts/goatcounter_summary.py --site atollaudit      # uses the export API

The API flow follows goatcounter.com/help/api: POST /api/v0/export, poll GET /api/v0/export/{id}, then
GET /api/v0/export/{id}/download (gzipped CSV). The token is read from the environment and never printed."""
import argparse, collections, csv, gzip, io, json, os, pathlib, re, sys, time, urllib.request

def fetch_export(site, token, timeout=120):
    api = f"https://{site}.goatcounter.com/api/v0"
    def call(method, path, raw=False):
        req = urllib.request.Request(api + path, method=method, headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
                                     data=b"{}" if method == "POST" else None)
        with urllib.request.urlopen(req, timeout=30) as r: return r.read() if raw else json.loads(r.read())
    eid = call("POST", "/export")["id"]; t0 = time.time()
    while not call("GET", f"/export/{eid}").get("finished_at"):
        if time.time() - t0 > timeout: raise TimeoutError("export did not finish")
        time.sleep(1.5)
    return gzip.decompress(call("GET", f"/export/{eid}/download", raw=True)).decode("utf-8", "replace")

def read_csv_text(path):
    b = pathlib.Path(path).read_bytes()
    return (gzip.decompress(b) if b[:2] == b"\x1f\x8b" else b).decode("utf-8", "replace")

def rows(text):
    r = csv.reader(io.StringIO(text)); hdr = next(r)
    hdr[0] = re.sub(r"^\d+,?", "", hdr[0])  # export format version is prefixed to the first column name
    hdr = [h.strip().lower() for h in hdr]
    for line in r:
        if line: yield dict(zip(hdr, line))

def summarize(text):
    pv, ev, refs, days = collections.Counter(), collections.Counter(), collections.Counter(), collections.Counter()
    for x in rows(text):
        if (x.get("bot") or "0") not in ("0", "", "false"): continue
        path = x.get("path", ""); is_event = (x.get("event") or "").lower() in ("true", "1", "t", "yes")
        (ev if is_event else pv)[path] += 1
        if not is_event:
            if x.get("referrer"): refs[x["referrer"]] += 1
            days[(x.get("date") or "")[:10]] += 1
    return pv, ev, refs, days

def pct(a, b): return f"{100 * a / b:.0f}%" if b else "n/a"

def report(pv, ev, refs, days):
    home = sum(v for k, v in pv.items() if k.rstrip("/") in ("", "/index.html") or k == "/")
    checker = sum(v for k, v in pv.items() if "checker" in k)
    runs = ev["check_run"]; finds = {k: v for k, v in ev.items() if k.startswith("finding_")}
    plats = {k[len("platform_"):]: v for k, v in ev.items() if k.startswith("platform_")}
    serious = sum(v for k, v in finds.items() if k not in ("finding_supabase_anon_key", "finding_supabase_publishable_key"))
    L = ["# Atoll Audit: analytics summary (GoatCounter)", "", f"Total page views: **{sum(pv.values())}** · days covered: {len([d for d in days if d])}", "",
         "## Funnel", "", "| Step | Count | Rate |", "|---|---|---|",
         f"| Home page views | {home} | |", f"| Checker page views | {checker} | {pct(checker, home)} of home |",
         f"| Checks run (`check_run`) | {runs} | {pct(runs, checker)} of checker views |",
         f"| Secret-key finding events | {serious} | {pct(serious, runs)} per check (types counted once per check) |",
         f"| Full-scan requests (`scan_request`) | {ev['scan_request']} | {pct(ev['scan_request'], home)} of home |", "",
         "## Findings by type", ""] + ([f"- `{k}`: {v}" for k, v in sorted(finds.items(), key=lambda kv: -kv[1])] or ["- none yet"]) + [
         "", "## Platforms (selected or detected)", ""] + ([f"- {k}: {v}" for k, v in sorted(plats.items(), key=lambda kv: -kv[1])] or ["- none yet"]) + [
         "", "## Top referrers", ""] + ([f"- {k}: {v}" for k, v in refs.most_common(10)] or ["- none yet"]) + [
         "", "## Page views by path", ""] + [f"- `{k}`: {v}" for k, v in pv.most_common(15)] + [
         "", "_Counts only: GoatCounter stores no personal data and Atoll Audit sends no code, keys, URLs or emails._", ""]
    return "\n".join(L)

def main(argv=None):
    ap = argparse.ArgumentParser(); g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--csv"); g.add_argument("--site", help="GoatCounter site code; needs GOATCOUNTER_TOKEN env var")
    ap.add_argument("--out", default="goatcounter-summary.md"); a = ap.parse_args(argv)
    if a.site:
        tok = os.environ.get("GOATCOUNTER_TOKEN")
        if not tok: print("Set GOATCOUNTER_TOKEN (API key with export permission).", file=sys.stderr); return 2
        text = fetch_export(a.site, tok)
    else: text = read_csv_text(a.csv)
    md = report(*summarize(text)); pathlib.Path(a.out).write_text(md); print(f"Wrote {a.out}"); return 0

if __name__ == "__main__":
    sys.exit(main())
