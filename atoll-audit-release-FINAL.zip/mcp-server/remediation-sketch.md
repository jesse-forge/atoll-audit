# Atoll Audit: Remediation Layer (outline)
*Draft, Oct 16 2026. Plain-English sketch for Jesse. "Verified" means checked against the provider docs on this date. Items marked ⚠️ are uncertain or need re-checking before building.*

**The idea:** today the scanner finds problems. The remediation layer would also **propose a fix, show exactly what will change, wait for your OK, apply it through the provider's official API, re-scan to prove it worked, and keep an undo button.** Nothing changes without approval.

## 1. What can be automated vs what needs a human
| Fix | Automate? | Why |
|---|---|---|
| Turn on RLS + **default-deny** (no policies) on an exposed table | ✅ Yes, one SQL line per table | Safe for data, but **it can break the app** (pages that read that table go blank). Always show that warning |
| Write the **correct per-user policies** (e.g. `auth.uid() = user_id`) | ⚠️ Draft only | Needs knowledge of the app (which column is the owner? teams? public rows?). AI drafts it, a human reviews it, then test as two users |
| Make a storage bucket private | ✅ Yes (one SQL/Storage call) | Breaks any public image links. Logos and avatars may be *meant* to be public, so ask first |
| Rotate Supabase secret/service_role key | ✅ Mechanically yes, ⚠️ risky | Anything still using the old key (Edge Functions, cron jobs, servers) breaks. Safe order: create new key → update every place that uses it → *then* disable the old one. Legacy key deactivation can be undone. Deleting a new-style secret key **cannot** be undone (Supabase docs) |
| Rotate Stripe / OpenAI / Resend / Twilio keys | ⚠️ Mostly manual, guided | Each provider differs. ⚠️ Stripe secret-key rolling seems to be Dashboard-only (unverified). OpenAI has an Admin API for project keys (⚠️ verify scope). v1: give step-by-step instructions plus a checklist |
| Remove a secret from frontend code | ❌ Not via API | Needs a code change and a redeploy. v1: generate the Lovable/Cursor prompt. Later: open a GitHub pull request for the customer to merge |
| Security headers (CSP, HSTS, X-Frame-Options), fix CORS | ✅ If the site is behind Cloudflare | Cloudflare Response Header Transform Rules via API (verified). CSP can break scripts, so start in "report-only" mode. Vercel/Netlify headers live in a config file in the code, so that becomes a PR |
| Source maps / `.env` / `.git` exposed | ❌ Mostly code/build changes | Turn off sourcemaps in the build config, stop deploying dotfiles, redeploy. Then rotate anything that was in `.env`. A Cloudflare rule can *block* those paths immediately as a stopgap ✅ |
| Open Firebase/Firestore rules | ⚠️ Draft + human | Rules are logic, like RLS policies. Default-deny is automatable but likely breaks the app |

**Rule of thumb:** automate **"close the door"** fixes (default-deny, private, block path). Keep **"decide who gets a key"** fixes (per-user policies, key rotation order, code changes) as drafts a human approves.

## 2. API access per provider (least privilege)
- **Supabase:**
  - *Personal Access Token* (scoped/fine-grained) for Jesse's own testing.
  - *OAuth app* for customers, so they approve access themselves and can revoke it.
  - SQL runs through `POST /v1/projects/{ref}/database/query` (OAuth scope `database:write`). There is also a separate **read-only query** endpoint (`database:read`), which the scan/diff step should use (verified). ⚠️ Both are marked **beta/experimental**, so they may change.
  - Keys: `secrets:read` / `secrets:write` scopes and `/v1/projects/{ref}/api-keys` endpoints (verified).
  - Bucket privacy: SQL on `storage.buckets` or the Storage API (⚠️ choose and verify).
- **Cloudflare:** a scoped API token limited to **one zone**, with *Transform Rules: Edit* (+ *Account Rulesets: Read*) for headers (verified). Add WAF/custom rules edit only if blocking paths. Never use the Global API Key.
- **Firebase/GCP:** a service account limited to the one project, with a rules-only role (⚠️ verify the exact role names, e.g. Firebase Rules Admin). No Owner/Editor.
- **Stripe:** a **restricted key** with the minimum permissions, only if needed at all. v1 shouldn't need Stripe access.
- **Vercel/Netlify:** tokens scoped to one team/project, used to trigger redeploys or read deploy settings. ⚠️ Check how finely they can be scoped; Vercel tokens can be broad.
- **GitHub (for code-fix PRs):** a GitHub App installed on **one repo**, with Contents + Pull requests write. It opens PRs only and never pushes to main.
- **Storage of credentials:**
  - Prefer OAuth (short-lived, revocable) over pasted tokens.
  - Encrypt tokens at rest (e.g. Cloudflare Workers secrets / a KMS).
  - Never log tokens, delete them after the job, and ask the customer to revoke access when done.
  - One customer's token can never touch another customer's project.

## 3. Architecture (propose → execute → verify → undo)
1. **Scan:** the existing read-only scanner produces findings.
2. **Propose:** for each finding, a fix "plan": what will change, the exact SQL/API call, the **risk** ("this page may stop loading"), and the **undo** step.
3. **Dry-run / diff:** read the current state with read-only access (current RLS status, policies, bucket setting, headers) and show before → after. Where possible, test SQL in a transaction that is rolled back, or on a Supabase branch (⚠️ branching may need a paid plan).
4. **Approve:** the customer clicks approve per fix (not "approve all" for risky ones). Record who approved, when, and which exact plan version.
5. **Execute:** one fix at a time, through official APIs only, with a rollback snapshot saved first (e.g. old policies and the bucket flag).
6. **Verify:** re-run the scanner. Pass = the finding is gone **and** a basic health check of the app still loads. Fail = automatic or one-click rollback.
7. **Rollback:** a stored inverse action (disable RLS, re-create old policies, make the bucket public again, remove the Cloudflare rule). Key rotation and key deletion **can't be fully undone**, so they need extra confirmation.
8. **Audit log:** an append-only log of every scan, plan, approval, API call (secrets redacted), result, and rollback. Exportable as part of the report.

## 4. Realistic 2-week v1 (Supabase-only)
- **In scope:**
  1. Enable RLS + default-deny on exposed tables.
  2. Make chosen buckets private.
  3. AI-drafted per-user policies shown for review only, not auto-applied.
  4. A guided key-rotation checklist (instructions, no API changes).
  5. Re-scan verification plus one-click rollback for 1 and 2.
- **Access:** Jesse's own scoped PAT against his own deliberately insecure test project. A customer OAuth app comes later.
- **Week 1:** plan/diff/rollback data model, read-only state reader, the two fix actions, audit log file.
- **Week 2:** approval step (CLI, then a simple web page), verify-by-rescan, rollback, tests against a real free Supabase project, and docs.
- **Out of v1:** Cloudflare/Firebase/Vercel, code PRs, automated key rotation, customers' production databases.

## 5. Indie vs sellable-to-small-business
| | Indie tier (v1) | Small-business tier (later) |
|---|---|---|
| **Who acts** | Customer clicks approve; Jesse's tool runs it | **Customer-approved changes only**, ideally run with *their* OAuth grant. Never Jesse acting on his own |
| **Authorization** | Consent checkbox + ownership check | Signed written authorization (scope, systems, dates, contact), like a mini pentest engagement letter |
| **Liability/ToS** | Clear ToS: "suggestions; you approve; limited to amount paid" | Lawyer-reviewed MSA, liability caps, and ⚠️ cyber/tech **E&O insurance**, which many businesses will require |
| **Audit trail** | Log file | **Immutable** (append-only, tamper-evident, e.g. hash-chained), exportable |
| **Reports** | Friendly HTML report | Compliance-friendly evidence: before/after, timestamps, approver, verification result. Useful for **SOC 2-style evidence**, but it is not a SOC 2 certification |
| **Rollback** | Best effort, one click | Documented rollback guarantee per fix type, plus change windows |
| **Data handling** | Minimal, nothing stored | Written data-handling/retention policy and a security contact. Jesse's own setup must also be hardened |

**Recommendation:** start with the indie tier on Jesse's own test projects. Only approach small businesses once there is a lawyer-reviewed agreement and insurance quotes.

**Main uncertainties to re-check:**
- Supabase SQL endpoints are beta.
- Exact method for bucket privacy.
- Stripe key rotation via API.
- OpenAI Admin API scope.
- GCP rule-role names.
- How finely Vercel tokens can be scoped.
- Whether Supabase branching works on the free tier.

Sources (checked Oct 16 2026):
- supabase.com/docs/reference/api/v1-run-a-query
- …/v1-read-only-query
- …/v1-update-project-api-key
- supabase.com/docs/guides/getting-started/api-keys
- supabase.com/docs/guides/integrations/supabase-for-platforms
- developers.cloudflare.com/rules/transform/response-header-modification/create-api/
