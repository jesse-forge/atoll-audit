// Atoll Audit DEMO app. INTENTIONALLY INSECURE. All keys below are FAKE and do not work.
const SUPABASE_URL = "https://atolldemofakeproject.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiAiSFMyNTYiLCAidHlwIjogIkpXVCJ9.eyJpc3MiOiAic3VwYWJhc2UiLCAicmVmIjogImF0b2xsZGVtb2Zha2Vwcm9qZWN0IiwgInJvbGUiOiAiYW5vbiIsICJpYXQiOiAxNzYwMDAwMDAwLCAiZXhwIjogMjA3NTAwMDAwMH0.FAKE-SIGNATURE-not-a-real-key-anon";
// BAD PRACTICE (planted for the demo): a service_role key shipped to the browser
const SUPABASE_SERVICE_ROLE_KEY = "eyJhbGciOiAiSFMyNTYiLCAidHlwIjogIkpXVCJ9.eyJpc3MiOiAic3VwYWJhc2UiLCAicmVmIjogImF0b2xsZGVtb2Zha2Vwcm9qZWN0IiwgInJvbGUiOiAic2VydmljZV9yb2xlIiwgImlhdCI6IDE3NjAwMDAwMDAsICJleHAiOiAyMDc1MDAwMDAwfQ.FAKE-SIGNATURE-not-a-real-key-service";
const VITE_ADMIN_API_SECRET = "demo-admin-secret-FAKE-1234567890abcdef";
document.getElementById('f').addEventListener('submit', e => {
  e.preventDefault();
  document.getElementById('out').textContent = 'Thanks, ' + document.getElementById('name').value + '! (demo only, nothing was sent)';
});
//# sourceMappingURL=app.js.map
